#!/usr/bin/env node
/* يقين — رفيق المسلم | أداة إصدار تحديث محلي (لا تنشر شيئاً)
 *
 * الاستخدام (من داخل ~/workspace/yaqeen/app):
 *   node scripts/make-update.js --version 2.5.1 --code 2 \
 *       --changelog "إصلاح ..." --changelog "إضافة ..." [--apk path/to/app-debug.apk]
 *
 * ما تفعله، بالترتيب:
 *   1. تتحقق أن versionCode الجديد عدد صحيح أكبر من الحالي في version.json.
 *   2. تُحدِث version.json و js/version.js و package.json (الاسم فقط) بالنسخة الجديدة.
 *   3. تشغّل بناء الويب (scripts/build-web.js) فينتج www/ بالنسخة الجديدة.
 *   4. تضغط www/ في updates/web-<version>.zip وتحسب بصمته SHA-256.
 *   5. إن وُجد APK تصحيح (المسار الافتراضي android/app/build/outputs/apk/debug/app-debug.apk
 *      أو --apk) تحسب بصمته أيضاً؛ وإلا تُترك حقول APK فارغة.
 *   6. تكتب updates/updates.json وupdates/latest.json (البيان) محلياً فقط
 *      (نسختان بالمحتوى نفسه؛ latest.json هو ما يُرفع للاستضافة).
 *
 * لا تنشر شيئاً ولا ترفع شيئاً ولا تغيّر أي توقيع: النشر على خادم تملكه
 * خطوة يدوية لاحقة موثقة في docs/update-release-guide.md.
 * لا تشغّل Gradle ولا تبني APK بنفسها.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync, execSync } = require('child_process');

const root = path.join(__dirname, '..');
const outDir = path.join(root, 'updates');

function usage() {
  console.error('الاستخدام: node scripts/make-update.js --version <X.Y.Z> --code <N> --changelog "نص" [--changelog "نص"] [--apk <path>]');
  process.exit(2);
}
function arg(flag) {
  const vals = [];
  const argv = process.argv.slice(2);
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === flag && argv[i + 1] !== undefined) vals.push(argv[++i]);
  }
  return vals;
}

const versionName = (arg('--version')[0] || '').trim();
const codeRaw = arg('--code')[0];
const changelog = arg('--changelog');
const apkArg = arg('--apk')[0];
if (!/^\d+\.\d+\.\d+$/.test(versionName)) { console.error('خطأ: --version يجب أن يكون بصيغة X.Y.Z (مثال 2.5.1)'); usage(); }
const versionCode = Number(codeRaw);
if (!Number.isInteger(versionCode) || versionCode <= 0) { console.error('خطأ: --code يجب أن يكون عدداً صحيحاً موجباً'); usage(); }
if (changelog.length === 0) { console.error('خطأ: أضف سجل تغييرات واحداً على الأقل عبر --changelog "نص"'); usage(); }

const versionPath = path.join(root, 'version.json');
const current = JSON.parse(fs.readFileSync(versionPath, 'utf8'));
if (versionCode <= current.versionCode) {
  console.error(`خطأ: versionCode الجديد (${versionCode}) يجب أن يكون أكبر من الحالي (${current.versionCode}) — الأرقام لا تعود للوراء أبداً`);
  process.exit(1);
}
const buildDate = new Date().toISOString().slice(0, 10);
const next = { versionName, versionCode, buildDate };

// 1+2. تحديث مصدر النسخة الواحد في أماكنه الثلاثة (يدوياً هنا؛ والبناء يولّد نسخة www منها)
fs.writeFileSync(versionPath, JSON.stringify(next, null, 2) + '\n');
const versionJs = path.join(root, 'js', 'version.js');
const versionJsSrc = fs.readFileSync(versionJs, 'utf8');
if (!/window\.YAQEEN_VERSION = \{/.test(versionJsSrc)) { console.error('خطأ: بنية js/version.js غير متوقعة — أوقف قبل أي تغيير'); process.exit(1); }
fs.writeFileSync(versionJs, versionJsSrc
  .replace(/versionName: '[^']*'/, `versionName: '${versionName}'`)
  .replace(/versionCode: \d+/, `versionCode: ${versionCode}`)
  .replace(/buildDate: '[^']*'/, `buildDate: '${buildDate}'`));
const pkgPath = path.join(root, 'package.json');
const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
pkg.version = versionName;
fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n');
console.log(`النسخة الجديدة: ${versionName} / رمز ${versionCode} (كانت ${current.versionName} / رمز ${current.versionCode})`);

// 3. بناء الويب
execSync('node scripts/build-web.js', { cwd: root, stdio: 'inherit' });

// 4. ضغط www/ وحساب البصمة
fs.mkdirSync(outDir, { recursive: true });
const zipName = `web-${versionName}.zip`;
const zipPath = path.join(outDir, zipName);
try {
  execFileSync('zip', ['-r', '-q', zipPath, '.'], { cwd: path.join(root, 'www'), stdio: 'inherit' });
} catch {
  // بديل بلا أداة zip: بايثون يضغط محتويات www/ من جذره (لا مجلد www/ داخل الأرشيف)
  const py = [
    'import zipfile, os, sys',
    'src, dst = sys.argv[1], sys.argv[2]',
    'z = zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED)',
    'for dp, dn, fn in os.walk(src):',
    '    for f in fn:',
    '        p = os.path.join(dp, f)',
    '        z.write(p, os.path.relpath(p, src))',
    'z.close()',
  ].join('\n');
  execFileSync('python3', ['-c', py, path.join(root, 'www'), zipPath], { stdio: 'inherit' });
}
const sha256File = (p) => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const webSha = sha256File(zipPath);
const webSize = fs.statSync(zipPath).size;
console.log(`${zipName}: ${webSize} بايت، sha256 ${webSha}`);

// 5. بصمة APK إن وُجد (لا يُبنى هنا)
let apkUrl = '';
let apkSha = '';
let apkSize = 0;
const apkDefault = path.join(root, 'android', 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk');
const apkPath = apkArg ? path.resolve(apkArg) : apkDefault;
if (fs.existsSync(apkPath)) {
  apkSha = sha256File(apkPath);
  apkSize = fs.statSync(apkPath).size;
  console.log(`APK موجود: ${apkPath} (${apkSize} بايت)، sha256 ${apkSha}`);
  console.log('ملاحظة: ضع رابط APK في updates.json يدوياً بعد رفعه إلى خادمك (الحقل apkUrl) — الأداة لا تنشره ولا تعرف رابطك.');
} else {
  console.log('لا يوجد APK تصحيح في المسار الافتراضي — حقلا apkUrl/apkSha256 تُتركان فارغين في البيان (تحديث ويب OTA فقط).');
}

// 6. كتابة البيان محلياً فقط — نسختان بالمحتوى نفسه:
//    updates.json (الاسم التاريخي) وlatest.json (الاسم الذي يُرفع للاستضافة
//    ويُشار إليه من js/update-config.js). لا يُنشر أي منهما تلقائياً.
const manifest = {
  versionName,
  versionCode,
  changelog,
  webZipUrl: '',
  webZipSha256: webSha,
  webZipSize: webSize,
  apkUrl,
  apkSha256: apkSha,
  apkSize,
  minVersionCode: current.versionCode,
  publishedAt: buildDate,
  notes: 'حدّث حقلي webZipUrl (وapkUrl إن وُجد) بروابط خادمك قبل النشر. انظر docs/update-release-guide.md.',
};
const manifestJson = JSON.stringify(manifest, null, 2) + '\n';
fs.writeFileSync(path.join(outDir, 'updates.json'), manifestJson);
fs.writeFileSync(path.join(outDir, 'latest.json'), manifestJson);
console.log(`\nتم محلياً (لم يُنشر شيء):`);
console.log(`  - ${path.relative(root, zipPath)}`);
console.log(`  - ${path.relative(root, path.join(outDir, 'updates.json'))}`);
console.log(`  - ${path.relative(root, path.join(outDir, 'latest.json'))} (نسخة مطابقة — ارفعها للاستضافة)`);
console.log('الخطوات التالية: ارفع الملفات إلى خادم تملكه، واملأ webZipUrl (وapkUrl) في latest.json، ثم ضع رابط latest.json في js/update-config.js وأعد بناء APK. التفاصيل في docs/update-release-guide.md.');
