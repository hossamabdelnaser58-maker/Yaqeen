// ينسخ ملفات التطبيق إلى مجلد www لبناء تطبيق أندرويد
// مصدر النسخة الواحد: version.json في جذر نسخة العمل.
// يُقرأ منه versionName/versionCode/buildDate وتُكتب في:
//  - www/js/native-flags.js (window.NOOR_BUILD: code + versionName + buildDate)
//  - www/js/version.js (window.YAQEEN_VERSION — يُولَّد من version.json نفسه،
//    فيستحيل أن يختلفا بعد البناء)
//  - www/version.json (نسخة مرجعية مقروءة داخل الحزمة)
// أرقام أندرويد الأصلية (versionCode/versionName في build.gradle) ما زالت
// تُشتق من native-level.txt ومتغيرات البيئة/رقم التشغيل، لا من هذا الملف
// (انظر docs/update-system.md §1: لماذا بقيت كذلك في دورة التصحيح هذه).
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const out = path.join(root, 'www');

const VERSION = JSON.parse(fs.readFileSync(path.join(root, 'version.json'), 'utf8'));
if (typeof VERSION.versionName !== 'string' || !VERSION.versionName.trim()) {
  throw new Error('version.json: versionName مفقود أو غير نصي');
}
if (!Number.isInteger(VERSION.versionCode) || VERSION.versionCode <= 0) {
  throw new Error('version.json: versionCode يجب أن يكون عدداً صحيحاً موجباً');
}
VERSION.buildDate = VERSION.buildDate || new Date().toISOString().slice(0, 10);

fs.rmSync(out, { recursive: true, force: true });
for (const f of ['index.html', 'manifest.webmanifest', 'sw.js', 'css', 'js', 'icons', 'data', 'yt.html']) {
  fs.cpSync(path.join(root, f), path.join(out, f), { recursive: true });
}
// هل يوجد ملف أذان مخصص؟
const hasAdhan = fs.existsSync(path.join(root, 'adhan', 'adhan.mp3'));
if (hasAdhan) fs.cpSync(path.join(root, 'adhan'), path.join(out, 'adhan'), { recursive: true });
const code = parseInt(process.env.NOOR_VERSION_CODE || String(VERSION.versionCode), 10);
const kind = process.env.NOOR_BUILD_KIND || 'local';
fs.writeFileSync(path.join(out, 'js', 'native-flags.js'),
  `window.NOOR_NATIVE_ADHAN = ${hasAdhan};\nwindow.NOOR_BUILD = ${JSON.stringify({ code, kind, versionName: VERSION.versionName, buildDate: VERSION.buildDate })};\n`);
// version.js في www يُولَّد من version.json نفسه (مصدر واحد، لا نسختين)
fs.writeFileSync(path.join(out, 'js', 'version.js'),
  `/* مولَّد من version.json أثناء البناء — لا تُعدَّله يدوياً هنا */\nwindow.YAQEEN_VERSION = ${JSON.stringify(VERSION)};\n`);
fs.writeFileSync(path.join(out, 'version.json'), JSON.stringify(VERSION, null, 2) + '\n');
console.log(`www جاهز (الإصدار ${VERSION.versionName} / رمز ${code})`, hasAdhan ? '(مع صوت أذان مخصص)' : '');
