window.NOOR_NATIVE_ADHAN = false;
window.NOOR_BUILD = {"code":1,"kind":"local","versionName":"2.5.0","buildDate":"2026-11-19"};
