// تطبيق «يقين»: وكيل IslamHouse (دار الإسلام) — يخفي مفتاح IslamHouse API عن العميل.
// يقرأ المفتاح من سرّ الدالة ISLAMHOUSE_API_KEY فقط، ولا يعيده أو يسجّله أبداً.
// يقبل معرّفاً رقمياً واحداً فقط ويستدعي get-item بالعربية، ثم يعيد نسخة مختصرة
// بالحقول نفسها التي يحتفظ بها js/library.js. لم تُنشر هذه الدالة بعد —
// النشر وضبط السرّ يتطلبان الوصول إلى مشروع Supabase الحي (انظر docs/change-log.md).
const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'apikey, authorization, content-type' };
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: CORS });
  const id = new URL(req.url).searchParams.get('id') || '';
  if (!/^\d{1,10}$/.test(id)) return Response.json({ error: 'bad id' }, { status: 400, headers: CORS });
  const key = Deno.env.get('ISLAMHOUSE_API_KEY');
  if (!key) return Response.json({ error: 'not configured' }, { status: 500, headers: CORS });
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 10000);
    let r;
    try {
      r = await fetch('https://api3.islamhouse.com/v3/' + key + '/main/get-item/' + id + '/ar/json', { signal: ctrl.signal });
    } finally {
      clearTimeout(timer);
    }
    if (!r.ok) return Response.json({ error: 'upstream error' }, { status: 502, headers: CORS });
    const d = await r.json();
    const slim = {
      id: d.id,
      t: d.title,
      d: d.full_description || d.description || '',
      img: d.image,
      au: (d.prepared_by || []).map((p) => ({ n: p.title, k: p.kind || p.type })),
      at: (d.attachments || []).map((a) => ({ u: a.url, x: (a.extension_type || '').toUpperCase(), s: a.size, n: a.description })),
    };
    return Response.json(slim, { headers: { ...CORS, 'Cache-Control': 'public, max-age=604800' } });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 502, headers: CORS });
  }
});
