package com.abdelnaser.athar;

import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.service.notification.StatusBarNotification;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Capacitor plugin "AdhanAuto": the native side of the automatic adhan.
 *
 * JS calls via Capacitor.Plugins.AdhanAuto (a separate JS worker owns the
 * js/app.js side against this exact contract — method names and result
 * shapes must not change).
 *
 * Registered in MainActivity via registerPlugin(AdhanAutoPlugin.class)
 * BEFORE super.onCreate(): Capacitor 8 loads plugin classes from the
 * generated assets/capacitor.plugins.json (rewritten by `cap sync`) plus
 * classes registered on the Bridge builder, so an app-local plugin class
 * has no other registration path.
 *
 * The plugin only schedules/cancels exact alarms and reports phone state.
 * The actual firing happens in AdhanAlarmReceiver, which posts the
 * full-screen notification (see AdhanAutoStore.postAdhanNotification).
 * The LocalNotifications JS path keeps owning the 14-day schedule UI and
 * its own notifications; this plugin is the parallel native alarm path
 * that survives the app being killed.
 *
 * 2.6.3 crash hardening — READ BEFORE TOUCHING: Capacitor does NOT turn a
 * plugin-method exception into a rejected promise. In Bridge.callPluginMethod
 * the invocation runs on the CapacitorPlugins HandlerThread wrapped as
 * `catch (Exception ex) { Logger.error(...); throw new RuntimeException(ex); }`,
 * so an uncaught exception on that thread kills the whole Android process
 * and the JS try/catch around the call never runs. 2.6.2 crashed on open
 * for exactly this reason (most likely SecurityException from
 * setExactAndAllowWhileIdle when SCHEDULE_EXACT_ALARM is denied on
 * Android 14). THEREFORE: every @PluginMethod body below is wrapped in a
 * top-level try/catch that records a "native-crash" diagnostic event
 * (readable in the JS diagnostics log on the next successful launch) and
 * calls call.reject(...). NO Java exception may ever escape a @PluginMethod.
 * AdhanAutoStore.scheduleOne/cancelAll are likewise non-throwing.
 */
@CapacitorPlugin(name = "AdhanAuto")
public class AdhanAutoPlugin extends Plugin {

    /**
     * Crash-safe diagnostic: records the thrower (method + exception type +
     * message) in the native event queue so the JS diagnostics log names it
     * on the next successful launch. pushEvent() already catches Exception
     * internally; this wrapper also guards getContext() itself.
     */
    private void crashDiag(String method, Throwable t) {
        try {
            String msg = method + ": " + t.getClass().getSimpleName()
                    + ": " + String.valueOf(t.getMessage());
            AdhanAutoStore.pushEvent(getContext(), "native-crash", msg);
        } catch (Exception ignored) {
            // Diagnostics must never break the adhan path.
        }
    }

    /** Reject the call AND leave the crash diagnostic behind. */
    private void rejectSafe(PluginCall call, String method, Exception e) {
        crashDiag(method, e);
        try {
            call.reject(method + " failed: " + e.getClass().getSimpleName()
                    + ": " + String.valueOf(e.getMessage()), e);
        } catch (Exception ignored) {
            // call.reject itself must never throw out of a @PluginMethod.
        }
    }

    // ---- scheduleAlarms ----------------------------------------------------
    // scheduleAlarms({ alarms: [{id, key, at, title, body, channelId}] })
    // Replaces any previously persisted native alarms (cancel-before-
    // schedule), persists the new list, sets one exact alarm per future
    // item. Returns {scheduled:N, exact:bool, exactCount:N, inexactCount:N}.
    // exactCount counts alarms set with setExactAndAllowWhileIdle; inexactCount
    // counts alarms that fell back to setAndAllowWhileIdle after the exact
    // call threw (e.g. SCHEDULE_EXACT_ALARM denied) — those are still
    // scheduled, just inexact, so JS must NOT double-schedule them via LN.

    @PluginMethod
    public void scheduleAlarms(PluginCall call) {
        try {
            JSArray alarms = call.getArray("alarms");
            if (alarms == null) {
                call.reject("alarms array is required");
                return;
            }
            Context ctx = getContext();
            if (ctx == null) {
                call.reject("no context");
                return;
            }
            // Cancel the previous native list first so a re-schedule (new
            // prayer times, timezone change, settings change) never leaves
            // stale alarms behind.
            AdhanAutoStore.cancelAll(ctx);

            JSONArray list = new JSONArray();
            for (int i = 0; i < alarms.length(); i++) {
                JSONObject a = alarms.optJSONObject(i);
                if (a == null) continue;
                list.put(a);
            }
            AdhanAutoStore.saveAlarms(ctx, list);
            int scheduled = AdhanAutoStore.scheduleAll(ctx);
            boolean exact = AdhanAutoStore.canScheduleExact(ctx) || (scheduled > 0 && AdhanAutoStore.lastInexactCount == 0);
            AdhanAutoStore.pushEvent(ctx, "native-schedule",
                    "scheduled " + scheduled + " of " + list.length()
                            + " alarms (exact=" + exact
                            + ", exactCount=" + AdhanAutoStore.lastExactCount
                            + ", inexactCount=" + AdhanAutoStore.lastInexactCount + ")");
            JSObject out = new JSObject();
            out.put("scheduled", scheduled);
            out.put("exact", exact);
            out.put("exactCount", AdhanAutoStore.lastExactCount);
            out.put("inexactCount", AdhanAutoStore.lastInexactCount);
            call.resolve(out);
        } catch (Exception e) {
            rejectSafe(call, "scheduleAlarms", e);
        }
    }

    // ---- cancelAlarms ------------------------------------------------------
    // Cancels every persisted alarm and clears the list. {cancelled:N}

    @PluginMethod
    public void cancelAlarms(PluginCall call) {
        try {
            Context ctx = getContext();
            if (ctx == null) {
                call.reject("no context");
                return;
            }
            int cancelled = AdhanAutoStore.cancelAll(ctx);
            AdhanAutoStore.pushEvent(ctx, "native-cancel",
                    "cancelled " + cancelled + " alarms");
            JSObject out = new JSObject();
            out.put("cancelled", cancelled);
            call.resolve(out);
        } catch (Exception e) {
            rejectSafe(call, "cancelAlarms", e);
        }
    }

    // ---- testAutomatic -----------------------------------------------------
    // testAutomatic({ delayMs, key }): one-shot exact alarm in delayMs
    // posting the REAL full-screen notification (same receiver path as real
    // prayers). NOT persisted (a test must not survive a reboot).
    // Returns {ok, exact}: ok is the boolean returned by
    // AdhanAutoStore.scheduleOne (so JS can tell a failed test schedule
    // from a successful one), exact is canScheduleExact() at call time.

    @PluginMethod
    public void testAutomatic(PluginCall call) {
        try {
            long delayMs = call.getLong("delayMs", 10000L);
            String key = call.getString("key", "fajr");
            if (key == null || key.isEmpty()) key = "fajr";
            try {
                JSONObject alarm = new JSONObject();
                alarm.put("id", AdhanAutoStore.TEST_FSI_ID);
                alarm.put("key", key);
                alarm.put("at", System.currentTimeMillis() + delayMs);
                alarm.put("title", "تجربة الأذان التلقائي");
                alarm.put("body", "ستظهر شاشة الأذان تلقائياً عند قفل الهاتف");
                alarm.put("channelId", AdhanAutoStore.CHANNEL_VOICE);
                alarm.put("fsi", true);
                Context ctx = getContext();
                boolean ok = AdhanAutoStore.scheduleOne(ctx, alarm);
                AdhanAutoStore.pushEvent(ctx, "native-test",
                        "testAutomatic in " + delayMs + "ms key=" + key);
                JSObject out = new JSObject();
                out.put("ok", ok);
                out.put("exact", AdhanAutoStore.canScheduleExact(ctx));
                call.resolve(out);
            } catch (JSONException e) {
                call.reject("could not build test alarm", e);
            }
        } catch (Exception e) {
            rejectSafe(call, "testAutomatic", e);
        }
    }

    // ---- testDefaultSound --------------------------------------------------
    // testDefaultSound({ delayMs }): one-shot alarm posting on the control
    // channel adhan-test-default (importance HIGH, NO custom sound, so the
    // system default notification sound plays), WITHOUT a full-screen
    // intent — the only variable under test is the sound. If this sounds
    // and adhan-voice-v2 does not, the adhan_short.mp3 file / channel
    // sound is at fault; if neither sounds, the phone (ringer / DND /
    // volume) is. NOT persisted. Returns {ok, exact} (see testAutomatic).

    @PluginMethod
    public void testDefaultSound(PluginCall call) {
        try {
            long delayMs = call.getLong("delayMs", 10000L);
            try {
                JSONObject alarm = new JSONObject();
                alarm.put("id", AdhanAutoStore.TEST_DEFAULT_SOUND_ID);
                alarm.put("key", "fajr");
                alarm.put("at", System.currentTimeMillis() + delayMs);
                alarm.put("title", "اختبار صوت التنبيه الافتراضي");
                alarm.put("body", "إن سمعت صوتاً فالهاتف سليم والمشكلة في صوت قناة الأذان");
                alarm.put("channelId", AdhanAutoStore.CHANNEL_TEST_DEFAULT);
                alarm.put("fsi", false);
                Context ctx = getContext();
                boolean ok = AdhanAutoStore.scheduleOne(ctx, alarm);
                AdhanAutoStore.pushEvent(ctx, "native-test",
                        "testDefaultSound in " + delayMs + "ms");
                JSObject out = new JSObject();
                out.put("ok", ok);
                out.put("exact", AdhanAutoStore.canScheduleExact(ctx));
                call.resolve(out);
            } catch (JSONException e) {
                call.reject("could not build test alarm", e);
            }
        } catch (Exception e) {
            rejectSafe(call, "testDefaultSound", e);
        }
    }

    // ---- getPhoneState -----------------------------------------------------
    // { ringerMode, interruptionFilter, policyAccess, notificationsEnabled,
    //   exactAlarm, fullScreenAllowed, fsiSettingsAvailable, notifVolume, notifVolumeMax,
    //   batteryOptimized }
    // batteryOptimized is PowerManager.isIgnoringBatteryOptimizations(package)
    // — true when the app is exempt from battery optimization (the
    // "unrestricted" state that lets alarms fire on time on OEM builds
    // like Infinix/XOS), false when it is subject to optimization, null
    // when the read is unavailable or throws. Every system-service read
    // is guarded individually: a read that throws leaves its field at
    // "unknown"/default/null instead of killing the process.
    // This is the earliest native call at boot, so it must never throw.

    @PluginMethod
    public void getPhoneState(PluginCall call) {
        try {
            Context ctx = getContext();
            AudioManager am = null;
            NotificationManager nm = null;
            if (ctx != null) {
                try {
                    am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
                } catch (Exception e) {
                    crashDiag("getPhoneState:AudioManager", e);
                }
                try {
                    nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
                } catch (Exception e) {
                    crashDiag("getPhoneState:NotificationManager", e);
                }
            }

            String ringerMode = "unknown";
            int notifVolume = -1;
            int notifVolumeMax = -1;
            if (am != null) {
                try {
                    switch (am.getRingerMode()) {
                        case AudioManager.RINGER_MODE_NORMAL: ringerMode = "normal"; break;
                        case AudioManager.RINGER_MODE_SILENT: ringerMode = "silent"; break;
                        case AudioManager.RINGER_MODE_VIBRATE: ringerMode = "vibrate"; break;
                        default: ringerMode = "unknown"; break;
                    }
                } catch (Exception e) {
                    crashDiag("getPhoneState:getRingerMode", e);
                }
                try {
                    notifVolume = am.getStreamVolume(AudioManager.STREAM_NOTIFICATION);
                } catch (Exception e) {
                    crashDiag("getPhoneState:getStreamVolume", e);
                }
                try {
                    notifVolumeMax = am.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION);
                } catch (Exception e) {
                    crashDiag("getPhoneState:getStreamMaxVolume", e);
                }
            }

            String interruptionFilter = "unknown";
            boolean policyAccess = false;
            boolean notificationsEnabled = false;
            boolean fullScreenAllowed = true;
            if (nm != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    try {
                        switch (nm.getCurrentInterruptionFilter()) {
                            case NotificationManager.INTERRUPTION_FILTER_ALL: interruptionFilter = "all"; break;
                            case NotificationManager.INTERRUPTION_FILTER_PRIORITY: interruptionFilter = "priority"; break;
                            case NotificationManager.INTERRUPTION_FILTER_NONE: interruptionFilter = "none"; break;
                            case NotificationManager.INTERRUPTION_FILTER_ALARMS: interruptionFilter = "alarms"; break;
                            default: interruptionFilter = "unknown"; break;
                        }
                    } catch (Exception e) {
                        crashDiag("getPhoneState:getCurrentInterruptionFilter", e);
                    }
                    try {
                        policyAccess = nm.isNotificationPolicyAccessGranted();
                    } catch (Exception e) {
                        crashDiag("getPhoneState:isNotificationPolicyAccessGranted", e);
                    }
                }
                try {
                    // areNotificationsEnabled() exists since API 24 = this app's minSdk.
                    notificationsEnabled = nm.areNotificationsEnabled();
                } catch (Exception e) {
                    crashDiag("getPhoneState:areNotificationsEnabled", e);
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    try {
                        fullScreenAllowed = nm.canUseFullScreenIntent();
                    } catch (Exception e) {
                        crashDiag("getPhoneState:canUseFullScreenIntent", e);
                    }
                }
            }

            boolean exactAlarm = false;
            try {
                exactAlarm = ctx != null && AdhanAutoStore.canScheduleExact(ctx);
            } catch (Exception e) {
                crashDiag("getPhoneState:canScheduleExact", e);
            }

            // 2.6.4: battery-optimization exemption for this app. Null when
            // unreadable (no PowerManager, no package name, or the read
            // throws) — the field is emitted as JSON null, not omitted.
            Boolean batteryOptimized = null;
            try {
                if (ctx != null) {
                    PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
                    if (pm != null) {
                        batteryOptimized = pm.isIgnoringBatteryOptimizations(ctx.getPackageName());
                    }
                }
            } catch (Exception e) {
                crashDiag("getPhoneState:isIgnoringBatteryOptimizations", e);
            }

            JSObject out = new JSObject();
            out.put("ringerMode", ringerMode);
            out.put("interruptionFilter", interruptionFilter);
            out.put("policyAccess", policyAccess);
            out.put("notificationsEnabled", notificationsEnabled);
            out.put("exactAlarm", exactAlarm);
            out.put("fullScreenAllowed", fullScreenAllowed);
            out.put("fsiSettingsAvailable", Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE);
            out.put("notifVolume", notifVolume);
            out.put("notifVolumeMax", notifVolumeMax);
            out.put("batteryOptimized", batteryOptimized == null
                    ? JSONObject.NULL : batteryOptimized);
            call.resolve(out);
        } catch (Exception e) {
            rejectSafe(call, "getPhoneState", e);
        }
    }

    // ---- getActiveAdhan ----------------------------------------------------
    // Inspects live notifications for a full-screen adhan notification
    // (tag "adhan-fsi", set when posting). Returns {key, at, id}, or
    // {key:null, at:null, id:null} when none is active. A notification in
    // the adhan id range (1..145, or test ids 5000..5002) without our tag
    // is reported as a fallback with key null and at = its post time.
    // getNotification() and extras are null-checked: either may be null
    // for a posted notification on some OEM builds.

    @PluginMethod
    public void getActiveAdhan(PluginCall call) {
        try {
            Context ctx = getContext();
            NotificationManager nm = null;
            if (ctx != null) {
                try {
                    nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
                } catch (Exception e) {
                    crashDiag("getActiveAdhan:NotificationManager", e);
                }
            }
            JSObject out = new JSObject();
            if (nm != null) {
                StatusBarNotification fallback = null;
                StatusBarNotification[] active = null;
                try {
                    active = nm.getActiveNotifications();
                } catch (Exception e) {
                    crashDiag("getActiveAdhan:getActiveNotifications", e);
                }
                if (active != null) {
                    for (StatusBarNotification sbn : active) {
                        if (sbn == null) continue;
                        if (AdhanAutoStore.FSI_TAG.equals(sbn.getTag())) {
                            android.app.Notification notif = null;
                            try {
                                notif = sbn.getNotification();
                            } catch (Exception e) {
                                crashDiag("getActiveAdhan:getNotification", e);
                            }
                            android.os.Bundle extras = notif != null ? notif.extras : null;
                            out.put("key", extras != null ? extras.getString("adhan_key") : null);
                            out.put("at", extras != null ? extras.getLong("adhan_at", sbn.getPostTime()) : sbn.getPostTime());
                            out.put("id", sbn.getId());
                            call.resolve(out);
                            return;
                        }
                        int id = sbn.getId();
                        if ((id >= 1 && id <= 145) || (id >= 5000 && id <= 5002)) {
                            if (fallback == null || sbn.getPostTime() > fallback.getPostTime()) {
                                fallback = sbn;
                            }
                        }
                    }
                }
                if (fallback != null) {
                    android.app.Notification notif = null;
                    try {
                        notif = fallback.getNotification();
                    } catch (Exception e) {
                        crashDiag("getActiveAdhan:getNotification(fallback)", e);
                    }
                    android.os.Bundle extras = notif != null ? notif.extras : null;
                    String key = extras != null ? extras.getString("adhan_key") : null;
                    out.put("key", key);
                    out.put("at", extras != null && extras.containsKey("adhan_at")
                            ? extras.getLong("adhan_at") : fallback.getPostTime());
                    out.put("id", fallback.getId());
                    call.resolve(out);
                    return;
                }
            }
            out.put("key", JSONObject.NULL);
            out.put("at", JSONObject.NULL);
            out.put("id", JSONObject.NULL);
            call.resolve(out);
        } catch (Exception e) {
            rejectSafe(call, "getActiveAdhan", e);
        }
    }

    // ---- consumePendingRoute -----------------------------------------------
    // Reads + clears the pending route written by the receiver when an
    // alarm fired (so JS can open the adhan screen on a cold start even
    // if no tap event arrived). {route, key, at}, or all-null when none.

    @PluginMethod
    public void consumePendingRoute(PluginCall call) {
        try {
            JSONObject pending = AdhanAutoStore.consumePendingRoute(getContext());
            JSObject out = new JSObject();
            if (pending == null) {
                out.put("route", JSONObject.NULL);
                out.put("key", JSONObject.NULL);
                out.put("at", JSONObject.NULL);
            } else {
                out.put("route", pending.optString("route", null));
                out.put("key", pending.optString("key", null));
                out.put("at", pending.optLong("at", 0));
            }
            call.resolve(out);
        } catch (Exception e) {
            rejectSafe(call, "consumePendingRoute", e);
        }
    }

    // ---- openNotificationSettings ------------------------------------------
    // Opens the system per-app notification settings screen.

    @PluginMethod
    public void openNotificationSettings(PluginCall call) {
        try {
            Context ctx = getContext();
            if (ctx == null) {
                call.reject("no context");
                return;
            }
            Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, ctx.getPackageName());
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (ctx.getPackageManager() != null
                    && intent.resolveActivity(ctx.getPackageManager()) == null) {
                call.reject("no activity handles notification settings");
                return;
            }
            ctx.startActivity(intent);
            call.resolve();
        } catch (ActivityNotFoundException e) {
            rejectSafe(call, "openNotificationSettings", e);
        } catch (Exception e) {
            rejectSafe(call, "openNotificationSettings", e);
        }
    }

    // ---- openFullScreenIntentSettings --------------------------------------
    // (Addition beyond the coordinator contract, same pattern as
    // openNotificationSettings.) Opens the system "Full-screen
    // notifications" special-access screen for this app (API 34+), so the
    // user can grant USE_FULL_SCREEN_INTENT when canUseFullScreenIntent()
    // is false. Below API 34 the permission is a normal install-time
    // grant and there is no such screen — resolves without doing anything.

    @PluginMethod
    public void openFullScreenIntentSettings(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                Context ctx = getContext();
                if (ctx == null) {
                    call.reject("no context");
                    return;
                }
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT);
                intent.setData(Uri.parse("package:" + ctx.getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                PackageManager pm = ctx.getPackageManager();
                if (pm != null && intent.resolveActivity(pm) == null) {
                    call.reject("no activity handles full-screen intent settings");
                    return;
                }
                ctx.startActivity(intent);
            }
            call.resolve();
        } catch (ActivityNotFoundException e) {
            rejectSafe(call, "openFullScreenIntentSettings", e);
        } catch (Exception e) {
            rejectSafe(call, "openFullScreenIntentSettings", e);
        }
    }

    // ---- setNotificationVolume -------------------------------------------
    // 2.6.4: setNotificationVolume({ level }): sets ONLY the notification
    // stream (AudioManager.STREAM_NOTIFICATION) to the given level, with
    // FLAG_SHOW_UI so the user sees the system volume panel for the
    // change. Explicit user action only — JS calls this solely from a
    // button tap ("make the notification sound loud"); it is never called
    // at boot, on a schedule, or from any background path, and it never
    // touches any other stream. Returns {volume, max} read back from the
    // system AFTER setting, so the caller sees what actually took effect
    // (on some devices the notification stream follows the ring stream
    // and the read-back may differ from the request). Guarded like every
    // other @PluginMethod: failure rejects, never throws.

    @PluginMethod
    public void setNotificationVolume(PluginCall call) {
        try {
            Context ctx = getContext();
            if (ctx == null) {
                call.reject("no context");
                return;
            }
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am == null) {
                call.reject("no AudioManager");
                return;
            }
            int level = call.getInt("level", -1);
            if (level < 0) {
                call.reject("level is required");
                return;
            }
            int max = am.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION);
            if (level > max) level = max;
            am.setStreamVolume(AudioManager.STREAM_NOTIFICATION, level,
                    AudioManager.FLAG_SHOW_UI);
            JSObject out = new JSObject();
            out.put("volume", am.getStreamVolume(AudioManager.STREAM_NOTIFICATION));
            out.put("max", max);
            call.resolve(out);
        } catch (Exception e) {
            rejectSafe(call, "setNotificationVolume", e);
        }
    }

    // ---- openSoundSettings -------------------------------------------------
    // 2.6.4: opens the system Sound settings screen (same
    // resolveActivity + ActivityNotFoundException pattern as
    // openNotificationSettings), so the user can adjust notification /
    // ring volume and sounds by hand. Resolves when the screen opens.

    @PluginMethod
    public void openSoundSettings(PluginCall call) {
        try {
            Context ctx = getContext();
            if (ctx == null) {
                call.reject("no context");
                return;
            }
            Intent intent = new Intent(Settings.ACTION_SOUND_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (ctx.getPackageManager() != null
                    && intent.resolveActivity(ctx.getPackageManager()) == null) {
                call.reject("no activity handles sound settings");
                return;
            }
            ctx.startActivity(intent);
            call.resolve();
        } catch (ActivityNotFoundException e) {
            rejectSafe(call, "openSoundSettings", e);
        } catch (Exception e) {
            rejectSafe(call, "openSoundSettings", e);
        }
    }

    // ---- drainNativeEvents -------------------------------------------------
    // Returns {events: [{type, msg, at}, ...]} from the native queue and
    // clears it. JS merges these into the yaqeen:adhan-diag log.

    @PluginMethod
    public void drainNativeEvents(PluginCall call) {
        try {
            JSONArray events = AdhanAutoStore.drainEvents(getContext());
            JSObject out = new JSObject();
            try {
                out.put("events", new JSArray(events.toString()));
            } catch (JSONException e) {
                out.put("events", new JSArray());
            }
            call.resolve(out);
        } catch (Exception e) {
            rejectSafe(call, "drainNativeEvents", e);
        }
    }
}
