package com.abdelnaser.athar;

import android.app.KeyguardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.view.WindowManager;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // AdhanAuto is an app-local plugin class, not an npm dependency, so
        // Capacitor's generated capacitor.plugins.json cannot list it.
        // It must be registered on the Bridge builder BEFORE super.onCreate()
        // creates the Bridge; registering later has no effect.
        registerPlugin(AdhanAutoPlugin.class);
        super.onCreate(savedInstanceState);
        // 2.6.4: let the adhan screen show over the lock screen. Without
        // this, a full-screen intent can only bring the app to the
        // foreground behind the keyguard (or not at all on some OEM
        // builds), so the user sees nothing until they unlock.
        // setShowWhenLocked/setTurnScreenOn exist since API 27; below
        // that the equivalent window flags are used. Guarded: a failure
        // here must never break launch (2.6.3 hardening — no exception
        // may escape the startup path).
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                setShowWhenLocked(true);
                setTurnScreenOn(true);
            } else {
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                        | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
            }
        } catch (Exception ignored) {
            // Lock-screen flags are best-effort; launch must continue.
        }
        recordAdhanLaunch(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        recordAdhanLaunch(intent);
    }

    /**
     * 2.6.4 diagnostic: when the activity is launched (cold start or
     * onNewIntent via singleTask) from an adhan deep link
     * (athar://open?r=adhan/&lt;key&gt;), record a "fsi-activity-launched"
     * native event with the lock state at launch time. This is the only
     * proof of whether the full-screen intent actually launched the
     * activity over the lock screen: the receiver can only prove it
     * posted the notification ("fsi-launch"), not that the system
     * honoured it. Guarded end to end — diagnostics must never break
     * launch.
     */
    private void recordAdhanLaunch(Intent intent) {
        try {
            if (intent == null) return;
            Uri data = intent.getData();
            if (data == null) return;
            String route = data.getQueryParameter("r");
            if (route == null || !route.startsWith("adhan/")) return;
            String key = route.substring("adhan/".length());
            boolean keyguardLocked = false;
            boolean deviceLocked = false;
            boolean interactive = true;
            try {
                KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
                if (km != null) {
                    keyguardLocked = km.isKeyguardLocked();
                    deviceLocked = km.isDeviceLocked();
                }
            } catch (Exception ignored) {
                // Lock state stays at the defaults above.
            }
            try {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null) interactive = pm.isInteractive();
            } catch (Exception ignored) {
                // Interactive stays at the default above.
            }
            AdhanAutoStore.pushEvent(this, "fsi-activity-launched",
                    "route=" + route + " keyguardLocked=" + keyguardLocked
                            + " deviceLocked=" + deviceLocked
                            + " interactive=" + interactive);
        } catch (Exception ignored) {
            // Diagnostics must never break launch.
        }
    }
}
