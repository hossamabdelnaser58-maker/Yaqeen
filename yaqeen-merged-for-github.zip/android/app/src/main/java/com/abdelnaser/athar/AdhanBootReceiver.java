package com.abdelnaser.athar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Re-schedules all persisted native adhan alarms after a reboot.
 * AlarmManager alarms do not survive a reboot, so without this the
 * automatic adhan would silently stop after the phone restarts.
 *
 * Manifest-registered with a BOOT_COMPLETED intent-filter, exported=true
 * (required: BOOT_COMPLETED is a system broadcast, and API 31+ requires
 * an explicit android:exported on every component with an intent-filter).
 * RECEIVE_BOOT_COMPLETED is already declared in the manifest. Note the app
 * must have been launched at least once before the system will deliver
 * BOOT_COMPLETED to it.
 */
public class AdhanBootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;

        // 2.6.3: scheduleAll() is non-throwing, but a receiver must never
        // throw either — guard it so a boot-time failure can only be
        // recorded, never crash the (not yet started) app process.
        try {
            int rescheduled = AdhanAutoStore.scheduleAll(context);
            AdhanAutoStore.pushEvent(context, "native-boot",
                    "boot completed: rescheduled " + rescheduled + " alarms");
        } catch (Exception e) {
            AdhanAutoStore.pushEvent(context, "native-crash",
                    "AdhanBootReceiver: " + e.getClass().getSimpleName()
                            + ": " + String.valueOf(e.getMessage()));
        }
    }
}
