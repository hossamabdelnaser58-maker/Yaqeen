package com.abdelnaser.athar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;

/**
 * Fires when an exact adhan alarm goes off (AlarmManager, RTC_WAKEUP —
 * wakes the device from Doze). Posts the full-screen adhan notification
 * via AdhanAutoStore and records the pending route, then returns
 * immediately: posting a notification is fast, and no sound is played
 * here (the notification channel sound is the mechanism — playing it
 * again would double it).
 *
 * 2.6.4: holds a PARTIAL_WAKE_LOCK (10 s timeout, backstop for the
 * release in finally) while posting, so the device cannot fall back
 * asleep between the alarm firing and the notification being posted on
 * a locked/Doze device. The whole body is wrapped in try/catch and
 * never throws (2.6.3 hardening — an uncaught exception in a receiver
 * is recorded, never propagated).
 *
 * Manifest-registered, exported=false, no intent-filter: the PendingIntent
 * is explicit (component + FLAG_IMMUTABLE), so no other app can trigger it.
 */
public class AdhanAlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        PowerManager.WakeLock wl = null;
        try {
            if (intent == null) return;
            if (!AdhanAutoStore.ACTION_ADHAN_ALARM.equals(intent.getAction())) return;

            int id = intent.getIntExtra("id", 0);
            String key = intent.getStringExtra("key");
            if (key == null || key.isEmpty()) return;
            long at = intent.getLongExtra("at", System.currentTimeMillis());
            String title = intent.getStringExtra("title");
            String body = intent.getStringExtra("body");
            String channelId = intent.getStringExtra("channelId");
            boolean fsi = intent.getBooleanExtra("fsi", true);

            // 2.6.4: keep the CPU awake while the notification posts.
            // Guarded: a wake-lock failure must not drop the adhan.
            try {
                if (context != null) {
                    PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                    if (pm != null) {
                        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                                "Yaqeen:AdhanAlarm");
                        wl.setReferenceCounted(false);
                        wl.acquire(10 * 1000L);
                    }
                }
            } catch (Exception e) {
                AdhanAutoStore.pushEvent(context, "native-crash",
                        "AdhanAlarmReceiver:wakeLock: " + e.getClass().getSimpleName()
                                + ": " + String.valueOf(e.getMessage()));
                wl = null;
            }

            AdhanAutoStore.postAdhanNotification(context, id, key, at, title, body, channelId, fsi);
        } catch (Exception e) {
            try {
                AdhanAutoStore.pushEvent(context, "native-crash",
                        "AdhanAlarmReceiver: " + e.getClass().getSimpleName()
                                + ": " + String.valueOf(e.getMessage()));
            } catch (Exception ignored) {
                // Diagnostics must never throw out of a receiver.
            }
        } finally {
            try {
                if (wl != null && wl.isHeld()) wl.release();
            } catch (Exception ignored) {
                // Release failure is harmless (the 10 s timeout is the backstop).
            }
        }
    }
}
