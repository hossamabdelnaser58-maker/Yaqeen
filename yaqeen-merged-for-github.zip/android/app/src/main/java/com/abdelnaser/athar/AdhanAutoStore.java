package com.abdelnaser.athar;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Shared native helpers for the automatic adhan (full-screen intent) path.
 *
 * Two independent notification paths exist in Yaqeen 2.6.1+:
 *  - LocalNotifications (JS, Capacitor plugin): schedules the 14-day prayer
 *    notifications on channels adhan-voice-v2 / adhan-beep-v2 / adhan-silent-v2.
 *  - This native path (AdhanAutoPlugin + AdhanAlarmReceiver): exact
 *    AlarmManager alarms that post a full-screen-intent notification on the
 *    SAME channels, so the adhan screen opens automatically over the lock
 *    screen even when the app is killed.
 *
 * Sound is NEVER played from code here. The channel sound is the mechanism:
 * adhan-voice-v2 plays res/raw/adhan_short.mp3 (30 s) by channel definition,
 * exactly as the LocalNotifications path does. Playing sound a second time
 * would double it.
 *
 * Android channels are immutable once created: ensureChannel() only creates
 * a channel when it does not exist yet, using the exact same parameters the
 * JS side (js/app.js ADHAN_CHANNELS) uses. If a channel already exists with
 * a wrong configuration it cannot be repaired from code.
 */
public final class AdhanAutoStore {

    private AdhanAutoStore() {}

    // ---- SharedPreferences -------------------------------------------------

    /** Persisted alarm list (JSON array string under KEY_ALARMS). */
    public static final String PREFS_ALARMS = "adhan-auto-alarms";
    private static final String KEY_ALARMS = "alarms";

    /** Pending route + native diagnostic event queue. */
    public static final String PREFS_STATE = "adhan-auto";
    private static final String KEY_PENDING_ROUTE = "pending_route";
    private static final String KEY_PENDING_KEY = "pending_key";
    private static final String KEY_PENDING_AT = "pending_at";
    private static final String KEY_EVENTS = "events";
    private static final int MAX_EVENTS = 100;

    // ---- Channels (must match js/app.js ADHAN_CHANNELS) --------------------

    public static final String CHANNEL_VOICE = "adhan-voice-v2";
    public static final String CHANNEL_BEEP = "adhan-beep-v2";
    public static final String CHANNEL_SILENT = "adhan-silent-v2";
    /** Control-test channel: importance HIGH, NO custom sound, so the system
     *  default notification sound plays. If this sounds but the voice
     *  channel does not, the file/channel sound is the problem; if neither
     *  sounds, the phone (ringer / DND / volume) is the problem. */
    public static final String CHANNEL_TEST_DEFAULT = "adhan-test-default";

    /** Tag set on every full-screen adhan notification we post, so
     *  getActiveAdhan() can find it among all active notifications. */
    public static final String FSI_TAG = "adhan-fsi";

    /** Explicit action for alarm intents (the intent is explicit by
     *  component anyway; the action only aids debugging). */
    public static final String ACTION_ADHAN_ALARM = "com.abdelnaser.athar.ADHAN_ALARM";

    /** Test notification ids. 5000 is the JS testAdhan() (LocalNotifications)
     *  id, so the native tests use 5001/5002 to avoid colliding with it. */
    public static final int TEST_FSI_ID = 5001;
    public static final int TEST_DEFAULT_SOUND_ID = 5002;

    public static final int FLAGS_IMMUTABLE_UPDATE =
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
    public static final int FLAGS_IMMUTABLE_NO_CREATE =
            PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE;

    // ---- Alarm persistence -------------------------------------------------

    public static JSONArray loadAlarms(Context ctx) {
        try {
            if (ctx == null) return new JSONArray();
            String raw = ctx.getSharedPreferences(PREFS_ALARMS, Context.MODE_PRIVATE)
                    .getString(KEY_ALARMS, null);
            if (raw == null || raw.isEmpty()) return new JSONArray();
            return new JSONArray(raw);
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static void saveAlarms(Context ctx, JSONArray alarms) {
        if (ctx == null) return;
        ctx.getSharedPreferences(PREFS_ALARMS, Context.MODE_PRIVATE)
                .edit().putString(KEY_ALARMS, alarms.toString()).apply();
    }

    // ---- Alarm scheduling --------------------------------------------------

    /** Counts from the most recent scheduleAll() run: how many alarms were
     *  set exactly vs fell back to inexact after the exact call threw.
     *  Read by AdhanAutoPlugin.scheduleAlarms so JS can tell a partial
     *  exact-denial (still scheduled, no LN double-scheduling) from a
     *  total failure (scheduled == 0, LN fallback is safe). */
    public static int lastExactCount = 0;
    public static int lastInexactCount = 0;

    public static boolean canScheduleExact(Context ctx) {
        try {
            if (ctx == null) return false;
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            return am != null && am.canScheduleExactAlarms();
        } catch (Exception e) {
            return false;
        }
    }

    /** Build the broadcast PendingIntent for one persisted alarm object.
     *  requestCode = alarm id, so every prayer has a distinct PendingIntent. */
    public static PendingIntent alarmPendingIntent(Context ctx, JSONObject alarm, int flags) {
        try {
            Intent intent = new Intent(ctx, AdhanAlarmReceiver.class);
            intent.setAction(ACTION_ADHAN_ALARM);
            intent.putExtra("id", alarm.optInt("id", 0));
            intent.putExtra("key", alarm.optString("key", ""));
            intent.putExtra("at", alarm.optLong("at", 0));
            intent.putExtra("title", alarm.optString("title", ""));
            intent.putExtra("body", alarm.optString("body", ""));
            intent.putExtra("channelId", alarm.optString("channelId", CHANNEL_VOICE));
            intent.putExtra("fsi", alarm.optBoolean("fsi", true));
            return PendingIntent.getBroadcast(ctx, alarm.optInt("id", 0), intent, flags);
        } catch (Exception e) {
            return null;
        }
    }

    /** Last-resort precise path: setAlarmClock needs no exact-alarm permission and
     *  fires on time even in Doze, so the adhan is never silently delayed. */
    private static boolean setClockAlarm(Context ctx, AlarmManager am, long at, PendingIntent pi) {
        try {
            Intent show = new Intent(ctx, MainActivity.class);
            show.setAction(Intent.ACTION_MAIN);
            PendingIntent showPi = PendingIntent.getActivity(ctx, 7001, show, FLAGS_IMMUTABLE_UPDATE);
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, showPi), pi);
            lastExactCount++;
            return true;
        } catch (Exception e) {
            pushEvent(ctx, "native-crash", "setClockAlarm: " + e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage()));
            return false;
        }
    }

    /**
     * Schedule one alarm. Past times are skipped (returns false).
     * Exact when allowed (setExactAndAllowWhileIdle, RTC_WAKEUP, fires in
     * Doze); otherwise inexact setAndAllowWhileIdle.
     *
     * 2.6.3 — NEVER THROWS. On Android 14 SCHEDULE_EXACT_ALARM is denied
     * by default for newly installed apps targeting API 33+, and setExact*
     * throws SecurityException without it — the check-then-act guard in
     * canScheduleExact() cannot prevent that (access can be revoked between
     * check and call, and OEM builds can disagree with the guard). The
     * SecurityException is caught here, the alarm falls back to
     * setAndAllowWhileIdle, and the denial is recorded in the diagnostic
     * queue so the next launch names it. A throw here used to escape
     * through the plugin and kill the whole process on open (2.6.2).
     */
    public static boolean scheduleOne(Context ctx, JSONObject alarm) {
        try {
            if (ctx == null || alarm == null) return false;
            long at = alarm.optLong("at", 0);
            if (at <= System.currentTimeMillis()) return false;
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return false;
            PendingIntent pi = alarmPendingIntent(ctx, alarm, FLAGS_IMMUTABLE_UPDATE);
            if (pi == null) return false;
            if (canScheduleExact(ctx)) {
                try {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                    lastExactCount++;
                } catch (SecurityException e) {
                    // Exact denied despite the guard (2.6.2 crash cause):
                    // fall back to inexact for this alarm, never throw.
                    pushEvent(ctx, "native-exact-denied",
                            "setExactAndAllowWhileIdle threw SecurityException for id="
                                    + alarm.optInt("id", 0) + " key=" + alarm.optString("key", "")
                                    + ": " + String.valueOf(e.getMessage())
                                    + " — fell back to setAndAllowWhileIdle");
                    if (setClockAlarm(ctx, am, at, pi)) return true;
                    try {
                        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                        lastInexactCount++;
                    } catch (Exception e2) {
                        pushEvent(ctx, "native-crash",
                                "scheduleOne:inexact-fallback: " + e2.getClass().getSimpleName()
                                        + ": " + String.valueOf(e2.getMessage()));
                        return false;
                    }
                } catch (Exception e) {
                    pushEvent(ctx, "native-crash",
                            "scheduleOne:setExact: " + e.getClass().getSimpleName()
                                    + ": " + String.valueOf(e.getMessage()));
                    try {
                        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                        lastInexactCount++;
                    } catch (Exception e2) {
                        return false;
                    }
                }
            } else if (setClockAlarm(ctx, am, at, pi)) {
                return true;
            } else {
                try {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                    lastInexactCount++;
                } catch (Exception e) {
                    pushEvent(ctx, "native-crash",
                            "scheduleOne:setAndAllowWhileIdle: " + e.getClass().getSimpleName()
                                    + ": " + String.valueOf(e.getMessage()));
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            pushEvent(ctx, "native-crash",
                    "scheduleOne: " + e.getClass().getSimpleName()
                            + ": " + String.valueOf(e.getMessage()));
            return false;
        }
    }

    /** Schedule every future alarm in the persisted list. Returns how many
     *  were actually scheduled (past ones are skipped, not counted).
     *  One bad alarm never aborts the rest, and this method never throws. */
    public static int scheduleAll(Context ctx) {
        lastExactCount = 0;
        lastInexactCount = 0;
        int n = 0;
        try {
            JSONArray alarms = loadAlarms(ctx);
            for (int i = 0; i < alarms.length(); i++) {
                try {
                    JSONObject a = alarms.optJSONObject(i);
                    if (a != null && scheduleOne(ctx, a)) n++;
                } catch (Exception e) {
                    pushEvent(ctx, "native-crash",
                            "scheduleAll: " + e.getClass().getSimpleName()
                                    + ": " + String.valueOf(e.getMessage()));
                }
            }
        } catch (Exception e) {
            pushEvent(ctx, "native-crash",
                    "scheduleAll: " + e.getClass().getSimpleName()
                            + ": " + String.valueOf(e.getMessage()));
        }
        return n;
    }

    /** Cancel every persisted alarm's PendingIntent and clear the list.
     *  Returns how many PendingIntents actually existed. Never throws:
     *  a failing cancel must not kill the app at boot. */
    public static int cancelAll(Context ctx) {
        int n = 0;
        try {
            if (ctx == null) return 0;
            JSONArray alarms = loadAlarms(ctx);
            AlarmManager am = null;
            try {
                am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            } catch (Exception e) {
                pushEvent(ctx, "native-crash",
                        "cancelAll:AlarmManager: " + e.getClass().getSimpleName()
                                + ": " + String.valueOf(e.getMessage()));
            }
            if (am != null) {
                for (int i = 0; i < alarms.length(); i++) {
                    try {
                        JSONObject a = alarms.optJSONObject(i);
                        if (a == null) continue;
                        PendingIntent pi = alarmPendingIntent(ctx, a, FLAGS_IMMUTABLE_NO_CREATE);
                        if (pi != null) {
                            try {
                                am.cancel(pi);
                            } catch (Exception e) {
                                pushEvent(ctx, "native-crash",
                                        "cancelAll:am.cancel: " + e.getClass().getSimpleName()
                                                + ": " + String.valueOf(e.getMessage()));
                            }
                            try {
                                pi.cancel();
                            } catch (Exception ignored) {
                            }
                            n++;
                        }
                    } catch (Exception e) {
                        pushEvent(ctx, "native-crash",
                                "cancelAll: " + e.getClass().getSimpleName()
                                        + ": " + String.valueOf(e.getMessage()));
                    }
                }
            }
            try {
                saveAlarms(ctx, new JSONArray());
            } catch (Exception ignored) {
            }
        } catch (Exception e) {
            pushEvent(ctx, "native-crash",
                    "cancelAll: " + e.getClass().getSimpleName()
                            + ": " + String.valueOf(e.getMessage()));
        }
        return n;
    }

    // ---- Pending route (cold start: alarm fired while app was dead) --------

    /** Written by the receiver when it posts; read+cleared by JS on launch
     *  so the app can open the adhan screen even if no tap event arrives. */
    public static void setPendingRoute(Context ctx, String route, String key, long at) {
        ctx.getSharedPreferences(PREFS_STATE, Context.MODE_PRIVATE).edit()
                .putString(KEY_PENDING_ROUTE, route)
                .putString(KEY_PENDING_KEY, key)
                .putLong(KEY_PENDING_AT, at)
                .apply();
    }

    /** Returns {route, key, at} or null, and clears the stored value. */
    public static JSONObject consumePendingRoute(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS_STATE, Context.MODE_PRIVATE);
        String route = prefs.getString(KEY_PENDING_ROUTE, null);
        if (route == null) return null;
        try {
            JSONObject out = new JSONObject();
            out.put("route", route);
            out.put("key", prefs.getString(KEY_PENDING_KEY, ""));
            out.put("at", prefs.getLong(KEY_PENDING_AT, 0));
            return out;
        } catch (JSONException e) {
            return null;
        } finally {
            prefs.edit()
                    .remove(KEY_PENDING_ROUTE)
                    .remove(KEY_PENDING_KEY)
                    .remove(KEY_PENDING_AT)
                    .apply();
        }
    }

    // ---- Native diagnostic event queue -------------------------------------

    /** Append {type, msg, at} (cap MAX_EVENTS, oldest dropped). Read by
     *  drainNativeEvents() and merged into the JS diagnostics log. */
    public static void pushEvent(Context ctx, String type, String msg) {
        try {
            SharedPreferences prefs = ctx.getSharedPreferences(PREFS_STATE, Context.MODE_PRIVATE);
            JSONArray events;
            try {
                String raw = prefs.getString(KEY_EVENTS, null);
                events = (raw == null || raw.isEmpty()) ? new JSONArray() : new JSONArray(raw);
            } catch (JSONException e) {
                events = new JSONArray();
            }
            JSONObject ev = new JSONObject();
            ev.put("type", type);
            ev.put("msg", msg == null ? "" : msg);
            ev.put("at", System.currentTimeMillis());
            events.put(ev);
            while (events.length() > MAX_EVENTS) events.remove(0);
            prefs.edit().putString(KEY_EVENTS, events.toString()).apply();
        } catch (Exception ignored) {
            // Diagnostics must never break the adhan path.
        }
    }

    /** Return all queued events and clear the queue. */
    public static JSONArray drainEvents(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS_STATE, Context.MODE_PRIVATE);
        JSONArray events;
        try {
            String raw = prefs.getString(KEY_EVENTS, null);
            events = (raw == null || raw.isEmpty()) ? new JSONArray() : new JSONArray(raw);
        } catch (JSONException e) {
            events = new JSONArray();
        }
        prefs.edit().remove(KEY_EVENTS).apply();
        return events;
    }

    // ---- Channels ----------------------------------------------------------

    /**
     * Create the channel if it does not exist yet, with the exact parameters
     * the JS side uses (js/app.js ADHAN_CHANNELS). Importance ints are the
     * raw Android values: 5 = IMPORTANCE_HIGH, 4 = IMPORTANCE_DEFAULT,
     * 2 = IMPORTANCE_MIN. A channel that already exists is left untouched
     * (Android channels are immutable after creation).
     */
    public static void ensureChannel(Context ctx, String channelId) {
        NotificationManager nm =
                (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (nm.getNotificationChannel(channelId) != null) return;

        String pkg = ctx.getPackageName();
        NotificationChannel ch;
        if (CHANNEL_VOICE.equals(channelId)) {
            ch = new NotificationChannel(CHANNEL_VOICE,
                    "الأذان ومواقيت الصلاة",
                    NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("تنبيه عند دخول وقت كل صلاة بصوت المؤذن");
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            ch.setSound(Uri.parse("android.resource://" + pkg + "/raw/adhan_short"), attrs);
            ch.enableVibration(true);
            ch.enableLights(true);
        } else if (CHANNEL_BEEP.equals(channelId)) {
            ch = new NotificationChannel(CHANNEL_BEEP,
                    "تنبيه الصلاة (قصير)",
                    NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("تنبيه قصير عند دخول وقت الصلاة");
            ch.enableVibration(true);
            ch.enableLights(true);
        } else if (CHANNEL_SILENT.equals(channelId)) {
            ch = new NotificationChannel(CHANNEL_SILENT,
                    "تنبيه الصلاة (صامت)",
                    NotificationManager.IMPORTANCE_MIN);
            ch.setDescription("إشعار بصري فقط عند دخول وقت الصلاة، بلا صوت");
            ch.enableVibration(false);
        } else if (CHANNEL_TEST_DEFAULT.equals(channelId)) {
            // Control test: deliberately NO setSound() call, so the channel
            // uses the system default notification sound. This is the whole
            // point of the channel — if it sounds and adhan-voice-v2 does
            // not, the adhan_short.mp3 file / channel sound is at fault;
            // if neither sounds, the phone (ringer / DND / volume) is.
            ch = new NotificationChannel(CHANNEL_TEST_DEFAULT,
                    "اختبار صوت الأذان (افتراضي)",
                    NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("اختبار تشخيصي: تنبيه بصوت النظام الافتراضي");
            ch.enableVibration(true);
        } else {
            // Unknown channel id (e.g. a future JS channel): fall back to the
            // voice channel so the prayer is never silently dropped.
            ensureChannel(ctx, CHANNEL_VOICE);
            return;
        }
        nm.createNotificationChannel(ch);
    }

    // ---- Posting -----------------------------------------------------------

    /**
     * Post the full-screen adhan notification and record the pending route.
     * Called from AdhanAlarmReceiver (alarm fired) only. No sound is played
     * here — the channel sound is the mechanism.
     *
     * 2.6.4: the PendingIntent is explicit (MainActivity.class + the adhan
     * deep link as data) and is used for both the content intent and the
     * full-screen intent. Before notify(), an FSI post records
     * "fsi-launch" (allowed at post time) or "fsi-denied" (API 34+ check
     * says no — still posted, the system demotes it to heads-up); a plain
     * post records "native-fsi" / "posted plain notification". The old
     * unconditional "posted full-screen notification" event was removed
     * because it could not distinguish success from demotion.
     *
     * @param fsi when false, posts a plain notification (content intent
     *            only, no full-screen intent) — used by the default-sound
     *            control test so the only variable is the sound.
     */
    public static void postAdhanNotification(Context ctx, int id, String key, long at,
                                             String title, String body, String channelId,
                                             boolean fsi) {
        NotificationManager nm =
                (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (channelId == null || channelId.isEmpty()) channelId = CHANNEL_VOICE;
        ensureChannel(ctx, channelId);

        // 2.6.4: ONE explicit PendingIntent targeting MainActivity with the
        // adhan deep link as its data URI. The previous implicit
        // ACTION_VIEW-only intent left the system to resolve the target;
        // an explicit component intent is what a full-screen intent needs
        // to launch the activity reliably over the lock screen. The same
        // PendingIntent serves as both content intent and full-screen
        // intent. MainActivity is singleTask, so a running instance gets
        // it via onNewIntent.
        Intent view = new Intent(ctx, MainActivity.class);
        view.setAction(Intent.ACTION_VIEW);
        view.setData(Uri.parse("athar://open?r=adhan/" + key));
        view.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentPi = PendingIntent.getActivity(
                ctx, id, view, FLAGS_IMMUTABLE_UPDATE);

        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, channelId)
                // Same small icon LocalNotifications 8.3.1 uses by default:
                // its getDefaultSmallIcon() falls back to
                // android.R.drawable.ic_dialog_info when no smallIcon is
                // configured in capacitor.config.json (only iconColor is set).
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title == null || title.isEmpty() ? "حان الآن موعد الصلاة" : title)
                .setContentText(body == null ? "" : body)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setAutoCancel(true)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setShowWhen(true)
                .setWhen(at)
                .setContentIntent(contentPi);
        // Extras let getActiveAdhan() recover key/at from a live notification.
        android.os.Bundle extras = new android.os.Bundle();
        extras.putString("adhan_key", key);
        extras.putLong("adhan_at", at);
        b.addExtras(extras);
        if (fsi) {
            // highPriority=true: sent even if other notifications are
            // suppressed. On a locked/asleep device the system launches
            // this intent instead of posting to the status bar; while the
            // user is using the device it may show as a heads-up instead.
            b.setFullScreenIntent(contentPi, true);
        }

        Notification notification = b.build();

        // 2.6.4: BEFORE notify(), check whether the system will actually
        // honour the full-screen intent, and record the honest outcome.
        // On API 34+ canUseFullScreenIntent() is the authoritative check;
        // below API 34 the permission is an install-time grant, so FSI is
        // treated as allowed. The old unconditional "posted full-screen
        // notification" event is gone: it was pushed after every notify()
        // whether or not the system honoured the FSI, so the log could not
        // distinguish a real launch from a demotion to heads-up. The
        // activity launch itself is recorded separately by MainActivity
        // as "fsi-activity-launched".
        if (fsi) {
            boolean fsiAllowed = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                try {
                    fsiAllowed = nm.canUseFullScreenIntent();
                } catch (Exception e) {
                    pushEvent(ctx, "native-crash",
                            "postAdhanNotification:canUseFullScreenIntent: "
                                    + e.getClass().getSimpleName()
                                    + ": " + String.valueOf(e.getMessage()));
                    fsiAllowed = true;
                }
            }
            if (!fsiAllowed) {
                pushEvent(ctx, "fsi-denied",
                        "FSI not allowed at post time id=" + id + " key=" + key
                                + " — system will demote to heads-up; posted anyway");
            } else {
                pushEvent(ctx, "fsi-launch",
                        "FSI allowed at post time id=" + id + " key=" + key
                                + " channel=" + channelId
                                + " — posted with full-screen intent; activity launch is recorded as fsi-activity-launched");
            }
        }

        nm.notify(FSI_TAG, id, notification);

        setPendingRoute(ctx, "adhan/" + key, key, at);
        if (!fsi) {
            // Plain notifications keep a plain event — this one is accurate.
            pushEvent(ctx, "native-fsi",
                    "posted plain notification id=" + id
                            + " key=" + key + " channel=" + channelId);
        }
    }
}
