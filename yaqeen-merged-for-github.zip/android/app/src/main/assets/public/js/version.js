/* مولَّد من version.json أثناء البناء — لا تُعدَّله يدوياً هنا */
window.YAQEEN_VERSION = {"versionName":"2.6.7","versionCode":9,"buildDate":"2026-11-20"};
