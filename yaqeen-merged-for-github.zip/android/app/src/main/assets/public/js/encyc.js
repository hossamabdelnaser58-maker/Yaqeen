/* الموسوعات الإسلامية: المساجد، العلماء، التاريخ الإسلامي (مع خط زمني)، اليوم الآخر، وبوابة الأكاديمية.
 * - مقدمات المقالات محفوظة داخل التطبيق (data/enc-wiki.json من ويكيبيديا العربية — CC BY-SA 4.0) وتعمل بلا إنترنت.
 * - المقال الكامل يُجلب من ويكيبيديا عند الطلب ويُحفظ على الجهاز بعد أول قراءة.
 * - اليوم الآخر وآداب المساجد: آيات من المصحف وأحاديث صحيحة بتخريجها وروابط لأبواب الصحيحين داخل التطبيق. */
(window.NoorModules = window.NoorModules || []).push((N) => {
  'use strict';
  const E = window.ENC;
  if (!E) return;
  const { $, $$, store, toast, go, ar, esc, routes } = N;
  const CACHE = 'noor-data-v1';
  const WIKI_API = 'https://ar.wikipedia.org/w/api.php';
  let WIKI = null;
  async function wiki() {
    if (WIKI) return WIKI;
    const r = await fetch('data/enc-wiki.json');
    WIKI = await r.json();
    return WIKI;
  }
  const loader = () => { N.view.innerHTML = '<div class="loader"></div>'; };
  const normAr = (t) => String(t || '').replace(/[ً-ْٰـ]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي');
  const yearLbl = (h) => { const hj = h[2] ? (h[2] < 0 ? `${ar(-h[2])} قبل الهجرة` : `${ar(h[2])} هـ`) : ''; const g = h[4] ? `${ar(h[3])}–${ar(h[4])} م` : `${ar(h[3])} م`; return `${hj ? hj + ' / ' : ''}${g}${h[5] ? ' (تقريباً)' : ''}`; };
  const HTYPE = Object.fromEntries(E.history.map((h) => [h[0], h]));
  const SCAT = {}; Object.entries(E.scholars).forEach(([c, l]) => l.forEach((n) => { SCAT[n] = c; }));
  const MPLACE = Object.fromEntries(E.mosques.map(([n, p]) => [n, p]));
  const kindOf = (k) => (MPLACE[k] ? 'm' : SCAT[k] ? 's' : 'h');
  const readList = () => store.get('enc:read', []);
  const favs = () => store.get('enc:fav', []);

  // ---------- بطاقة مقال ----------
  function artCard(k, W, sub) {
    const p = W.pages[k];
    if (!p) return '';
    return `<button class="yq-gold-row enc-card" data-a="${esc(k)}">
      <span class="enc-img">${p.img ? `<img src="${esc(p.img)}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.replaceWith('🏛️')">` : '<span>🕌</span>'}</span>
      <span class="enc-info"><b>${esc(k)}</b><small>${esc(sub || '')}</small><span>${esc(p.intro.slice(0, 110))}…</span></span>
    </button>`;
  }
  const bindCards = (root) => $$('[data-a]', root).forEach((b) => { b.onclick = () => go(`encw/${encodeURIComponent(b.dataset.a)}`); });

  // ---------- الصفحة الرئيسية للموسوعات ----------
  function renderHub() {
    const last = readList().slice(0, 4);
    N.view.innerHTML = `
      <form class="az-search" id="encS"><input id="encQ" type="search" placeholder="ابحث: مسجد، عالم، معركة، دولة، موضوع…" autocomplete="off"><button class="btn">بحث</button></form>
      <ol class="yq-index">
        <li class="yq-index-item" data-go="encm" style="cursor:pointer"><span class="yq-index-num">٠١</span><div class="yq-index-body"><h3 class="yq-index-title">🕌 موسوعة المساجد</h3><p class="yq-index-desc">${ar(E.mosques.length)} مسجداً تاريخياً وآداب المساجد</p></div><span aria-hidden="true">‹</span></li>
        <li class="yq-index-item" data-go="academy" style="cursor:pointer"><span class="yq-index-num">٠٢</span><div class="yq-index-body"><h3 class="yq-index-title">🎓 أكاديمية العلوم الشرعية</h3><p class="yq-index-desc">مسارات بمستويات واختبارات وشهادات</p></div><span aria-hidden="true">‹</span></li>
        <li class="yq-index-item" data-go="encs" style="cursor:pointer"><span class="yq-index-num">٠٣</span><div class="yq-index-body"><h3 class="yq-index-title">📚 موسوعة العلماء</h3><p class="yq-index-desc">${ar(Object.values(E.scholars).flat().length)} عالماً في ${ar(E.scholarCats.length)} تخصصات</p></div><span aria-hidden="true">‹</span></li>
        <li class="yq-index-item" data-go="ench" style="cursor:pointer"><span class="yq-index-num">٠٤</span><div class="yq-index-body"><h3 class="yq-index-title">🏛️ التاريخ الإسلامي</h3><p class="yq-index-desc">خط زمني و${ar(E.history.length)} حدثاً ودولة ومعركة</p></div><span aria-hidden="true">‹</span></li>
        <li class="yq-index-item" data-go="enca" style="cursor:pointer"><span class="yq-index-num">٠٥</span><div class="yq-index-body"><h3 class="yq-index-title">⏳ موسوعة اليوم الآخر</h3><p class="yq-index-desc">من القرآن والأحاديث الصحيحة</p></div><span aria-hidden="true">‹</span></li>
        <li class="yq-index-item" data-go="lib/all" style="cursor:pointer"><span class="yq-index-num">٠٦</span><div class="yq-index-body"><h3 class="yq-index-title">📖 المكتبة العلمية</h3><p class="yq-index-desc">كتب PDF وصوتيات ومرئيات من دار الإسلام</p></div><span aria-hidden="true">‹</span></li>
        <li class="yq-index-item" data-go="encme" style="cursor:pointer"><span class="yq-index-num">٠٧</span><div class="yq-index-body"><h3 class="yq-index-title">⭐ متابعتي</h3><p class="yq-index-desc">آخر ما قرأت والمحفوظات والتقدّم</p></div><span aria-hidden="true">‹</span></li>
      </ol>
      ${last.length ? `<h3 class="dash-sec">📌 آخر ما قرأت</h3><div class="chips" style="justify-content:flex-start">${last.map((k) => `<button class="chip" data-a="${esc(k)}">${esc(k)}</button>`).join('')}</div>` : ''}
      <p class="muted enc-note">مقالات المساجد والعلماء والتاريخ من <b>ويكيبيديا العربية</b> (ترخيص CC BY-SA)، ويُذكر المصدر وتاريخ آخر تحديث في كل مقال. وهي مقالات يحررها متطوعون، فالمسائل الشرعية تؤخذ من القرآن والسنة وأهل العلم.</p>`;
    $$('[data-go]', N.view).forEach((b) => { b.onclick = () => go(b.dataset.go); });
    bindCards(N.view);
    $('#encS').onsubmit = (e) => { e.preventDefault(); const q = $('#encQ').value.trim(); if (q.length < 2) { toast('اكتب كلمتين على الأقل'); return; } go(`encq/${encodeURIComponent(q)}`); };
  }

  // ---------- المساجد ----------
  function renderMosques() {
    loader();
    wiki().then((W) => {
      if (!location.hash.startsWith('#/encm')) return;
      N.view.innerHTML = `
        <button class="yq-gold-row enc-adab" data-go="encma" style="width:100%"><div class="yq-gold-row-body"><small class="muted">🧎 آداب وأحكام المساجد</small><br><b>أحاديث صحيحة بتخريجها</b></div><span class="yq-gold-row-status">فتح</span></button>
        <div class="yq-gold-rows">${E.mosques.map(([k, place]) => artCard(k, W, '📍 ' + place)).join('')}</div>
        <button class="yq-btn yq-btn--block" data-go="lib/masajid" style="margin-bottom:8px">📚 كتب وصوتيات عن المساجد وأحكامها</button>
        <button class="yq-btn yq-btn--ghost yq-btn--block" data-go="dtopic/seerah">🎬 محاضرات السيرة والتاريخ في المكتبة الدعوية</button>`;
      bindCards(N.view);
      $$('[data-go]', N.view).forEach((b) => { b.onclick = () => go(b.dataset.go); });
    }).catch(() => { N.view.innerHTML = '<div class="card center">تعذّر تحميل البيانات</div>'; });
  }
  function renderAdab() {
    N.view.innerHTML = `
      <div class="yq-encyc-chapter"><h3>🕌 دعاء دخول المسجد والخروج منه</h3><p class="muted" style="margin:0 0 8px">من «حصن المسلم» بتخريجه، مع العدّاد والصوت.</p><button class="yq-btn yq-btn--block" data-go="azcat/azkar/masjid">فتح أذكار المسجد والأذان</button></div>
      <div class="yq-hadith-list">${E.masjidAdab.map(([t, txt, src, hukm]) => `<article class="yq-hadith-entry"><h3>${esc(t)}</h3><p class="hadith-text yq-hadith-text" style="font-size:1.15rem">${esc(txt)}</p><span class="yq-hadith-source">${esc(src)}</span><p class="enc-hukm">⚖️ ${esc(hukm)}</p></article>`).join('')}</div>
      <div class="yq-encyc-chapter"><h3>📜 أبواب الأحاديث كاملة</h3>${E.masjidBooks.map(([b, n, t]) => `<button class="yq-btn yq-btn--ghost yq-btn--block" style="margin-bottom:6px" data-go="hsec/${b}/${n}">${esc(t)}</button>`).join('')}</div>
      <p class="muted enc-note">«الحكم» المذكور تلخيص لما عليه جمهور العلماء أو بيان لوجود خلاف، وتفاصيل الأحكام في مسار الفقه بالأكاديمية.</p>`;
    $$('[data-go]', N.view).forEach((b) => { b.onclick = () => go(b.dataset.go); });
  }

  // ---------- العلماء ----------
  function renderScholars(cat) {
    loader();
    wiki().then((W) => {
      if (!location.hash.startsWith('#/encs')) return;
      const c = cat && E.scholars[cat] ? cat : E.scholarCats[0][0];
      N.view.innerHTML = `
        <div class="chips enc-tabs">${E.scholarCats.map(([k, t, ic]) => `<button class="chip ${k === c ? 'active' : ''}" data-c="${k}">${ic} ${t}</button>`).join('')}</div>
        <div class="yq-gold-rows">${E.scholars[c].map((k) => artCard(k, W, (E.scholarCats.find((x) => x[0] === c) || [])[1])).join('')}</div>
        <button class="yq-btn yq-btn--block" data-go="lib/ulama">📚 كتب التراجم وسير الأعلام</button>`;
      $$('[data-go]', N.view).forEach((b) => { b.onclick = () => go(b.dataset.go); });
      bindCards(N.view);
      $$('[data-c]', N.view).forEach((b) => { b.onclick = () => go(`encs/${b.dataset.c}`); });
    });
  }

  // ---------- التاريخ ----------
  function renderHistory(type) {
    loader();
    wiki().then((W) => {
      if (!location.hash.startsWith('#/ench')) return;
      const t = type || 'timeline';
      const tabs = [['timeline', 'الخط الزمني', '🗓️'], ...Object.entries(E.historyTypes).map(([k, [n, ic]]) => [k, n, ic])];
      const list = t === 'timeline' ? E.history.slice().sort((a, b) => a[3] - b[3]) : E.history.filter((h) => h[1] === t);
      N.view.innerHTML = `
        <div class="chips enc-tabs">${tabs.map(([k, n, ic]) => `<button class="chip ${k === t ? 'active' : ''}" data-t="${k}">${ic} ${n}</button>`).join('')}</div>
        ${t === 'timeline' ? `<ol class="yq-chronicle">${list.filter((h) => W.pages[h[0]]).map((h) => `<li class="yq-chronicle-item"><span class="yq-chronicle-year">${yearLbl(h)}</span><button class="enc-tl-i" data-a="${esc(h[0])}"><h3>${E.historyTypes[h[1]][1]} ${esc(h[0])}</h3></button></li>`).join('')}</ol>`
          : `<div class="yq-gold-rows">${list.map((h) => artCard(h[0], W, '🗓️ ' + yearLbl(h))).join('')}</div>`}
        <p class="muted enc-note">التواريخ المعلَّمة «تقريباً» يختلف فيها المؤرخون أو تمتد على فترة؛ وتفاصيل الروايات ومواضع الخلاف في كل مقال ومراجعه.</p>
        <button class="btn block" data-go="lib/tarikh" style="margin-bottom:8px">📚 كتب وصوتيات التاريخ والسيرة</button>
        <button class="btn ghost block" data-go="dtopic/seerah">🎬 محاضرات السيرة في المكتبة الدعوية</button>`;
      bindCards(N.view);
      $$('[data-t]', N.view).forEach((b) => { b.onclick = () => go(`ench/${b.dataset.t}`); });
      $$('[data-go]', N.view).forEach((b) => { b.onclick = () => go(b.dataset.go); });
    });
  }

  // ---------- اليوم الآخر ----------
  function renderAkhirah() {
    N.view.innerHTML = `
      <div class="yq-featured-verse"><p class="yq-quran-text">﴿${esc(E.ayat['3:185-185'].t)}﴾</p><span class="yq-verse-ref">آل عمران: ١٨٥</span></div>
      <ol class="yq-index">${E.akhirah.map((x, ix) => `<li class="yq-index-item" data-k="${x.k}" style="cursor:pointer"><span class="yq-index-num">${ar(ix + 1)}</span><div class="yq-index-body"><h3 class="yq-index-title">${x.ic} ${x.t}</h3><p class="yq-index-desc">${ar(x.q.length)} آية/مقطع • ${ar(x.h.length)} باب حديث</p></div><span aria-hidden="true">‹</span></li>`).join('')}</ol>
      <button class="yq-btn yq-btn--block" data-go="lib/akhirah" style="margin-bottom:8px">📚 كتب وصوتيات عن اليوم الآخر والجنائز</button>
      <button class="yq-btn yq-btn--ghost yq-btn--block" data-go="dtopic/akhirah">🎬 محاضرات عن الآخرة في المكتبة الدعوية</button>
      <p class="muted enc-note">هذه الموسوعة تعتمد على نص القرآن الكريم وأبواب الصحيحين فقط، دون قصص غير ثابتة أو تفاصيل غيبية لم ترد بها النصوص.</p>`;
    $$('[data-k]', N.view).forEach((b) => { b.onclick = () => go(`encak/${b.dataset.k}`); });
    $$('[data-go]', N.view).forEach((b) => { b.onclick = () => go(b.dataset.go); });
  }
  function renderAkhTopic(k) {
    const x = E.akhirah.find((a) => a.k === k);
    if (!x) { go('enca'); return; }
    N.setTitle(x.t);
    N.view.innerHTML = `
      ${x.q.length ? `<h3 class="dash-sec">📖 من القرآن الكريم</h3>${x.q.map(([s, a, b]) => { const y = E.ayat[`${s}:${a}-${b}`]; return y ? `<div class="yq-featured-verse"><p class="yq-quran-text">﴿${esc(y.t)}﴾</p><span class="yq-verse-ref">${esc(y.n)} • ${a === b ? `الآية ${ar(a)}` : `الآيات ${ar(a)}–${ar(b)}`}</span><button class="yq-btn yq-btn--ghost" style="margin-top:8px" data-go="surah/${s}/${a}">فتح في المصحف مع التفسير</button></div>` : ''; }).join('')}` : ''}
      <h3 class="dash-sec">📜 من الأحاديث الصحيحة</h3>
      <div class="yq-gold-rows">${x.h.map(([b, n, t]) => `<button class="yq-gold-row" data-go="hsec/${b}/${n}">${esc(t)}</button>`).join('')}</div><p class="muted" style="font-size:.82rem;margin:6px 0 0">تُفتح الأبواب كاملة من مكتبة الحديث داخل التطبيق، مع رقم كل حديث.</p>
      ${x.az.length ? `<h3 class="dash-sec">🤲 ذو صلة</h3><div class="yq-gold-rows">${x.az.map(([r, t]) => `<button class="yq-gold-row" data-go="${r}">${esc(t)}</button>`).join('')}</div>` : ''}`;
    $$('[data-go]', N.view).forEach((b) => { b.onclick = () => go(b.dataset.go); });
  }

  // ---------- قارئ المقال ----------
  async function fullArticle(title) {
    const url = `${WIKI_API}?action=query&format=json&formatversion=2&origin=*&prop=extracts|info&explaintext=1&exsectionformat=wiki&titles=${encodeURIComponent(title)}`;
    let c = null;
    try { c = await caches.open(CACHE); const hit = await c.match(url); if (hit && !navigator.onLine) return (await hit.json()); } catch { /* */ }
    try {
      const r = await fetch(url);
      if (!r.ok) throw new Error(r.status);
      if (c) try { await c.put(url, r.clone()); } catch { /* */ }
      return await r.json();
    } catch (e) {
      if (c) { const hit = await c.match(url); if (hit) return hit.json(); }
      throw e;
    }
  }
  const SKIP = /^(المراجع|مراجع|الهوامش|هوامش|انظر أيضا|انظر أيضًا|وصلات خارجية|روابط خارجية|المصادر|مصادر|ملاحظات|قراءات إضافية|معرض صور|معرض الصور|ببليوغرافيا)$/;
  function renderText(txt) {
    const out = []; let skip = false; let inChapter = false; let firstP = true;
    const closeChapter = () => { if (inChapter) { out.push('</div>'); inChapter = false; } };
    txt.split('\n').forEach((line) => {
      const l = line.trim(); if (!l) return;
      const m = /^(=+)\s*(.*?)\s*=+$/.exec(l);
      if (m) { skip = SKIP.test(m[2]); if (!skip) { closeChapter(); out.push('<div class="yq-encyc-chapter">'); inChapter = true; out.push(`<h${m[1].length <= 2 ? 3 : 4} class="enc-h">${esc(m[2])}</h${m[1].length <= 2 ? 3 : 4}>`); } return; }
      if (!skip) { out.push(firstP ? `<p class="yq-dropcap">${esc(l)}</p>` : `<p>${esc(l)}</p>`); firstP = false; }
    });
    closeChapter();
    return out.join('');
  }
  function renderArticle(kEnc) {
    const k = decodeURIComponent(kEnc || '');
    loader();
    wiki().then((W) => {
      const p = W.pages[k];
      if (!p) { N.view.innerHTML = '<div class="card center">المقال غير متوفر</div>'; return; }
      N.setTitle(k);
      const R = readList().filter((x) => x !== k); R.unshift(k); store.set('enc:read', R.slice(0, 40));
      const kind = kindOf(k);
      routes.encw.back = kind === 'm' ? 'encm' : kind === 's' ? `encs/${SCAT[k]}` : 'ench';
      const h = HTYPE[k];
      const isFav = () => favs().includes(k);
      const fs = store.get('enc:fs', 1);
      const wikiUrl = `https://ar.wikipedia.org/wiki/${encodeURIComponent(p.title.replace(/ /g, '_'))}`;
      N.view.innerHTML = `
        ${p.img ? `<div class="enc-hero"><img src="${esc(p.img)}" alt="" referrerpolicy="no-referrer" onerror="this.parentNode.remove()"></div>` : ''}
        <h2 class="enc-title yq-display">${esc(k)}</h2>
        <div class="enc-meta">${MPLACE[k] ? `📍 ${esc(MPLACE[k])}` : ''}${h ? `🗓️ ${yearLbl(h)}` : ''}${SCAT[k] ? `📚 ${esc((E.scholarCats.find((c) => c[0] === SCAT[k]) || [])[1])}` : ''}</div>
        <div class="enc-tools"><button class="chip" id="eFav">${isFav() ? '★ محفوظ' : '☆ حفظ'}</button><button class="chip" id="eFsM">أ−</button><button class="chip" id="eFsP">أ+</button>${p.geo ? `<a class="chip" target="_blank" rel="noopener" href="https://www.openstreetmap.org/?mlat=${p.geo[0]}&mlon=${p.geo[1]}#map=17/${p.geo[0]}/${p.geo[1]}">🗺️ الخريطة</a>` : ''}<button class="chip" id="eShare">↗ مشاركة</button></div>
        <article class="enc-body yq-encyc-article" id="eBody" style="--encfs:${fs}">${renderText(p.intro)}</article>
        <button class="yq-btn yq-btn--block" id="eFull">📖 قراءة المقال كاملاً</button>
        <div class="enc-src">المصدر: ويكيبيديا العربية — مقال «<a href="${wikiUrl}" target="_blank" rel="noopener">${esc(p.title)}</a>»${p.touched ? ` — آخر تحديث للمقال: ${N.toAr(p.touched.slice(0, 10))}` : ''} — النص متاح بترخيص <a href="https://creativecommons.org/licenses/by-sa/4.0/deed.ar" target="_blank" rel="noopener">CC BY-SA 4.0</a>. المراجع والروايات المختلفة مذكورة في المقال الأصلي.</div>`;
      const body = $('#eBody');
      $('#eFav').onclick = () => { const F = favs(); const i = F.indexOf(k); if (i < 0) F.unshift(k); else F.splice(i, 1); store.set('enc:fav', F); $('#eFav').textContent = i < 0 ? '★ محفوظ' : '☆ حفظ'; };
      const setFs = (d) => { const v = Math.max(0.8, Math.min(1.8, +(store.get('enc:fs', 1) + d).toFixed(2))); store.set('enc:fs', v); body.style.setProperty('--encfs', v); };
      $('#eFsM').onclick = () => setFs(-0.1); $('#eFsP').onclick = () => setFs(0.1);
      $('#eShare').onclick = () => N.shareText(`${k}\n${p.intro.slice(0, 300)}…\n\nالمصدر: ويكيبيديا — ${wikiUrl}\nمن تطبيق يقين - رفيق المسلم`);
      $('#eFull').onclick = async () => {
        const b = $('#eFull'); b.disabled = true; b.textContent = 'جارٍ التحميل…';
        try {
          const d = await fullArticle(p.title);
          const pg = d.query && d.query.pages && d.query.pages[0];
          if (!pg || !pg.extract) throw new Error('empty');
          body.innerHTML = renderText(pg.extract);
          b.remove();
          const done = store.get('enc:full', []); if (!done.includes(k)) { done.unshift(k); store.set('enc:full', done.slice(0, 200)); }
        } catch { b.disabled = false; b.textContent = '📖 قراءة المقال كاملاً'; toast('تعذّر التحميل — المقال الكامل يحتاج إنترنت أول مرة، ثم يُحفظ على جهازك'); }
      };
      if (store.get('enc:full', []).includes(k)) $('#eFull').click();
    });
  }

  // ---------- البحث الموحّد ----------
  function renderSearch(qEnc) {
    const q = decodeURIComponent(qEnc || '');
    loader();
    Promise.all([wiki(), N.lib ? N.lib.index().catch(() => null) : null]).then(([W, LI]) => {
      const words = normAr(q).split(/\s+/).filter((w) => w.length > 1);
      const hit = (s) => words.every((w) => normAr(s).includes(w));
      const arts = Object.entries(W.pages).filter(([k, p]) => (MPLACE[k] || SCAT[k] || HTYPE[k]) && hit(k + ' ' + p.title + ' ' + p.intro)).map(([k]) => k);
      const groups = [['🕌 المساجد', arts.filter((k) => kindOf(k) === 'm')], ['📚 العلماء', arts.filter((k) => kindOf(k) === 's')], ['🏛️ التاريخ', arts.filter((k) => kindOf(k) === 'h')]];
      const akh = E.akhirah.filter((x) => hit(x.t + ' ' + x.h.map((h) => h[2]).join(' ')));
      const acad = (typeof ACADEMY !== 'undefined' ? ACADEMY : []).flatMap((t) => (t.levels || []).flatMap((l, li) => (l.lessons || []).filter((s) => hit(s + ' ' + t.title)).map((s) => [t.id, li, s, t.title])));
      const libHits = LI ? LI.items.filter((x) => hit(`${x.t} ${x.au.join(' ')} ${x.d}`)) : [];
      const total = arts.length + akh.length + acad.length + libHits.length;
      N.view.innerHTML = `
        <form class="az-search" id="encS2"><input id="encQ2" type="search" value="${esc(q)}"><button class="btn">بحث</button></form>
        <p class="muted">${ar(total)} نتيجة لـ «${esc(q)}»</p>
        ${groups.filter((g) => g[1].length).map(([t, l]) => `<h3 class="dash-sec">${t}</h3><div class="yq-gold-rows">${l.map((k) => artCard(k, W, '')).join('')}</div>`).join('')}
        ${akh.length ? `<h3 class="dash-sec">⏳ اليوم الآخر</h3><div class="yq-gold-rows">${akh.map((x) => `<button class="yq-gold-row" data-go="encak/${x.k}">${x.ic} ${x.t}</button>`).join('')}</div>` : ''}
        ${acad.length ? `<h3 class="dash-sec">🎓 دروس الأكاديمية</h3><div class="yq-gold-rows">${acad.slice(0, 30).map(([id, li, s, tt]) => `<button class="yq-gold-row" data-go="track/${id}">${esc(s)} <small class="muted">— ${esc(tt)}</small></button>`).join('')}</div>` : ''}
        ${libHits.length ? `<h3 class="dash-sec">📖 المكتبة العلمية (${ar(libHits.length)})</h3><div class="yq-gold-rows">${libHits.slice(0, 25).map((x) => `<button class="yq-gold-row" style="margin-bottom:6px;text-align:start" data-go="libi/${x.id}">${{ b: '📕', a: '🎧', v: '🎬' }[x.y]} ${esc(x.t)} <small class="muted">— ${esc(x.au.join('، '))}</small></button>`).join('')}</div>` : ''}
        ${total ? '' : '<div class="card center muted">لا توجد نتائج. جرّب: الأزهر، البخاري، حطين، العباسية، الميزان…</div>'}
        <button class="yq-btn yq-btn--ghost yq-btn--block" data-go="dsearch/${encodeURIComponent(q)}">🎬 ابحث عن «${esc(q)}» في المحاضرات المرئية</button>`;
      bindCards(N.view);
      $$('[data-go]', N.view).forEach((b) => { b.onclick = () => go(b.dataset.go); });
      $('#encS2').onsubmit = (e) => { e.preventDefault(); const v = $('#encQ2').value.trim(); if (v.length >= 2) go(`encq/${encodeURIComponent(v)}`); };
    });
  }

  // ---------- متابعتي ----------
  function renderMine() {
    loader();
    wiki().then((W) => {
      const prog = store.get('academy:progress', null);
      const F = favs().filter((k) => W.pages[k]); const R = readList().filter((k) => W.pages[k]); const full = store.get('enc:full', []);
      N.view.innerHTML = `
        <div class="az-stats card"><div><b>${ar(R.length)}</b><small>مقالاً قرأته</small></div><div><b>${ar(full.length)}</b><small>محفوظ للقراءة بلا إنترنت</small></div><div><b>${ar(F.length)}</b><small>في المحفوظات</small></div></div>
        <button class="yq-btn yq-btn--block" data-go="academy" style="margin-bottom:8px">🎓 تقدّمي في الأكاديمية والشهادات</button>
        <button class="yq-btn yq-btn--ghost yq-btn--block" data-go="libme" style="margin-bottom:14px">📖 مكتبتي: الكتب والتحميلات وآخر صفحة</button>
        ${F.length ? `<h3 class="dash-sec">⭐ المحفوظات</h3><div class="yq-gold-rows">${F.map((k) => artCard(k, W, '')).join('')}</div>` : ''}
        ${R.length ? `<h3 class="dash-sec">🕘 سجل القراءة</h3><div class="yq-gold-rows">${R.slice(0, 15).map((k) => artCard(k, W, '')).join('')}</div>` : '<div class="card center muted">لم تقرأ أي مقال بعد</div>'}
        ${prog ? '' : ''}`;
      bindCards(N.view);
      $$('[data-go]', N.view).forEach((b) => { b.onclick = () => go(b.dataset.go); });
    });
  }

  Object.assign(routes, {
    enc: { title: 'الموسوعات الإسلامية', render: renderHub, back: 'home' },
    encm: { title: 'موسوعة المساجد', render: renderMosques, back: 'enc' },
    encma: { title: 'آداب وأحكام المساجد', render: renderAdab, back: 'encm' },
    encs: { title: 'موسوعة العلماء', render: renderScholars, back: 'enc' },
    ench: { title: 'التاريخ الإسلامي', render: renderHistory, back: 'enc' },
    enca: { title: 'موسوعة اليوم الآخر', render: renderAkhirah, back: 'enc' },
    encak: { title: 'اليوم الآخر', render: renderAkhTopic, back: 'enca' },
    encw: { title: 'المقال', render: renderArticle, back: 'enc' },
    encq: { title: 'البحث في الموسوعات', render: renderSearch, back: 'enc' },
    encme: { title: 'متابعتي', render: renderMine, back: 'enc' },
  });
});
