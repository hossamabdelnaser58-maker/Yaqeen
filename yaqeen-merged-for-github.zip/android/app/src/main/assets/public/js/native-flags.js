window.NOOR_NATIVE_ADHAN = true;
window.NOOR_BUILD = {"code":9,"kind":"local","versionName":"2.6.7","buildDate":"2026-11-20"};
