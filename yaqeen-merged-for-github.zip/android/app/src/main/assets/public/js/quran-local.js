/* One immutable edition for reading, memorisation and search. Load only on demand. */
const QuranLocal = (() => {
  let pending;
  const load = () => pending ||= fetch('data/quran-uthmani.json').then(async response => {
    if (!response.ok) throw Error('quran-data');
    const {surahs} = await response.json();
    const pages = [], parts = [];
    const list = surahs.map(({ayahs, ...s}) => {
      const meta = {...s, numberOfAyahs: ayahs.length};
      for (const a of ayahs) {
        const row = {...a, surah: meta};
        (pages[a.page] ||= []).push(row); (parts[a.juz] ||= []).push(row);
      }
      return meta;
    });
    return {surahs,list,pages,parts};
  }).catch(e => { pending = null; throw e; });
  const normalize = s => String(s).normalize('NFKC').replace(/[\u0640\u064b-\u065f\u0670\u06d6-\u06ed]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/[٠-٩]/g,c=>'٠١٢٣٤٥٦٧٨٩'.indexOf(c));
  const basmala = 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ ';
  function verse(text,s,a) {
    if (s===1 || s===9 || a!==1) return text;
    for (const prefix of [basmala,basmala.replace('بِ','بِّ')]) if(text.startsWith(prefix)) return text.slice(prefix.length);
    return text;
  }
  async function read(kind,n) {
    const d = await load(); if (kind==='list') return d.list;
    if (kind==='surah') return {...d.surahs[n-1],numberOfAyahs:d.list[n-1].numberOfAyahs};
    return {number:n,ayahs:(kind==='page'?d.pages:d.parts)[n]};
  }
  async function search(term) {
    const {pages} = await load(); const matches=[]; let count=0;
    const query=normalize(term).trim(); if(!query) return {count,matches};
    for (const rows of pages) if(rows) for(const row of rows) {
      const text=verse(row.text,row.surah.number,row.numberInSurah);
      if(normalize(text).includes(query)){count++;if(matches.length<100) matches.push({...row,text});}
    } return {count,matches};
  }
  return {read,search,normalize,verse};
})();
