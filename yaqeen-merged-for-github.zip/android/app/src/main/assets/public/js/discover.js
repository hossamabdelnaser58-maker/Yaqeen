/* Navigation only: saved content remains in its original stores. */
(window.NoorModules = window.NoorModules || []).push(N => {
  const {view,routes,ar,esc,store} = N;
  const link = (path,title,meta) => `<a class="di-result" href="#/${esc(path)}"><span>${esc(title)}</span><small>${esc(meta)}</small></a>`;
  routes.saved = {title:'محفوظاتي',back:'home',render(){
    const groups=[['bookmarks','علامات المصحف','bookmarks'],['azfav','الأذكار والأدعية','az:fav'],['hbookmarks','الأحاديث النبوية','hadith:fav']];
    view.innerHTML=`<h2 class="di-heading">مكتبتك الشخصية</h2>${groups.map(([p,t,k])=>link(p,t,ar(store.get(k,[]).length)+' محفوظ')).join('')}${link('azlists','قوائم الأذكار','فتح القوائم')}`;
  }};
  routes.hbookmarks={title:'مفضلة الأحاديث',back:'hadith',render(){return routes.hadith.render('fav');}};
  routes.discover={title:'البحث الشامل',back:'home',render(){
    const keys=['quran','audio','prayers','qibla','azkar','hadith','tasbih','saved','khatma','hifz','tracker','lib','radio','ibtihal','academy','fiqh','calc','calendar','names','settings'];
    const entries=keys.filter(k=>routes[k]).map(k=>[k==='lib'?'lib/all':k,routes[k].title,'قسم']);
    SURAH_NAMES.forEach((v,i)=>entries.push(['surah/'+(i+1),'سورة '+v,'سورة '+ar(i+1)]));
    for(const type of ['azkar','duas']) for(const c of window.AZ_DB[type]) entries.push([`azcat/${type}/${c.k}`,c.t,type==='azkar'?'أذكار':'أدعية']);
    HADITH_BOOKS.forEach(b=>entries.push(['hbook/'+b.key,b.name,'كتاب حديث']));
    view.innerHTML=`<form id="diForm"><label for="diQuery" class="di-heading">ماذا تريد أن تقرأ؟</label><input id="diQuery" class="search" type="search" autocomplete="off" placeholder="مثلاً: الكهف، أذكار السفر، البخاري"><button class="btn" type="submit" disabled>بحث في نص الآيات</button></form><p id="diCount" class="muted" role="status"></p><div id="diResults"></div>`;
    const q=view.querySelector('input'), form=view.querySelector('form'), out=view.querySelector('#diResults'), status=view.querySelector('#diCount');let seq=0;
    const draw=()=>{seq++; const v=QuranLocal.normalize(q.value.trim());form.querySelector('button').disabled=v.length<2;
      const rows=v?entries.filter(([r,t,m])=>QuranLocal.normalize(t+' '+m).includes(v)||r==='surah/'+v):entries.slice(0,8);
      status.textContent=v?(rows.length?ar(rows.length)+' نتيجة':'لا توجد عناوين مطابقة. يمكنك البحث في نص الآيات.'):'اختصارات';out.innerHTML=rows.map(e=>link(...e)).join('');};
    q.oninput=draw;form.onsubmit=async e=>{e.preventDefault();if(q.value.trim().length<2)return;const id=++seq;status.textContent='جارٍ البحث في المصحف…';out.replaceChildren();try{const {count,matches}=await QuranLocal.search(q.value);if(id!==seq)return;status.textContent=count?ar(count)+' نتيجة'+(count>100?' • أول ١٠٠':''):'لا توجد آيات مطابقة';out.innerHTML=matches.map(a=>link(`surah/${a.surah.number}/${a.numberInSurah}`,a.text,a.surah.name+' • '+ar(a.numberInSurah))).join('');}catch{if(id===seq)status.textContent='تعذّر فتح المصحف. أعد المحاولة.';}};draw();return ()=>{seq++;};
  }};
});
