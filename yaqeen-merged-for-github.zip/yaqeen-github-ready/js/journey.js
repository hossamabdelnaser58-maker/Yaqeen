/* أدوات متابعة شخصية محلية ونسخ احتياطي وبحث في محتوى التطبيق. */
(window.NoorModules = window.NoorModules || []).push((N) => {
  'use strict';
  const { $, $$, store, toast, go, ar, esc, routes } = N;
  const STORAGE_KEY = 'journey:v1';
  const HABITS = [
    ['quran', 'قراءة ورد من القرآن'],
    ['review', 'حفظ أو مراجعة القرآن'],
    ['adhkar', 'قراءة الأذكار'],
    ['prayer', 'متابعة الصلوات'],
    ['kindness', 'عمل خير أو إحسان'],
  ];
  const LEVELS = ['مبتدئ', 'متوسط', 'متقدم'];
  const dayKey = (d = new Date()) => N.ymdIn(d, N.tz()).map((x) => String(x).padStart(2, '0')).join('-');
  const dateObj = (key) => new Date(`${key}T12:00:00`);
  const safeState = () => {
    const raw = store.get(STORAGE_KEY, {});
    const state = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
    if (!state.days || typeof state.days !== 'object' || Array.isArray(state.days)) state.days = {};
    if (!state.goal || typeof state.goal !== 'object') state.goal = {};
    state.goal.habit = HABITS.some(([k]) => k === state.goal.habit) ? state.goal.habit : 'quran';
    state.goal.weekly = Math.max(1, Math.min(7, Number(state.goal.weekly) || 5));
    state.goal.monthly = Math.max(1, Math.min(31, Number(state.goal.monthly) || 20));
    return state;
  };
  const save = (state) => store.set(STORAGE_KEY, state);
  const escAttr = esc;
  const stateLabel = (k) => HABITS.find(([id]) => id === k)?.[1] || '';
  const shortDay = (d) => d.toLocaleDateString('ar-EG', { weekday: 'short' });
  const recentKeys = (count) => Array.from({ length: count }, (_, i) => {
    const d = new Date(); d.setDate(d.getDate() - (count - 1 - i)); return dayKey(d);
  });

  function renderJourney() {
    const s = safeState();
    const today = dayKey();
    const todayMarks = s.days[today] || {};
    const weekStart = new Date(); weekStart.setHours(12, 0, 0, 0);
    weekStart.setDate(weekStart.getDate() - ((weekStart.getDay() + 1) % 7));
    const week = Array.from({ length: 7 }, (_, i) => { const d = new Date(weekStart); d.setDate(d.getDate() + i); return d; });
    const wkCount = week.filter((d) => !!(s.days[dayKey(d)] || {})[s.goal.habit]).length;
    const monthKey = today.slice(0, 7);
    const monthCount = Object.entries(s.days).filter(([k, v]) => k.startsWith(monthKey) && v && v[s.goal.habit]).length;
    const recent = recentKeys(7);
    const monthTarget = Math.min(s.goal.monthly, new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).getDate());

    N.view.innerHTML = `
      <div class="journey">
        <section class="jr-intro">
          <div><p class="jr-kicker">متابعة شخصية على جهازك</p><h2>رحلتي</h2><p>سجّل ما تريد متابعته، وحدّد هدفاً واقعياً لك. هذه السجلات للتذكير الشخصي وليست تقييماً للأعمال.</p></div>
        </section>
        <section class="jr-section">
          <div class="jr-section-head"><h3>متابعة اليوم</h3><span>${esc(new Intl.DateTimeFormat('ar-EG', { dateStyle: 'full' }).format(new Date()))}</span></div>
          <div class="jr-habits">${HABITS.map(([k, label]) => `<label class="jr-habit"><input type="checkbox" data-habit="${k}" ${todayMarks[k] ? 'checked' : ''}><span>${label}</span></label>`).join('')}</div>
          <div class="jr-week" aria-label="متابعة الأسبوع">${week.map((d) => { const k = dayKey(d); const checked = !!(s.days[k] || {})[s.goal.habit]; return `<div class="jr-day ${checked ? 'is-done' : ''}" title="${escAttr(k)}"><span>${shortDay(d)}</span><b>${checked ? '✓' : '·'}</b></div>`; }).join('')}</div>
          <p class="jr-caption">الأيام المسجّلة لهدف «${esc(stateLabel(s.goal.habit))}» هذا الأسبوع: <b>${ar(wkCount)} من ${ar(s.goal.weekly)}</b></p>
        </section>
        <section class="jr-section">
          <div class="jr-section-head"><h3>أهدافي</h3><span>اختر هدفاً وعدّل عدد الأيام</span></div>
          <form id="jrGoal" class="jr-goal-form">
            <label>ما الذي تريد متابعته؟<select id="jrHabit">${HABITS.map(([k, label]) => `<option value="${k}" ${s.goal.habit === k ? 'selected' : ''}>${label}</option>`).join('')}</select></label>
            <label>أيام في الأسبوع<input id="jrWeekTarget" type="number" min="1" max="7" value="${s.goal.weekly}"></label>
            <label>أيام في الشهر<input id="jrMonthTarget" type="number" min="1" max="31" value="${s.goal.monthly}"></label>
            <button class="btn" type="submit">حفظ الهدف</button>
          </form>
          <div class="jr-goal-summary"><b>${ar(monthCount)} / ${ar(monthTarget)}</b><span>أيام هذا الشهر لهدف «${esc(stateLabel(s.goal.habit))}»</span><div class="jr-meter" role="progressbar" aria-label="أيام الهدف المسجّلة هذا الشهر" aria-valuemin="0" aria-valuemax="${monthTarget}" aria-valuenow="${Math.min(monthCount, monthTarget)}"><i style="width:${Math.min(100, Math.round(monthCount / Math.max(1, monthTarget) * 100))}%"></i></div></div>
        </section>
        <section class="jr-section">
          <div class="jr-section-head"><h3>سجل الأسبوع</h3><span>عدد الاختيارات التي سجّلتها يومياً</span></div>
          <div class="jr-week-summary">${recent.map((k) => { const marks = HABITS.filter(([id]) => !!(s.days[k] || {})[id]).length; return `<div><span>${esc(dateObj(k).toLocaleDateString('ar-EG', { weekday: 'short', day: 'numeric' }))}</span><b>${ar(marks)}</b></div>`; }).join('')}</div>
        </section>
        <section class="jr-section">
          <div class="jr-section-head"><h3>تذكير يومي</h3><span>إشعار محلي على جهاز أندرويد</span></div>
          <div class="jr-reminder"><label for="jrTime">الوقت</label><input id="jrTime" type="time" value="${escAttr(s.reminder || '')}"><button class="btn ghost" id="jrReminderSave">${s.reminder ? 'تحديث التذكير' : 'تفعيل التذكير'}</button><button class="btn ghost" id="jrReminderOff" ${s.reminder ? '' : 'disabled'}>إيقاف</button></div>
          <p class="jr-caption">لا يُرسل المتصفح إشعاراً إذا أُغلق؛ يلزم استخدام تطبيق أندرويد والسماح بالإشعارات.</p><div id="jrReminderError" role="status" class="jr-error" hidden></div>
        </section>
        <section class="jr-section">
          <div class="jr-section-head"><h3>نسخة بياناتك</h3><span>تصدير أو استعادة ما حُفظ على هذا الجهاز</span></div>
          <div class="jr-backup"><button class="btn ghost" id="jrExport">تصدير نسخة احتياطية</button><button class="btn ghost" id="jrImportBtn">استعادة نسخة احتياطية</button><input id="jrImport" type="file" accept="application/json,.json" hidden><span id="jrBackupStatus" role="status"></span></div>
          <p class="jr-caption">النسخة تتضمن مفاتيح البيانات المحلية التي يستخدمها يقين، وقد تحتوي على تفضيلاتك وسجلاتك.</p>
        </section>
      </div>`;

    $$('[data-habit]', N.view).forEach((input) => input.addEventListener('change', () => {
      const fresh = safeState();
      if (!fresh.days[today] || typeof fresh.days[today] !== 'object') fresh.days[today] = {};
      fresh.days[today][input.dataset.habit] = input.checked;
      save(fresh); renderJourney();
    }));
    $('#jrGoal').addEventListener('submit', (e) => {
      e.preventDefault();
      const fresh = safeState();
      fresh.goal.habit = $('#jrHabit').value;
      fresh.goal.weekly = Math.max(1, Math.min(7, Number($('#jrWeekTarget').value) || 1));
      fresh.goal.monthly = Math.max(1, Math.min(31, Number($('#jrMonthTarget').value) || 1));
      save(fresh); toast('تم حفظ هدفك'); renderJourney();
    });
    $('#jrExport').onclick = exportBackup;
    $('#jrImportBtn').onclick = () => $('#jrImport').click();
    $('#jrImport').addEventListener('change', importBackup);
    $('#jrReminderSave').onclick = () => saveReminder($('#jrTime').value);
    $('#jrReminderOff').onclick = () => saveReminder('');
  }

  function renderGlobalSearch(queryArg) {
    let alive = true;
    const raw = queryArg ? decodeURIComponent(queryArg) : '';
    const normalize = (value) => String(value || '').replace(/[ً-ٰٟۖ-ۭـ]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').toLowerCase();
    const matches = (text, query) => {
      const hay = normalize(text); const words = normalize(query).split(/\s+/).filter(Boolean);
      return words.length > 0 && words.every((word) => hay.includes(word));
    };
    N.view.innerHTML = `<div class="journey"><section class="jr-section"><h2>بحث في محتويات يقين</h2><form id="jrSearchForm" class="jr-search-form"><input id="jrSearchInput" type="search" aria-label="ابحث في محتويات يقين" value="${esc(raw)}" placeholder="اكتب كلمة أو موضوعاً" autocomplete="off"><button class="btn" type="submit">بحث</button></form><p class="jr-caption">يبحث في فهرس الأكاديمية والموسوعات والحديث، ويبحث في نص آيات القرآن عبر خدمة القرآن المتصلة بالإنترنت.</p></section><div id="jrSearchResults" aria-live="polite"></div></div>`;
    const input = $('#jrSearchInput');
    const output = $('#jrSearchResults');
    const run = async (q) => {
      if (q.trim().length < 2) { toast('اكتب حرفين على الأقل للبحث'); input.focus(); return; }
      output.innerHTML = '<div class="jr-section" role="status">جارٍ البحث في المحتوى المحلي ونص القرآن…</div>';
      const groups = [];
      const academyResults = typeof ACADEMY === 'undefined' ? [] : ACADEMY.flatMap((track) => (track.levels || []).flatMap((level, li) => (level.lessons || []).map((lesson, i) => ({ title: lesson, sub: `${track.title} · المستوى ${LEVELS[li]}`, route: `lesson/${track.id}/${li}/${i}`, text: `${track.title} ${lesson} ${level.goals || ''}` })))).filter((item) => matches(item.text, q)).slice(0, 12);
      if (academyResults.length) groups.push(['دروس الأكاديمية', academyResults]);
      const encyclopedia = window.ENC && window.ENC.pages ? Object.entries(window.ENC.pages).map(([title, page]) => ({ title, sub: `الموسوعات · ${page.source || 'مادة موسوعية'}`, route: `encw/${encodeURIComponent(title)}`, text: `${title} ${page.title || ''} ${page.intro || ''}` })).filter((item) => matches(item.text, q)).slice(0, 12) : [];
      if (encyclopedia.length) groups.push(['الموسوعات الإسلامية', encyclopedia]);
      const books = typeof HADITH_BOOKS === 'undefined' ? [] : HADITH_BOOKS.filter((book) => matches(`${book.name} ${book.author}`, q)).map((book) => ({ title: book.name, sub: `${book.author} · بحث في الكتاب المتاح على الجهاز`, route: `hbook/${book.key}`, text: `${book.name} ${book.author}` }));
      const sections = typeof HADITH_SECTIONS === 'undefined' ? [] : Object.entries(HADITH_SECTIONS).flatMap(([key, names]) => {
        const book = typeof HADITH_BOOKS === 'undefined' ? null : HADITH_BOOKS.find((item) => item.key === key);
        return (names || []).map((name, i) => ({ title: name, sub: `أبواب ${book?.name || key}`, route: `hsearch/${key}/${encodeURIComponent(q)}`, text: `${name} ${book?.name || ''}` }));
      }).filter((item) => matches(item.text, q)).slice(0, 10);
      const hadithResults = [...books, ...sections].slice(0, 12);
      if (hadithResults.length) groups.push(['فهرس الحديث', hadithResults]);
      const surahs = typeof SURAH_NAMES === 'undefined' ? [] : SURAH_NAMES.map((name, i) => ({ title: name, sub: `السورة ${ar(i + 1)} · فتح المصحف`, route: `surah/${i + 1}`, text: `${name} ${i + 1}` })).filter((item) => matches(item.text, q)).slice(0, 8);
      if (surahs.length) groups.push(['السور', surahs]);
      let quranBlock = '<section class="jr-section"><h3>آيات القرآن</h3><p class="jr-caption">لا يتوفر اتصال بخدمة البحث الآن. تبقى نتائج الفهارس المحلية أعلاه متاحة.</p></section>';
      try {
        const data = await N.fetchJSON(`${N.API}/search/${encodeURIComponent(normalize(q))}/all/quran-simple-clean`, `global-search:${normalize(q)}`);
        const found = data && Array.isArray(data.matches) ? data.matches.slice(0, 15) : [];
        quranBlock = `<section class="jr-section"><div class="jr-section-head"><h3>آيات القرآن</h3><span>${ar(found.length)} نتيجة</span></div>${found.length ? found.map((item) => `<button class="yq-gold-row jr-search-result" data-route="surah/${item.surah.number}/${item.numberInSurah}"><b>${esc(item.text)}</b><small>${esc(item.surah.name)} · الآية ${ar(item.numberInSurah)}</small></button>`).join('') : '<p class="jr-caption">لم تظهر آيات مطابقة لهذه العبارة.</p>'}</section>`;
      } catch { /* تظهر الفهارس المحلية مع تنبيه البحث */ }
      if (!alive) return;
      output.innerHTML = `${groups.map(([title, results]) => `<section class="jr-section"><div class="jr-section-head"><h3>${title}</h3><span>${ar(results.length)} نتيجة</span></div>${results.map((item) => `<button class="yq-gold-row jr-search-result" data-route="${esc(item.route)}"><b>${esc(item.title)}</b><small>${esc(item.sub || '')}</small></button>`).join('')}</section>`).join('')}${quranBlock}${groups.length ? '<p class="jr-caption">تظهر النتائج من الفهارس والمحتوى المتاح في المشروع؛ قد لا تشمل كامل نصوص الكتب أو محتوى يتطلب اتصالاً بالخدمة.</p>' : '<section class="jr-section">لا توجد نتائج محلية مطابقة. جرّب عبارة أقصر أو كلمة أخرى.</section>'}`;
      $$('.jr-search-result', output).forEach((button) => button.addEventListener('click', () => go(button.dataset.route)));
    };
    $('#jrSearchForm').addEventListener('submit', (event) => { event.preventDefault(); void run(input.value); });
    if (raw.trim().length >= 2) void run(raw);
    return () => { alive = false; };
  }

  async function saveReminder(time) {
    const status = $('#jrReminderError');
    status.hidden = true;
    if (!time) {
      try {
        const ln = window.Capacitor?.Plugins?.LocalNotifications;
        if (N.NATIVE && ln) await ln.cancel({ notifications: [{ id: 4011 }] });
        const s = safeState(); s.reminder = ''; save(s); toast('تم إيقاف التذكير'); renderJourney();
      } catch { status.textContent = 'تعذّر إيقاف الإشعار على هذا الجهاز.'; status.hidden = false; }
      return;
    }
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) { status.textContent = 'اختر وقتاً صحيحاً أولاً.'; status.hidden = false; return; }
    const ln = window.Capacitor?.Plugins?.LocalNotifications;
    if (!N.NATIVE || !ln) { status.textContent = 'التذكير بعد إغلاق التطبيق متاح في تطبيق أندرويد فقط.'; status.hidden = false; return; }
    try {
      let permission = await ln.checkPermissions();
      if (permission.display !== 'granted') permission = await ln.requestPermissions();
      if (permission.display !== 'granted') { status.textContent = 'لم يتم منح إذن الإشعارات؛ يمكنك تفعيله من إعدادات الهاتف.'; status.hidden = false; return; }
      await ln.cancel({ notifications: [{ id: 4011 }] });
      await ln.createChannel({ id: 'journey', name: 'تذكيرات يقين', description: 'تذكير يومي اختياري بمتابعة أهدافك الشخصية', importance: 3, visibility: 1 });
      const [hour, minute] = time.split(':').map(Number);
      await ln.schedule({ notifications: [{ id: 4011, title: 'تذكيرك من يقين', body: 'افتح رحلتك الشخصية وسجّل ما ترغب بمتابعته اليوم.', channelId: 'journey', schedule: { on: { hour, minute }, allowWhileIdle: true }, extra: { route: 'journey' }, autoCancel: true }] });
      const s = safeState(); s.reminder = time; save(s); toast('تم تفعيل التذكير اليومي'); renderJourney();
    } catch { status.textContent = 'تعذّر ضبط الإشعار. تحقّق من أذونات الإشعارات وحاول مرة أخرى.'; status.hidden = false; }
  }

  function localEntries() {
    const out = {};
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && (key.startsWith('yaqeen:') || key.startsWith('noor:'))) out[key] = localStorage.getItem(key);
      }
    } catch { throw new Error('تعذّر قراءة البيانات المحلية'); }
    return out;
  }
  async function exportBackup() {
    const status = $('#jrBackupStatus');
    status.textContent = '';
    try {
      const payload = { format: 'yaqeen-local-backup', version: 1, exportedAt: new Date().toISOString(), entries: localEntries() };
      const text = JSON.stringify(payload, null, 2);
      const fs = window.Capacitor?.Plugins?.Filesystem;
      const share = window.Capacitor?.Plugins?.Share;
      if (N.NATIVE && fs && share) {
        const file = await fs.writeFile({ path: `yaqeen-backup-${dayKey()}.json`, data: text, directory: 'CACHE', encoding: 'utf8' });
        await share.share({ title: 'نسخة بيانات يقين', dialogTitle: 'حفظ النسخة أو مشاركتها', files: [file.uri] });
      } else {
        const blob = new Blob([text], { type: 'application/json;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const anchor = document.createElement('a'); anchor.href = url; anchor.download = `yaqeen-backup-${dayKey()}.json`; document.body.appendChild(anchor); anchor.click(); anchor.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
      }
      status.textContent = 'أُعدّت النسخة. احفظها في مكان آمن.';
    } catch { status.textContent = 'تعذّر تصدير البيانات. جرّب مرة أخرى من جهازك.'; }
  }
  async function importBackup(event) {
    const input = event.target;
    const status = $('#jrBackupStatus');
    status.textContent = '';
    const file = input.files && input.files[0];
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      if (!data || data.format !== 'yaqeen-local-backup' || data.version !== 1 || !data.entries || typeof data.entries !== 'object' || Array.isArray(data.entries)) throw new Error('invalid');
      const pairs = Object.entries(data.entries);
      if (pairs.length > 2000 || pairs.some(([key, value]) => !(key.startsWith('yaqeen:') || key.startsWith('noor:')) || typeof value !== 'string')) throw new Error('invalid');
      if (!window.confirm(`ستُستبدل البيانات المحلية المفاتيح الموجودة في النسخة (${ar(pairs.length)}). يُفضّل تصدير نسخة حالية قبل الاستعادة. متابعة؟`)) { input.value = ''; return; }
      const previous = pairs.map(([key]) => [key, localStorage.getItem(key)]);
      try {
        pairs.forEach(([key, value]) => localStorage.setItem(key, value));
      } catch (writeError) {
        previous.forEach(([key, value]) => { if (value === null) localStorage.removeItem(key); else localStorage.setItem(key, value); });
        throw writeError;
      }
      status.textContent = 'اكتملت الاستعادة. سيُعاد فتح يقين لقراءة البيانات.';
      setTimeout(() => location.reload(), 700);
    } catch (error) {
      status.textContent = error instanceof SyntaxError ? 'الملف ليس نسخة JSON صالحة.' : 'تعذّرت الاستعادة؛ استخدم نسخة يقين صالحة وتأكد من توفر مساحة.';
    } finally { input.value = ''; }
  }

  routes.journey = { title: 'رحلتي', render: renderJourney, back: 'home' };
  routes.search = { title: 'بحث في المحتوى', render: renderGlobalSearch, back: 'home' };
  N.homeExtras.push((root) => {
    if (!root) return;
    const button = document.createElement('button');
    button.className = 'yq-gold-row jr-home';
    button.innerHTML = '<span><b>رحلتي</b><small>متابعة شخصية، أهداف ونسخ احتياطي</small></span><span aria-hidden="true">‹</span>';
    button.addEventListener('click', () => go('journey'));
    root.appendChild(button);
  });
});
