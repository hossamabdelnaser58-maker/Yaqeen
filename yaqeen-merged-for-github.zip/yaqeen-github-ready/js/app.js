/* يقين — رفيق المسلم | المنطق الرئيسي للتطبيق */
(() => {
  'use strict';

  // ---------- أدوات مساعدة ----------
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const view = $('#view');
  const ar = (n) => Number(n).toLocaleString('ar-EG', { useGrouping: false });
  const arG = (n) => Number(n).toLocaleString('ar-EG');
  // تنسيق حجم ملف بالبايت → «١٤٫٢ م.ب» (يُستخدم في حوار التحديث وشريط التقدّم).
  const fmtBytes = (n) => {
    const v = Number(n);
    if (!Number.isFinite(v) || v < 0) return '';
    if (v < 1024) return `${arG(v)} ب`;
    if (v < 1048576) return `${toAr((v / 1024).toFixed(1))} ك.ب`;
    if (v < 1073741824) return `${toAr((v / 1048576).toFixed(1))} م.ب`;
    return `${toAr((v / 1073741824).toFixed(1))} غ.ب`;
  };
  const pad = (n) => String(n).padStart(2, '0');
  const toAr = (s) => String(s).replace(/\d/g, (d) => '٠١٢٣٤٥٦٧٨٩'[d]);
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // بادئة التخزين «yaqeen:» (المرحلة 4، 19 تشرين الثاني 2026). ترحيل عند القراءة:
  // إن غاب مفتاح «yaqeen:<k>» يُقرأ المفتاح القديم «noor:<k>» ويُنسخ إلى
  // «yaqeen:<k>» ويُعاد، فلا يفقد المستخدمون الحاليون أي بيانات. تُكتب
  // القيم الجديدة ببادئة «yaqeen:» فقط. يُبقي المفتاح القديم كمصدر احتياطي
  // للقراءة؛ إزالته لاحقاً قرار منفصل بعد إصدارين.
  const store = {
    get(k, d) { try { let v = localStorage.getItem('yaqeen:' + k); if (v == null) { const old = localStorage.getItem('noor:' + k); if (old != null) { try { localStorage.setItem('yaqeen:' + k, old); } catch { /* تجاهل */ } v = old; } } return v == null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem('yaqeen:' + k, JSON.stringify(v)); } catch { /* تجاهل */ } },
  };

  const DEFAULTS = {
    location: { name: 'القاهرة', lat: 30.0444, lng: 31.2357, tz: 'Africa/Cairo' },
    method: 'egypt',
    asr: 1,
    theme: 'light',
    qsize: 1.9,
    reciter: 'ar.alafasy',
    repeat: 1,
    translation: '',
    alerts: false,
    adhanSound: { fajr: 'voice', dhuhr: 'voice', asr: 'voice', maghrib: 'voice', isha: 'voice' },
    alertOff: [],
    pre: 0,
  };
  const NATIVE = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  // مصدر النسخة الواحد (js/version.js ← version.json؛ انظر docs/update-system.md §1).
  // BUILD.code هو رمز البناء الفعلي (من native-flags.js: متغير البيئة أو
  // version.json) فيتقدّم عند المقارنة؛ وYAQEEN_VERSION احتياطي وعرض.
  const YAQEEN_VERSION = window.YAQEEN_VERSION || { versionName: '2.5.0', versionCode: 1, buildDate: '' };
  const CURRENT_CODE = (typeof window !== 'undefined' && window.NOOR_BUILD && window.NOOR_BUILD.code) || YAQEEN_VERSION.versionCode || 0;
  const CURRENT_NAME = (window.NOOR_BUILD && window.NOOR_BUILD.versionName) || YAQEEN_VERSION.versionName || '2.5.0';
  const versionLabel = () => `الإصدار ${toAr(CURRENT_NAME)} (رمز ${arG(CURRENT_CODE)})`;
  if (NATIVE) DEFAULTS.alerts = true;
  const settings = Object.assign({}, DEFAULTS, store.get('settings', {}));
  // تطبيع إعدادات الأذان لكل صلاة (قيم قديمة أو ناقصة ← 'voice')
  if (!settings.adhanSound || typeof settings.adhanSound !== 'object') settings.adhanSound = {};
  for (const k of ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha']) if (!['voice', 'beep', 'silent'].includes(settings.adhanSound[k])) settings.adhanSound[k] = 'voice';
  if (!Array.isArray(settings.alertOff)) settings.alertOff = [];
  // الثيم الفاتح هو الافتراضي؛ من لم يختر ثيماً بنفسه ينتقل إلى الفاتح
  if (settings.theme === 'auto' && !store.get('themeChosen', false)) settings.theme = 'light';
  const saveSettings = () => { store.set('settings', settings); if (typeof scheduleAdhan === 'function') scheduleAdhan(); };

  const RECITERS = {
    'ar.alafasy': { name: 'مشاري راشد العفاسي', br: 128 },
    'ar.husary': { name: 'محمود خليل الحصري', br: 128 },
    'ar.minshawi': { name: 'محمد صديق المنشاوي', br: 128 },
    'ar.abdulbasitmurattal': { name: 'عبد الباسط عبد الصمد', br: 192 },
    'ar.mahermuaiqly': { name: 'ماهر المعيقلي', br: 128 },
  };

  const TRANSLATIONS = {
    '': 'بدون ترجمة',
    'en.sahih': 'English — Saheeh International',
    'fr.hamidullah': 'Français — Hamidullah',
    'de.bubenheim': 'Deutsch — Bubenheim',
    'es.cortes': 'Español — Cortés',
    'tr.diyanet': 'Türkçe — Diyanet',
    'id.indonesian': 'Bahasa Indonesia',
    'ur.jalandhry': 'اردو — جالندھری',
  };

  // أيقونات الصلوات من مجموعة الرموز الموحّدة (sprite المضمَّن في index.html) — بلا إيموجي
  const pIc = (k) => `<svg class="pi" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-${k}"/></svg>`;
  const PRAYERS = [
    { key: 'fajr', name: 'الفجر', ic: pIc('fajr') },
    { key: 'sunrise', name: 'الشروق', ic: pIc('sunrise'), sun: true },
    { key: 'dhuhr', name: 'الظهر', ic: pIc('dhuhr') },
    { key: 'asr', name: 'العصر', ic: pIc('asr') },
    { key: 'maghrib', name: 'المغرب', ic: pIc('maghrib') },
    { key: 'isha', name: 'العشاء', ic: pIc('isha') },
  ];

  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => t.classList.remove('show'), 2400);
  }

  function applyTheme() {
    const brown = settings.theme === 'brown';
    const dark = brown || settings.theme === 'dark' || (settings.theme === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    if (brown) document.documentElement.dataset.skin = 'brown'; else delete document.documentElement.dataset.skin;
    $('meta[name="theme-color"]').content = brown ? '#0b0d0c' : dark ? '#0b1512' : '#0d3b2e';
  }
  matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);

  // ---------- التاريخ والمواقيت ----------
  const tz = () => settings.location.tz || undefined;

  function ymdIn(date, timeZone) {
    const p = new Intl.DateTimeFormat('en-CA', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(date);
    const g = (t) => +p.find((x) => x.type === t).value;
    return [g('year'), g('month'), g('day')];
  }

  function timesFor(date) {
    const [y, m, d] = ymdIn(date, tz());
    const { lat, lng } = settings.location;
    const t = PrayTimes.compute(y, m, d, lat, lng, settings.method, settings.asr);
    const adj = settings.adj || {};
    Object.keys(adj).forEach((k) => { if (t[k] && adj[k]) t[k] = new Date(t[k].getTime() + adj[k] * 60000); });
    return t;
  }

  const fmtTime = (d) => d.toLocaleTimeString('ar-EG', { hour: 'numeric', minute: '2-digit', timeZone: tz() });
  const hijri = (d) => {
    try {
      return new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura-nu-arab', { day: 'numeric', month: 'long', year: 'numeric', timeZone: tz() }).format(new Date(d.getTime() + (settings.hijriAdj || 0) * 864e5));
    } catch { return ''; }
  };
  const greg = (d) => d.toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: tz() });

  function nextPrayer(now = new Date()) {
    const t = timesFor(now);
    for (const p of PRAYERS) {
      if (p.sun) continue;
      if (t[p.key] > now) return { ...p, time: t[p.key] };
    }
    const tomorrow = new Date(now.getTime() + 86400000);
    return { ...PRAYERS[0], time: timesFor(tomorrow).fajr };
  }

  function countdown(ms) {
    const s = Math.max(0, Math.floor(ms / 1000));
    return toAr(`${pad(Math.floor(s / 3600))}:${pad(Math.floor((s % 3600) / 60))}:${pad(s % 60)}`);
  }

  const dayIndex = () => Math.floor(Date.now() / 86400000);

  // ---------- الموجّه (Router) ----------
  const routes = {
    home: { title: 'يقين', render: renderHome },
    prayers: { title: 'مواقيت الصلاة', render: renderPrayers },
    adhan: { title: 'الأذان', render: renderAdhan, back: 'home' },
    quran: { title: 'القرآن الكريم', render: renderQuran },
    surah: { title: 'القرآن الكريم', render: renderSurah, back: 'quran' },
    azkar: { title: 'الأذكار', render: renderAzkarList },
    zikr: { title: 'الأذكار', render: renderAzkar, back: 'azkar' },
    tasbih: { title: 'السبحة الإلكترونية', render: renderTasbih },
    qibla: { title: 'اتجاه القبلة', render: renderQibla, back: 'home' },
    names: { title: 'أسماء الله الحسنى', render: renderNames, back: 'home' },
    settings: { title: 'الإعدادات', render: renderSettings, back: 'home' },
    juz: { title: 'القرآن الكريم', render: renderJuz, back: 'quran' },
    khatma: { title: 'ختمة القرآن', render: renderKhatma, back: 'home' },
    tracker: { title: 'متابعة الصلوات', render: renderTracker, back: 'home' },
    calendar: { title: 'التقويم الهجري', render: renderCalendar, back: 'home' },
    zakat: { title: 'حاسبة الزكاة', render: renderZakat, back: 'home' },
    bookmarks: { title: 'العلامات المحفوظة', render: renderBookmarks, back: 'home' },
    about: { title: 'عن التطبيق', render: renderAbout, back: 'home' },
    sources: { title: 'المصادر والتراخيص', render: renderSources, back: 'home' },
  };

  let cleanup = null;
  let renderSeq = 0;
  function router() {
    const [name, arg, arg2, arg3] = (location.hash.slice(2) || 'home').split('/');
    const route = routes[name] || routes.home;
    if (typeof cleanup === "function") { try { cleanup(); } catch (e) { console.error(e); } } cleanup = null;
    $$('.sheet-backdrop').forEach((e) => e.remove());
    $('#pageTitle').textContent = route.title;
    document.body.dataset.route = routes[name] ? name : 'home';
    $('#backBtn').hidden = !route.back;
    $('#backBtn').onclick = () => history.length > 1 ? history.back() : go(route.back);
    const tab = { surah: 'quran', juz: 'quran', zikr: 'azkar', audio: 'quran', reciter: 'quran', player: 'quran', compare: 'quran', playlist: 'quran', repeat: 'quran', hifz: 'quran', hifzs: 'quran', hifzp: 'quran', hifzplan: 'quran', azcat: 'azkar', azsearch: 'azkar', azfav: 'azkar', azlists: 'azkar', azlist: 'azkar', azset: 'azkar', azabout: 'azkar', ptable: 'prayers', adhan: 'prayers', mpage: 'quran', surah: 'quran' }[name] || name;
    $$('#tabbar button').forEach((b) => b.classList.toggle('active', b.dataset.route === tab));
    view.innerHTML = '';
    view.className = 'fade-in';
    void view.offsetWidth;
    const out = route.render(arg, arg2, arg3);
    if (out && typeof out.then === "function") { const mine = ++renderSeq; out.then((fn) => { if (typeof fn !== "function") return; if (mine === renderSeq) cleanup = fn; else fn(); }).catch(() => {}); } else { cleanup = out || null; renderSeq++; }
    window.scrollTo(0, 0);
  }
  // يشيل الإيموجي الزخرفية المتبقية من النصوص (تبقى الأزرار التي ليس فيها غير إيموجي، وعلامات الوظائف)
  const EMOJI_RE = /[\p{Extended_Pictographic}\uFE0F]\s*/gu;
  const EMOJI_TEST = /\p{Extended_Pictographic}/u;
  function deEmoji(root) {
    const walk = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    for (let n = walk.nextNode(); n; n = walk.nextNode()) if (EMOJI_TEST.test(n.nodeValue)) nodes.push(n);
    nodes.forEach((n) => {
      const host = n.parentElement;
      if (!host || /^(SCRIPT|STYLE|TEXTAREA)$/.test(host.tagName)) return;
      const rest = n.nodeValue.replace(EMOJI_RE, '').trim();
      if (!rest && !host.textContent.replace(EMOJI_RE, '').trim()) return; // زر/عنصر إيموجي فقط: نتركه
      n.nodeValue = n.nodeValue.replace(EMOJI_RE, '');
    });
  }
  // المحتوى يُرسم أيضاً بعد جلب البيانات، فنراقب العرض بدل استدعاء واحد
  let deRaf = 0;
  new MutationObserver(() => { if (!deRaf) deRaf = requestAnimationFrame(() => { deRaf = 0; deEmoji(view); }); }).observe(view, { childList: true, subtree: true });
  const go = (r) => { location.hash = '#/' + r; };

  $$('#tabbar button').forEach((b) => b.addEventListener('click', () => go(b.dataset.route)));
  $('#settingsBtn').addEventListener('click', () => go('settings'));
  $('#searchBtn').setAttribute('aria-label', 'بحث في المحتوى');
  $('#searchBtn').addEventListener('click', () => go('search'));
  window.addEventListener('hashchange', router);

  // ---------- الرئيسية ----------
  // Editorial Manuscript (يقين): wordmark + mihrab hero + 6-prayer timeline
  // + featured verse + numbered index. Data/logic unchanged: nextPrayer,
  // countdown tick, DAILY_AYAT/HADITH, lastRead, zikrKey, homeExtras.
  // ---------- الإهداء في أعلى الرئيسية ----------
  // نص حرفي ثابت، بلا صورة للمتوفى ولا صورة مولَّدة. يُعرض مباشرة تحت
  // wordmark «يقين» في أعلى الشاشة (renderHome وrenderDash)، فيظهر عند
  // أول فتح دون تمرير. النسخة الكاملة (مع الدعاء والأزرار) تبقى في «عن
  // التطبيق» وفي نص إتمام الختمة فقط؛ وحُذف الإهداء المكرر من تذييل الرئيسية.
  function dedicationTopHTML() {
    return `
      <div class="hm-ded">
        <span class="hm-ded-mark" aria-hidden="true"><svg viewBox="0 0 24 24"><use href="#i-duas"/></svg></span>
        <div>
          <p class="hm-ded-label">صدقة جارية</p>
          <p class="hm-ded-name">عبدالناصر عمران</p>
          <p class="hm-ded-dua">صدقة جارية على روح والدي عبدالناصر عمران، رحمه الله وغفر له</p>
        </div>
      </div>`;
  }

  // أيقونة من مجموعة الرموز الموحّدة (sprite المضمَّن في index.html)
  const icon = (id, cls = '') => `<svg viewBox="0 0 24 24" aria-hidden="true"${cls ? ` class="${cls}"` : ''}><use href="#i-${id}"/></svg>`;
  // وقت الصلاة السابقة (لحلقة التقدّم): آخر صلاة من الخمس مرّت، وإلا عشاء الأمس
  function prevPrayerTime(n) {
    const t = timesFor(n);
    let best = null;
    for (const p of PRAYERS) { if (!p.sun && t[p.key] <= n && (!best || t[p.key] > best)) best = t[p.key]; }
    return best || timesFor(new Date(n.getTime() - 864e5)).isha;
  }
  const RING_C = 2 * Math.PI * 92;

  // الرئيسية — «محراب»: ترويسة التاريخ، حلقة الصلاة القادمة، يومك، أقسام مجمّعة، آية وحديث اليوم.
  // البيانات والمنطق كما هي: nextPrayer، العدّاد، DAILY_AYAT/HADITH، lastRead، zikrKey، homeExtras،
  // إحصاءات اليوم وبركات الجمعة (كانت في لوحة «أسمر» فصارت لكل الثيمات).
  function renderHome() {
    const now = new Date();
    const ayah = DAILY_AYAT[dayIndex() % DAILY_AYAT.length];
    const hadith = DAILY_HADITH[dayIndex() % DAILY_HADITH.length];
    const hour = +new Intl.DateTimeFormat('en-GB', { hour: 'numeric', hourCycle: 'h23', timeZone: tz() }).format(now);
    const zikrKey = hour >= 4 && hour < 12 ? 'morning' : 'evening';
    const last = store.get('lastRead');
    const t = timesFor(now);
    const keyOf = (d) => ymdIn(d, tz()).join('-');
    const tr = (store.get('tracker', {})[keyOf(now)]) || {};
    const prayed = PRAYERS.filter((p) => !p.sun && tr[p.key]).length;
    const az = (window.Noor.azStats && window.Noor.azStats()) || { done: 0, streak: 0, friDone: 0, friTotal: 0 };
    const kh = Object.assign({ done: [] }, store.get('khatma', {}));
    const wd = new Intl.DateTimeFormat('en-US', { weekday: 'short', timeZone: tz() }).format(now);
    const toFri = (5 - ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(wd) + 7) % 7;
    const friKey = 'fri:' + keyOf(new Date(now.getTime() + toFri * 864e5));
    const fri = Object.assign({ kahf: false, salawat: 0 }, store.get(friKey, {}));
    const friWhen = toFri === 0 ? 'اليوم' : toFri === 1 ? 'غداً' : 'الجمعة القادمة';

    // [المسار، الأيقونة، الاسم، أساسي؟]
    const groups = [
      ['القرآن الكريم', [['quran', 'quran', 'المصحف', 1], ['hifz', 'hifz', 'الحفظ'], ['khatma', 'khatma', 'الختمة'], ['bookmarks', 'bookmarks', 'العلامات']]],
      ['الاستماع', [['audio', 'audio', 'المكتبة الصوتية'], ['radio', 'radio', 'الإذاعة'], ['ibtihal', 'ibtihal', 'الابتهالات'], ['dawah', 'recitation', 'الدعوية']]],
      ['العلم الشرعي', [['hadith', 'hadith', 'الحديث'], ['enc', 'encyclopedia', 'الموسوعات'], ['academy', 'academy', 'الأكاديمية'], ['muntakhab', 'quran', 'منتخبات']]],
      ['عبادتك اليومية', [[`zikr/${zikrKey}`, 'azkar', AZKAR[zikrKey].title, 1], ['zikr/duas', 'duas', 'أدعية قرآنية'], ['tasbih', 'tasbih', 'السبحة'], ['prayers', 'prayer-times', 'المواقيت'], ['qibla', 'qibla', 'القبلة'], ['tracker', 'tracker', 'صلواتي']]],
      ['أدوات', [['calc', 'calculators', 'الحاسبات'], ['calendar', 'calendar', 'التقويم'], ['names', 'names', 'الأسماء الحسنى']]],
    ];
    const tile = ([r, i, n, key]) => `<button class="hm-tile${key ? ' is-key' : ''}" data-go="${r}"><span class="hm-tile-ic">${icon(i)}</span><span>${n}</span></button>`;
    const groupHTML = groups.map(([title, items]) => `
      <div class="v3-div">${icon('mark')}<span>${title}</span></div>
      <div class="hm-grid">${items.map(tile).join('')}</div>`).join('');

    const friHTML = `
      <section class="hm-fri">
        <button class="hm-fri-h" data-go="azcat/azkar/friday">
          <span class="ic">${icon('friday')}</span>
          <span><b>بركات الجمعة <em>${friWhen}</em></b><small>سورة الكهف، الصلاة على النبي ﷺ، ساعة الإجابة</small></span>
        </button>
        <div class="hm-fri-row">
          <button id="fKahf"><b>${fri.kahf ? '✓ قُرئت' : 'لم تُقرأ'}</b><small>سورة الكهف</small></button>
          <button id="fSal"><b>${ar(fri.salawat)}</b><small>الصلاة على النبي</small></button>
          <button data-go="azcat/azkar/friday"><b>${ar(az.friDone)}/${ar(az.friTotal)}</b><small>أذكار الجمعة</small></button>
        </div>
      </section>`;

    view.innerHTML = `
    <div class="hm">
      <header class="hm-head">
        <div class="hm-head-row">
          <p class="hm-greet">السلام عليكم ورحمة الله</p>
          <span class="hm-loc">${icon('pin')}${esc(settings.location.name)}</span>
        </div>
        <h2 class="hm-hijri">${hijri(now)}</h2>
        <p class="hm-greg">${greg(now)}</p>
      </header>

      ${dedicationTopHTML()}

      <section class="hm-hero" aria-label="الصلاة القادمة">
        <p class="hm-eyebrow">الصلاة القادمة</p>
        <div class="hm-ring">
          <svg class="ring-svg" viewBox="0 0 200 200" aria-hidden="true">
            <circle class="r-ticks" cx="100" cy="100" r="96"/>
            <circle class="r-bg" cx="100" cy="100" r="86"/>
            <circle class="r-fg" id="ringFg" cx="100" cy="100" r="86" stroke-dasharray="${(2 * Math.PI * 86).toFixed(2)}" stroke-dashoffset="${(2 * Math.PI * 86).toFixed(2)}"/>
          </svg>
          <div class="hm-ring-in">
            <div class="hm-next-name" id="nextName"></div>
            <div class="hm-next-time" id="nextTime"></div>
            <div class="hm-cd" id="cd" aria-live="off"></div>
            <div class="hm-cd-l">المتبقّي</div>
          </div>
        </div>
        <div class="hm-strip">
          ${PRAYERS.map((p) => `<div class="hm-pt" data-k="${p.key}">${icon(p.key)}<span>${p.name}</span><b>${fmtTime(t[p.key])}</b></div>`).join('')}
        </div>
      </section>

      <section class="hm-stats" aria-label="يومك مع يقين">
        <button class="hm-stat" data-go="tracker">${icon('tracker')}<b>${ar(prayed)}/${ar(5)}</b><small>الصلوات</small></button>
        <button class="hm-stat" data-go="khatma">${icon('khatma')}<b>${ar(kh.done.length)}/${ar(30)}</b><small>أجزاء الختمة</small></button>
        <button class="hm-stat" data-go="azkar">${icon('azkar')}<b>${ar(az.done)}</b><small>أذكار اليوم</small></button>
        <button class="hm-stat" data-go="azkar">${icon('flame')}<b>${ar(az.streak)}</b><small>يوم متتالٍ</small></button>
      </section>

      ${last ? `<button class="hm-resume" data-go="surah/${last.n}">
        <span class="hm-resume-ic">${icon('quran')}</span>
        <span><small>متابعة القراءة</small><b>${esc(last.name)}</b> <small style="display:inline">— الآية ${ar(last.ayah)}</small></span>
        ${icon('chev')}
      </button>` : ''}

      <div id="homeExtras"></div>

      ${toFri <= 1 ? friHTML : ''}

      ${groupHTML}

      <div class="v3-div">${icon('mark')}<span>آية اليوم</span></div>
      <section class="hm-verse">
        <span class="hm-verse-star">${icon('mark')}</span>
        <p class="hm-verse-text">﴿${ayah.text}﴾</p>
        <span class="hm-verse-ref">${ayah.ref}</span>
      </section>
      <section class="hm-hadith">
        <p>«${hadith.text}»</p>
        <small>حديث اليوم — ${hadith.ref}</small>
      </section>

      ${toFri > 1 ? friHTML : ''}

      <footer class="hm-foot">
        <button class="btn" data-go="zikr/deceased">أدعية للمتوفى</button>
        <button class="btn ghost" data-go="about">عن التطبيق</button>
        <button class="btn ghost" data-go="sources">المصادر والتراخيص</button>
      </footer>
    </div>
    `;
    $$('[data-go]', view).forEach((b) => b.addEventListener('click', () => go(b.dataset.go)));
    (window.Noor.homeExtras || []).forEach((fn) => { try { fn($('#homeExtras')); } catch (e) { console.error(e); } });
    const saveFri = () => store.set(friKey, fri);
    $('#fKahf').onclick = () => { fri.kahf = !fri.kahf; saveFri(); $('#fKahf b').textContent = fri.kahf ? '✓ قُرئت' : 'لم تُقرأ'; if (fri.kahf) toast('تقبّل الله منك 🤍'); };
    $('#fSal').onclick = () => { fri.salawat++; saveFri(); $('#fSal b').textContent = ar(fri.salawat); if (navigator.vibrate) navigator.vibrate(10); };

    let np = nextPrayer();
    let prev = prevPrayerTime(now);
    const ringLen = 2 * Math.PI * 86;
    const tick = () => {
      const n = new Date();
      if (n >= np.time) { np = nextPrayer(n); prev = prevPrayerTime(n); }
      $('#nextName').textContent = np.name;
      $('#nextTime').textContent = fmtTime(np.time);
      $('#cd').textContent = countdown(np.time - n);
      const frac = Math.min(1, Math.max(0, (n - prev) / (np.time - prev)));
      $('#ringFg').setAttribute('stroke-dashoffset', (ringLen * (1 - frac)).toFixed(2));
      const tt = timesFor(n);
      $$('.hm-pt', view).forEach((el) => {
        const k = el.dataset.k;
        el.classList.toggle('on', k === np.key);
        el.classList.toggle('past', k !== np.key && tt[k] < n);
      });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }

  // ---------- لوحة الرئيسية (ثيم «أسمر») ----------
  const P_ICON = {
    fajr: '<path d="M3 18h18M7 18a5 5 0 0 1 10 0M12 4v4M9 7l3-3 3 3M5 12l1.5 1M19 12l-1.5 1"/>',
    sunrise: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    dhuhr: '<circle cx="12" cy="12" r="5"/><path d="M12 1v3M12 20v3M1 12h3M20 12h3"/>',
    asr: '<path d="M7 18a4 4 0 0 1 0-8 5 5 0 0 1 9.6-1.5A4 4 0 1 1 17 18z"/><path d="M16 4l1-2M20 7l2-1"/>',
    maghrib: '<path d="M3 18h18M7 18a5 5 0 0 1 10 0M12 9v4M9 11l3 3 3-3"/>',
    isha: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
  };
  const DASH_LINES = [
    ['﴿فَاذْكُرُونِي أَذْكُرْكُمْ﴾', 'البقرة: ١٥٢'],
    ['«أحبّ الأعمال إلى الله أدومها وإن قلّ»', 'متفق عليه'],
    ['﴿أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ﴾', 'الرعد: ٢٨'],
    ['«خيركم من تعلّم القرآن وعلّمه»', 'رواه البخاري'],
    ['﴿وَاسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ﴾', 'البقرة: ٤٥'],
  ];
  const DASH_TILES = [['quran', '📖', 'القرآن'], ['audio', '🎧', 'الصوتيات'], ['radio', '📻', 'الإذاعة'], ['ibtihal', '🎙️', 'الابتهالات'], ['enc', '📚', 'الموسوعات'], ['azkar', '📿', 'الأذكار'], ['hifz', '🧠', 'الحفظ'], ['hadith', '📜', 'الحديث'], ['dawah', '🎬', 'الدعوية'], ['qibla', '🧭', 'القبلة'], ['names', '✨', 'الأسماء'], ['tasbih', '🤍', 'السبحة'], ['calendar', '📅', 'التقويم'], ['khatma', '📗', 'الختمة'], ['tracker', '✅', 'صلواتي'], ['calc', '🧮', 'الحاسبات'], ['bookmarks', '🔖', 'العلامات']];
  function renderDash() {
    const now = new Date();
    const t = timesFor(now);
    const ayah = DAILY_AYAT[dayIndex() % DAILY_AYAT.length];
    const keyOf = (d) => ymdIn(d, tz()).join('-');
    const tr = (store.get('tracker', {})[keyOf(now)]) || {};
    const prayed = PRAYERS.filter((p) => !p.sun && tr[p.key]).length;
    const az = (window.Noor.azStats && window.Noor.azStats()) || { done: 0, streak: 0, friDone: 0, friTotal: 0 };
    const kh = Object.assign({ done: [] }, store.get('khatma', {}));
    const wd = new Intl.DateTimeFormat('en-US', { weekday: 'short', timeZone: tz() }).format(now);
    const toFri = (5 - ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(wd) + 7) % 7;
    const friKey = 'fri:' + keyOf(new Date(now.getTime() + toFri * 864e5));
    const fri = Object.assign({ kahf: false, salawat: 0 }, store.get(friKey, {}));
    const line = DASH_LINES[dayIndex() % DASH_LINES.length];
    const last = store.get('lastRead');
    const friWhen = toFri === 0 ? 'اليوم' : toFri === 1 ? 'غداً' : 'الجمعة القادمة';
    view.innerHTML = `
      <header class="yq-wordmark yq-wordmark--compact">
        <h2 class="yq-wordmark-ar">يقين</h2>
        <span class="yq-wordmark-en">YAQEEN — رفيق المسلم</span>
      </header>

      ${dedicationTopHTML()}

      <section class="dash-prayer">
        <div class="dash-top">
          <div class="dash-where">
            <div class="dash-loc"><svg viewBox="0 0 24 24"><path d="M12 21s-7-6.2-7-12a7 7 0 0 1 14 0c0 5.8-7 12-7 12z"/><circle cx="12" cy="9" r="2.5"/></svg>${esc(settings.location.name)}</div>
            <div class="dash-date">${greg(now)}</div>
            <div class="dash-hijri">${hijri(now)}</div>
          </div>
          <div class="dash-next">
            <small>الصلاة القادمة</small>
            <b id="dNext"></b>
            <div class="dash-pill"><svg viewBox="0 0 24 24"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2.5M9 2h6"/></svg><span><small>متبقّي</small><span id="dCd"></span></span></div>
          </div>
        </div>
        <div class="dash-times" id="dTimes">${PRAYERS.map((p) => `<div class="dash-t" data-k="${p.key}"><svg viewBox="0 0 24 24">${P_ICON[p.key]}</svg><span>${p.name}</span><b>${fmtTime(t[p.key])}</b></div>`).join('')}</div>
      </section>

      <section class="card dash-day">
        <div class="dash-h"><h3>يومك مع يقين</h3><button class="dash-link" data-go="tracker">التفاصيل ‹</button></div>
        <div class="dash-stats">
          <button data-go="tracker"><svg viewBox="0 0 24 24"><path d="M4 21V10l8-6 8 6v11zM9 21v-6h6v6"/></svg><b>${ar(prayed)}/${ar(5)}</b><small>الصلوات</small></button>
          <button data-go="khatma"><svg viewBox="0 0 24 24"><path d="M12 6c-2-1.5-5-2-8-1.5V19c3-.5 6 0 8 1.5 2-1.5 5-2 8-1.5V4.5c-3-.5-6 0-8 1.5zM12 6v14.5"/></svg><b>${ar(kh.done.length)}/${ar(30)}</b><small>أجزاء الختمة</small></button>
          <button data-go="azkar"><svg viewBox="0 0 24 24"><path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.5-7 10-7 10z"/></svg><b>${ar(az.done)}</b><small>أذكار اليوم</small></button>
          <button data-go="azkar"><svg viewBox="0 0 24 24"><path d="M12 22c4 0 7-3 7-7 0-5-5-7-4-13-3 2-6 6-6 9-1-1-1.5-2.5-1.5-4C5 9.5 5 12 5 15c0 4 3 7 7 7z"/></svg><b>${ar(az.streak)}</b><small>يوم متتالٍ</small></button>
        </div>
        <div class="dash-line">${line[0]} <small>— ${line[1]}</small></div>
      </section>

      <section class="card dash-fri">
        <button class="dash-fri-h" data-go="azcat/azkar/friday">
          <span class="dash-fri-ic">🕌</span>
          <span class="dash-fri-t"><b>بركات الجمعة <em>${friWhen}</em></b><small>سورة الكهف، الصلاة على النبي ﷺ، ساعة الإجابة</small></span>
          <span class="dash-arrow">‹</span>
        </button>
        <div class="dash-fri-row">
          <button id="fKahf"><b>${fri.kahf ? '✓ قُرئت' : 'لم تُقرأ'}</b><small>سورة الكهف</small></button>
          <button id="fSal"><b>${ar(fri.salawat)}</b><small>الصلاة على النبي</small></button>
          <button data-go="azcat/azkar/friday"><b>${ar(az.friDone)}/${ar(az.friTotal)}</b><small>أذكار الجمعة</small></button>
        </div>
      </section>

      ${last ? `<ul class="yq-gold-rows"><li class="yq-gold-row" data-go="surah/${last.n}" style="cursor:pointer"><div class="yq-gold-row-body"><p class="yq-gold-row-title">متابعة القراءة — ${esc(last.name)}</p><p class="yq-gold-row-meta">الآية ${ar(last.ayah)}</p></div><span class="yq-gold-row-status">متابعة</span></li></ul>` : ''}

      <h3 class="dash-sec">الأقسام</h3>
      <ol class="yq-index">${DASH_TILES.map(([r, i, n], ix) => `<li class="yq-index-item" data-go="${r}" style="cursor:pointer"><span aria-hidden="true" style="font-size:1.3rem">${i}</span><span class="yq-index-num">${toAr(String(ix + 1).padStart(2, '0'))}</span><div class="yq-index-body"><h3 class="yq-index-title">${n}</h3></div><span aria-hidden="true">‹</span></li>`).join('')}</ol>
      <div id="homeExtras"></div>
      <div class="card"><h3>آية اليوم</h3><p class="ayah-text">﴿${ayah.text}﴾</p><div class="ref">${ayah.ref}</div></div>`;
    $$('[data-go]', view).forEach((b) => b.addEventListener('click', () => go(b.dataset.go)));
    (window.Noor.homeExtras || []).forEach((fn) => { try { fn($('#homeExtras')); } catch (e) { console.error(e); } });
    const saveFri = () => store.set(friKey, fri);
    $('#fKahf').onclick = () => { fri.kahf = !fri.kahf; saveFri(); $('#fKahf b').textContent = fri.kahf ? '✓ قُرئت' : 'لم تُقرأ'; if (fri.kahf) toast('تقبّل الله منك 🤍'); };
    $('#fSal').onclick = () => { fri.salawat++; saveFri(); $('#fSal b').textContent = ar(fri.salawat); if (navigator.vibrate) navigator.vibrate(10); };
    let np = nextPrayer();
    const tick = () => {
      const n = new Date();
      if (n >= np.time) np = nextPrayer(n);
      $('#dNext').textContent = np.name;
      $('#dCd').textContent = countdown(np.time - n);
      $$('#dTimes .dash-t').forEach((el) => el.classList.toggle('on', el.dataset.k === np.key));
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }

  // ---------- مواقيت الصلاة ----------
  function renderPrayers() {
    let offset = 0;
    const draw = () => {
      const now = new Date();
      const date = new Date(now.getTime() + offset * 86400000);
      const t = timesFor(date);
      const np = offset === 0 ? nextPrayer(now) : null;
      view.innerHTML = `
        <div class="date-nav">
          <button class="icon-btn" id="prev" aria-label="اليوم السابق"><svg viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></svg></button>
          <div class="d"><b>${offset === 0 ? 'اليوم' : greg(date)}</b><small>${hijri(date)}</small></div>
          <button class="icon-btn" id="next" aria-label="اليوم التالي"><svg viewBox="0 0 24 24"><path d="M15 6l-6 6 6 6"/></svg></button>
        </div>
        <ul class="yq-timeline">
          ${PRAYERS.map((p) => {
            const isNext = np && np.key === p.key && np.time.getTime() === t[p.key].getTime();
            const isPassed = offset === 0 && t[p.key] < now;
            return `<li class="yq-timeline-item ${isNext ? 'yq-timeline-item--now' : ''} ${isPassed ? 'yq-timeline-item--passed' : ''}"><span class="yq-timeline-dot"></span><span class="yq-timeline-label">${p.ic} ${p.name}</span><span class="yq-timeline-time">${fmtTime(t[p.key])}</span></li>`;
          }).join('')}
        </ul>
        <div class="card" style="margin-top:16px">
          <div class="muted" style="font-size:.85rem">📍 ${esc(settings.location.name)} • ${PrayTimes.METHODS[settings.method].name} • العصر: ${settings.asr === 2 ? 'الحنفي' : 'الجمهور'}</div>
          <button class="btn ghost block" style="margin-top:10px" id="toSettings">تغيير الموقع وطريقة الحساب</button>
        </div>`;
      $('#prev').onclick = () => { offset--; draw(); };
      $('#next').onclick = () => { offset++; draw(); };
      $('#toSettings').onclick = () => go('settings');
    };
    draw();
  }

  // ---------- شاشة الأذان الكاملة ----------
  // تُعرض عند دخول وقت الصلاة (من مراقب التطبيق أو من إشعار الخلفية أو من
  // زر التجربة). ثلاث حالات: حية (حان الآن)، ومعاينة (الوقت في المستقبل —
  // من زر التجربة)، وفاتت (مرّ على الوقت أكثر من 15 دقيقة — لا يُشغَّل فيها
  // صوت الأذان تلقائياً حتى لا يأتي في وقت خاطئ).
  let adhanTest = null; // { key } يضبطه زر «جرّب شاشة الأذان» قبل الانتقال
  function adhanSoundFor(key) { return (settings.adhanSound && settings.adhanSound[key]) || 'voice'; }
  function adhanPlayedMap() { return store.get('adhan:played', {}); }
  function markAdhanPlayed(key, atMs) {
    const m = adhanPlayedMap();
    m[`${key}:${ymdIn(new Date(atMs), tz()).join('-')}`] = atMs;
    store.set('adhan:played', m);
  }
  function wasAdhanPlayed(key, atMs) {
    return adhanPlayedMap()[`${key}:${ymdIn(new Date(atMs), tz()).join('-')}`] === atMs;
  }
  function adhanHandled(key, atMs) { if (wasAdhanPlayed(key, atMs)) return true; markAdhanPlayed(key, atMs); return false; }
  function renderAdhan(key) {
    const p = PRAY5.find((x) => x.key === key) || nextPrayer();
    if (!p) { view.innerHTML = '<div class="card center"><p>لا توجد صلاة قادمة.</p></div>'; return; }
    const test = adhanTest && adhanTest.key === p.key ? adhanTest : null;
    adhanTest = null;
    const now = new Date();
    const t = timesFor(now)[p.key];
    const diff = now - t;
    const stale = !test && diff > 15 * 60000;
    const preview = !!test || (!stale && diff < -2 * 60000);
    const sound = adhanSoundFor(p.key);
    markAdhanPlayed(p.key, t.getTime());
    const state = stale ? 'فات وقت صلاة' : preview ? 'معاينة شاشة الأذان' : 'حان الآن وقت صلاة';
    adhanDiag('screen-open', `فُتحت شاشة الأذان: صلاة ${p.key} — ${state} (وقتها ${fmtTime(t)}، الصوت: ${sound})`);
    const soundLabel = { voice: 'الأذان الكامل', beep: 'تنبيه قصير', silent: 'صامت (إشعار بصري فقط)' }[sound];
    view.innerHTML = `
    <div class="yq-page yq-adhan">
      <div class="yq-adhan-arch" aria-hidden="true"><i class="ad-ring"></i><i class="ad-ring r2"></i><svg class="yq-adhan-emb" viewBox="0 0 100 124"><use href="#logo-emblem"/></svg></div>
      <p class="yq-adhan-state">${state}</p>
      <h2 class="yq-adhan-name">${p.ic} صلاة ${p.name}</h2>
      <p class="yq-adhan-time">${fmtTime(t)}</p>
      <p class="yq-adhan-date">${greg(now)}<br>${hijri(now)}</p>
      <p class="yq-adhan-loc">📍 ${esc(settings.location.name)} • ${PrayTimes.METHODS[settings.method].name}</p>
      ${stale ? `<p class="yq-adhan-note">فاتتك هذه الصلاة — يمكنك تسجيل قضائها من صفحة «متابعة الصلوات».</p>` : ''}
      ${preview ? `<p class="yq-adhan-note">هكذا ستبدو شاشة الأذان عند دخول الوقت — تظهر تلقائياً حتى لو كان الهاتف مقفولاً. الصوت المضبوط لهذه الصلاة: ${soundLabel}.</p>` : `<p class="yq-adhan-note">صوت هذه الصلاة: ${soundLabel}.</p>`}
      <div class="yq-adhan-actions">
        ${sound === 'voice' ? `<button class="btn block" id="adnPlay">▶ تشغيل الأذان</button>` : ''}
        <button class="btn ghost block" id="adnTimes">مواقيت الصلاة</button>
        ${stale ? `<button class="btn ghost block" id="adnQada">تسجيل القضاء</button>` : ''}
        <button class="btn ghost block" id="adnClose">إغلاق</button>
      </div>
    </div>`;
    const playBtn = $('#adnPlay');
    const setPlaying = (playing) => {
      document.body.dataset.adhanAudio = playing ? 'playing' : 'paused';
      if (playBtn) playBtn.textContent = playing ? '⏸ إيقاف الأذان' : '▶ تشغيل الأذان';
    };
    const playAdhan = () => {
      try {
        window.dispatchEvent(new CustomEvent('yaqeen:audio', { detail: 'adhan' }));
        adhanAudio().play().then(() => { setPlaying(true); adhanDiag('audio', `تشغيل صوت الأذان داخل التطبيق (صلاة ${p.key}) — نجح`); }).catch(() => { adhanDiag('audio', `تشغيل صوت الأذان داخل التطبيق (صلاة ${p.key}) — فشل`); toast('تعذّر تشغيل صوت الأذان'); });
      } catch { adhanDiag('audio', `تشغيل صوت الأذان داخل التطبيق (صلاة ${p.key}) — استثناء`); }
    };
    if (playBtn) {
      playBtn.onclick = () => {
        if (adhanEl && !adhanEl.paused) { stopAdhanAudio(); setPlaying(false); adhanDiag('audio', `إيقاف صوت الأذان يدوياً (صلاة ${p.key})`); }
        else playAdhan();
      };
      adhanAudio().onended = () => setPlaying(false);
      // التشغيل التلقائي: في المعاينة/التجربة دائماً (ليسمع المستخدم الصوت)،
      // وفي الحالة الحية فقط عندما لا يغطي الإشعار الصوت (متصفح أو إشعارات مرفوضة)
      // لأن صوت الإشعار نفسه يشغّل الأذان في الخلفية.
      const autoAudio = sound === 'voice' && !stale && (preview || !LN || notifyGranted === false);
      if (autoAudio) playAdhan();
    }
    $('#adnTimes').onclick = () => go('prayers');
    const q = $('#adnQada'); if (q) q.onclick = () => go('tracker');
    $('#adnClose').onclick = () => go('home');
    return () => stopAdhanAudio();
  }

  // ---------- القرآن الكريم ----------
  const API = 'https://api.alquran.cloud/v1';
  // تفاسير متاحة من alquran.cloud (اُستبعد «تنوير المقباس» لضعف نسبته إلى ابن عباس رضي الله عنهما)
  const TAFSIRS = [['ar.muyassar', 'الميسر'], ['ar.jalalayn', 'الجلالين'], ['ar.waseet', 'الوسيط (طنطاوي)'], ['ar.baghawi', 'البغوي'], ['ar.qurtubi', 'القرطبي']];
  async function fetchJSON(url, cacheKey) {
    const cached = cacheKey && store.get(cacheKey);
    if (cached) return cached;
    // مهلة 15 ثانية: طلب معلّق بلا مهلة كان يترك شاشة التحميل تدور إلى الأبد
    // دون رسالة خطأ ولا زر إعادة محاولة (عيب أصلي من النسخة الأولى).
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 15000);
    let res;
    try { res = await fetch(url, { signal: ctrl.signal }); }
    finally { clearTimeout(timer); }
    if (!res.ok) throw new Error(res.status);
    const json = await res.json();
    if (cacheKey) store.set(cacheKey, json.data);
    return json.data;
  }
  const errorBox = (retry) => {
    view.innerHTML = `<div class="card center"><p>تعذّر تحميل البيانات. تأكد من اتصالك بالإنترنت.</p><button class="btn" id="retry">إعادة المحاولة</button></div>`;
    $('#retry').onclick = retry;
  };

  const normAr = (t) => t.replace(/[ً-ٰٟۖ-ۭ]/g, '').replace(/[ٱأإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه');
  let quranMode = 'surah';
  function renderQuran() {
    view.innerHTML = '<div class="loader"></div>';
    let alive = true;
    fetchJSON(`${API}/surah`, 'surahList').then((list) => {
      if (!alive) return;
      const last = store.get('lastRead');
      view.innerHTML = `
        ${last ? `<div class="card continue"><div><small class="muted">آخر قراءة</small><br><b>${esc(last.name)}</b> <small class="muted">— الآية ${ar(last.ayah)}</small></div><button class="btn" id="cont">متابعة</button></div>` : ''}
        <div class="seg" id="qmode" style="margin-bottom:14px"><button data-m="surah">السور</button><button data-m="juz">الأجزاء</button><button data-m="search">بحث في الآيات</button></div>
        <p class="yq-small" style="text-align:center;margin:0 0 12px">نص القرآن الكريم من <a href="https://tanzil.net/" target="_blank" rel="noopener">Tanzil</a> عبر AlQuran Cloud — نص غير معدَّل</p>
        <div id="qbody"></div>`;
      if (last) $('#cont').onclick = () => go(`surah/${last.n}/${last.ayah}`);
      const body = $('#qbody');

      const surahMode = () => {
        body.innerHTML = `<input class="search" id="q" type="search" placeholder="ابحث عن سورة بالاسم أو الرقم..."><div class="yq-index" id="list"></div>`;
        const draw = (q = '') => {
          const nq = normAr(q.trim());
          $('#list').innerHTML = list
            .filter((s) => !nq || normAr(s.name).includes(nq) || String(s.number) === q.trim() || ar(s.number) === q.trim())
            .map((s) => `<button class="yq-index-item surah-item" data-n="${s.number}"><span class="yq-index-num">${toAr(String(s.number).padStart(2, '0'))}</span><span class="yq-index-body"><span class="yq-index-title">${s.name}</span><span class="yq-index-desc">${s.revelationType === 'Meccan' ? 'مكية' : 'مدنية'}، ${ar(s.numberOfAyahs)} آية</span></span></button>`)
            .join('') || '<p class="center muted">لا توجد نتائج</p>';
          $$('.surah-item', body).forEach((b) => b.addEventListener('click', () => go(`surah/${b.dataset.n}`)));
        };
        draw();
        $('#q').addEventListener('input', (e) => draw(e.target.value));
      };

      const juzMode = () => {
        const k = khatmaState();
        body.innerHTML = `<div class="yq-index">${JUZ_NAMES.map((nm, i) => `<button class="yq-index-item surah-item" data-j="${i + 1}"><span class="yq-index-num">${toAr(String(i + 1).padStart(2, '0'))}</span><span class="yq-index-body"><span class="yq-index-title">${nm}</span><span class="yq-index-desc">الجزء ${ar(i + 1)}${k.done[i] ? ' • ✓ مقروء في الختمة' : ''}</span></span></button>`).join('')}</div>`;
        $$('[data-j]', body).forEach((b) => b.addEventListener('click', () => go(`juz/${b.dataset.j}`)));
      };

      const searchMode = () => {
        body.innerHTML = `<form id="sf" style="display:flex;gap:8px"><input class="search" id="sq" type="search" placeholder="اكتب كلمة من الآية... مثال: الصبر" style="margin:0"><button class="btn" type="submit">بحث</button></form><div id="sres" style="margin-top:14px"></div>`;
        $('#sf').addEventListener('submit', async (e) => {
          e.preventDefault();
          const q = normAr($('#sq').value.trim());
          if (q.length < 2) return toast('اكتب كلمتين أو حرفين على الأقل');
          const out = $('#sres');
          out.innerHTML = '<div class="loader"></div>';
          try {
            const res = await fetch(`${API}/search/${encodeURIComponent(q)}/all/quran-simple-clean`);
            const json = res.ok ? await res.json() : null;
            const m = (json && json.data && json.data.matches) || [];
            if (!m.length) { out.innerHTML = '<p class="center muted">لا توجد نتائج</p>'; return; }
            const re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
            out.innerHTML = `<p class="muted" style="font-size:.85rem">${arG(m.length)} نتيجة${m.length > 100 ? ' (أول ١٠٠)' : ''}</p><div class="yq-gold-rows">` + m.slice(0, 100).map((x) =>
              `<button class="yq-gold-row result" data-s="${x.surah.number}" data-a="${x.numberInSurah}"><span class="yq-gold-row-body"><span class="yq-gold-row-title">${esc(x.text).replace(re, '<mark>$&</mark>')}</span><span class="yq-gold-row-meta">${x.surah.name} • الآية ${ar(x.numberInSurah)}</span></span></button>`).join('') + '</div>';
            $$('.result', out).forEach((b) => b.addEventListener('click', () => go(`surah/${b.dataset.s}/${b.dataset.a}`)));
          } catch { out.innerHTML = '<p class="center muted">تعذّر البحث، تأكد من الاتصال بالإنترنت.</p>'; }
        });
        $('#sq').focus();
      };

      const setMode = (m) => {
        quranMode = m;
        $$('#qmode button').forEach((b) => b.classList.toggle('active', b.dataset.m === m));
        ({ surah: surahMode, juz: juzMode, search: searchMode })[m]();
      };
      $$('#qmode button').forEach((b) => b.addEventListener('click', () => setMode(b.dataset.m)));
      setMode(quranMode);
    }).catch(() => alive && errorBox(renderQuran));
    return () => { alive = false; };
  }

  // ---------- أدوات الآيات: العلامات والمشاركة ونافذة الخيارات ----------
  const getBM = () => store.get('bookmarks', []);
  const isBM = (n, a) => getBM().some((b) => b.n === n && b.ayah === a);
  function toggleBM(item) {
    const bm = getBM();
    const i = bm.findIndex((b) => b.n === item.n && b.ayah === item.ayah);
    if (i >= 0) { bm.splice(i, 1); toast('أُزيلت العلامة'); } else { bm.unshift({ ...item, t: Date.now() }); toast('تم حفظ العلامة 🔖'); }
    store.set('bookmarks', bm);
    return i < 0;
  }
  async function shareText(text, opts) {
    if (window.NoorShare) return window.NoorShare(text, opts); // js/share.js: قائمة المشاركة الأصلية + روابط تفتح التطبيق
    try { if (navigator.share) { await navigator.share({ text }); return; } } catch (e) { if (e && e.name === 'AbortError') return; }
    try { await navigator.clipboard.writeText(text); toast('تم نسخ النص'); } catch { toast('تعذّر النسخ'); }
  }
  const APP_SIGN = () => '\n\nمن تطبيق يقين - صدقة جارية على روح المرحوم عبدالناصر عمران';
  function sheet(html) {
    const bd = document.createElement('div');
    bd.className = 'sheet-backdrop';
    bd.innerHTML = `<div class="sheet" role="dialog" aria-modal="true"><div class="sheet-handle"></div>${html}</div>`;
    document.body.appendChild(bd);
    requestAnimationFrame(() => bd.classList.add('open'));
    const close = () => { bd.classList.remove('open'); setTimeout(() => bd.remove(), 250); };
    bd.addEventListener('click', (e) => { if (e.target === bd) close(); });
    return { el: $('.sheet', bd), close };
  }

  function renderSurah(arg, arg2) {
    const n = Math.min(114, Math.max(1, parseInt(arg, 10) || 1));
    view.innerHTML = '<div class="loader"></div>';
    let alive = true;
    const audio = new Audio();
    audio.preload = 'auto';
    const onExclusive = (e) => { if (e.detail !== 'surah') audio.pause(); };
    window.addEventListener('yaqeen:audio', onExclusive);

    fetchJSON(`${API}/surah/${n}/quran-uthmani`, `surah:${n}`).then((s) => {
      if (!alive) return;
      $('#pageTitle').textContent = s.name;
      const ayahs = s.ayahs.map((a, i) => {
        let text = a.text;
        if (i === 0 && n !== 1 && n !== 9 && /^بِسْمِ|^بِسۡمِ/.test(text)) text = text.split(' ').slice(4).join(' ');
        return { ...a, text };
      });
      const last = store.get('lastRead');
      view.innerHTML = `
        <div class="player">
          <button class="icon-btn" id="play" aria-label="تشغيل"></button>
          <div class="p-info"><b id="pState">استماع</b><small class="muted">${RECITERS[settings.reciter].name}</small></div>
          <select id="rep" class="rep" aria-label="تكرار الآية للحفظ">${[1, 3, 5, 10].map((v) => `<option value="${v}" ${v === settings.repeat ? 'selected' : ''}>${v === 1 ? 'بدون تكرار' : 'تكرار ×' + ar(v)}</option>`).join('')}</select>
          <button class="icon-btn" id="fminus" aria-label="تصغير الخط"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-minus"/></svg><i>أ</i></button>
          <button class="icon-btn" id="fplus" aria-label="تكبير الخط"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-plus"/></svg><i>أ</i></button>
        </div>
        <article class="mushaf yq-reading">
          <div class="surah-header yq-surah-head"><span class="sh-num">${toAr(String(n).padStart(3, '0'))}</span><h2>${s.name}</h2><small>${s.revelationType === 'Meccan' ? 'مكية' : 'مدنية'}، ${ar(s.numberOfAyahs)} آية</small></div>
          ${n !== 1 && n !== 9 ? '<div class="basmala">بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ</div>' : ''}
          <p class="quran-text" id="qt">${ayahs.map((a, i) => { const pv = ayahs[i - 1]; const mk = []; if (i > 0 && pv.juz !== a.juz) mk.push(`الجزء ${ar(a.juz)}`); if (i > 0 && pv.hizbQuarter !== a.hizbQuarter && (a.hizbQuarter - 1) % 4 === 0) mk.push(`الحزب ${ar((a.hizbQuarter - 1) / 4 + 1)}`); else if (i > 0 && pv.hizbQuarter !== a.hizbQuarter) mk.push(['', 'ربع', 'نصف', 'ثلاثة أرباع'][(a.hizbQuarter - 1) % 4] + ` الحزب ${ar(Math.floor((a.hizbQuarter - 1) / 4) + 1)}`); return `${i > 0 && pv.page !== a.page ? `<span class="q-page">صفحة ${ar(a.page)}</span>` : ''}${mk.length ? `<span class="q-mark">${mk.join(' • ')}</span>` : ''}<span class="ayah" data-i="${i}">${a.text}</span> <span class="ayah-num yq-ayah-num">${ar(a.numberInSurah)}</span>${a.sajda ? ' <span class="q-sajda" title="موضع سجدة تلاوة">۩ سجدة</span>' : ''} `; }).join('')}</p>
        </article>
        <div style="display:flex;gap:10px;margin-top:14px">
          ${n > 1 ? `<button class="btn ghost block" data-go="surah/${n - 1}"><svg style="transform:scaleX(-1)" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-chev"/></svg> السورة السابقة</button>` : ''}
          ${n < 114 ? `<button class="btn ghost block" data-go="surah/${n + 1}">السورة التالية <svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-chev"/></svg></button>` : ''}
        </div>
        <p class="yq-small" style="text-align:center;margin:12px 0 0">نص القرآن الكريم من <a href="https://tanzil.net/" target="_blank" rel="noopener">Tanzil</a> عبر AlQuran Cloud — نص غير معدَّل</p>`;
      $$('[data-go]', view).forEach((b) => b.addEventListener('click', () => go(b.dataset.go)));
      document.documentElement.style.setProperty('--qsize', settings.qsize + 'rem');
      const setSize = (d) => { settings.qsize = Math.min(3, Math.max(1.1, +(settings.qsize + d).toFixed(1))); saveSettings(); document.documentElement.style.setProperty('--qsize', settings.qsize + 'rem'); };
      $('#fplus').onclick = () => setSize(0.15);
      $('#fminus').onclick = () => setSize(-0.15);

      let cur = -1;
      const playIcon = '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-play"/></svg>';
      const pauseIcon = '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-pause"/></svg>';
      const setBtn = () => { $('#play').innerHTML = audio.paused ? playIcon : pauseIcon; };
      setBtn();
      const mark = (i, scroll) => {
        $$('.ayah.active').forEach((e) => e.classList.remove('active'));
        const el = $(`.ayah[data-i="${i}"]`);
        if (el) { el.classList.add('active'); if (scroll) el.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
        store.set('lastRead', { n, name: s.name, ayah: ayahs[i].numberInSurah });
      };
      let rep = 0;
      $('#rep').onchange = (e) => { settings.repeat = +e.target.value; saveSettings(); toast(settings.repeat > 1 ? `وضع الحفظ: كل آية ${ar(settings.repeat)} مرات` : 'تم إلغاء التكرار'); };
      const playAt = (i) => {
        rep = 0;
        if (i >= ayahs.length) { cur = -1; $('#pState').textContent = 'انتهت التلاوة'; setBtn(); return; }
        cur = i;
        const r = RECITERS[settings.reciter];
        audio.src = `https://cdn.islamic.network/quran/audio/${r.br}/${settings.reciter}/${ayahs[i].number}.mp3`;
        audio.play().catch(() => toast('تعذّر تشغيل الصوت'));
        $('#pState').textContent = `الآية ${ar(ayahs[i].numberInSurah)}`;
        mark(i, true);
      };
      audio.onended = () => {
        rep++;
        if (rep < (settings.repeat || 1)) { audio.currentTime = 0; audio.play().catch(() => {}); $('#pState').textContent = `الآية ${ar(ayahs[cur].numberInSurah)} • تكرار ${ar(rep + 1)}`; return; }
        playAt(cur + 1);
      };
      audio.onpause = setBtn;
      audio.onplay = () => { setBtn(); window.dispatchEvent(new CustomEvent('yaqeen:audio', { detail: 'surah' })); };
      $('#play').onclick = () => {
        if (cur < 0) playAt(0);
        else if (audio.paused) audio.play(); else audio.pause();
      };
      const openAyah = (i) => {
        const a = ayahs[i];
        const ref = `${s.name} - الآية ${ar(a.numberInSurah)}`;
        const bmLabel = () => (isBM(n, a.numberInSurah) ? '🔖 إزالة العلامة' : '🔖 حفظ علامة');
        const sh = sheet(`
          <div class="sheet-title">${esc(ref)}</div>
          <p class="sheet-ayah">${a.text}</p>
          <div class="sheet-actions">
            <button class="btn" data-a="play">▶ استماع من هنا</button>
            <button class="btn ghost" data-a="bm">${bmLabel()}</button>
            <button class="btn ghost" data-a="share">📤 مشاركة</button>
          </div>
          ${settings.translation ? `<div class="tafsir"><h4>الترجمة • ${esc(TRANSLATIONS[settings.translation] || '')}</h4><div class="trans-body" dir="${settings.translation.startsWith('ur') ? 'rtl' : 'ltr'}"><div class="loader" style="margin:16px auto"></div></div></div>` : ''}
          <div class="tafsir yq-tafsir-panel"><h4>التفسير</h4><div class="chips tf-chips" style="justify-content:flex-start;margin-bottom:8px">${TAFSIRS.map(([k, t]) => `<button class="chip ${k === (settings.tafsir || 'ar.muyassar') ? 'active' : ''}" data-tf="${k}">${t}</button>`).join('')}</div><div class="tafsir-body"><div class="loader" style="margin:16px auto"></div></div></div>`);
        if (settings.translation) {
          const trb = $('.trans-body', sh.el);
          fetchJSON(`${API}/ayah/${a.number}/${settings.translation}`, `tr:${settings.translation}:${a.number}`)
            .then((d) => { trb.textContent = d.text; })
            .catch(() => { trb.textContent = 'تعذّر تحميل الترجمة، تأكد من الاتصال بالإنترنت.'; });
        }
        $('[data-a="play"]', sh.el).onclick = () => { sh.close(); playAt(i); };
        $('[data-a="bm"]', sh.el).onclick = (e) => { toggleBM({ n, name: s.name, ayah: a.numberInSurah, text: a.text.slice(0, 90) }); e.currentTarget.textContent = bmLabel(); };
        $('[data-a="share"]', sh.el).onclick = () => shareText(`﴿${a.text}﴾\n[${ref}]`, { route: `surah/${n}/${a.numberInSurah}`, card: { kind: 'آية قرآنية', text: `﴿${a.text}﴾`, ref } });
        const tb = $('.tafsir-body', sh.el);
        const loadTf = (ed) => {
          tb.innerHTML = '<div class="loader" style="margin:16px auto"></div>';
          fetchJSON(`${API}/ayah/${a.number}/${ed}`, ed === 'ar.muyassar' ? `tafsir:${a.number}` : `tf:${ed}:${a.number}`)
            .then((d) => { tb.textContent = d.text; })
            .catch(() => { tb.textContent = 'تعذّر تحميل التفسير، تأكد من الاتصال بالإنترنت.'; });
        };
        loadTf(settings.tafsir || 'ar.muyassar');
        $$('[data-tf]', sh.el).forEach((b) => { b.onclick = () => { settings.tafsir = b.dataset.tf; saveSettings(); $$('[data-tf]', sh.el).forEach((x) => x.classList.toggle('active', x === b)); loadTf(b.dataset.tf); }; });
      };
      $$('.ayah').forEach((el) => el.addEventListener('click', () => openAyah(+el.dataset.i)));

      const target = arg2 ? +arg2 : (last && last.n === n ? last.ayah : 1);
      if (target > 1) {
        const i = ayahs.findIndex((a) => a.numberInSurah === target);
        if (i > 0) setTimeout(() => mark(i, true), 150);
      } else {
        store.set('lastRead', { n, name: s.name, ayah: 1 });
      }
    }).catch(() => alive && errorBox(() => renderSurah(arg)));

    return () => { alive = false; audio.pause(); audio.src = ''; window.removeEventListener('yaqeen:audio', onExclusive); };
  }

  // ---------- الأذكار ----------
  const todayKey = () => ymdIn(new Date(), tz()).join('-');

  function renderAzkarList() {
    view.innerHTML = `<ol class="yq-index">
      ${Object.entries(AZKAR).map(([k, z], ix) => {
        const prog = store.get(`azkar:${k}:${todayKey()}`, {});
        const done = z.items.filter((it, i) => (prog[i] || 0) >= it.count).length;
        return `<li class="yq-index-item" data-k="${k}" style="cursor:pointer"><span aria-hidden="true" style="font-size:1.3rem">${z.icon}</span><span class="yq-index-num">${toAr(String(ix + 1).padStart(2, '0'))}</span><div class="yq-index-body"><h3 class="yq-index-title">${z.title}</h3></div><span class="yq-index-count">${ar(done)} / ${ar(z.items.length)}</span></li>`;
      }).join('')}
    </ol>
    <div class="yq-featured-verse"><p class="yq-eyebrow">فضل الذكر</p><p class="yq-quran-text">﴿أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ﴾</p><span class="yq-verse-ref">الرعد: ٢٨</span></div>`;
    $$('[data-k]', view).forEach((b) => b.addEventListener('click', () => go(`zikr/${b.dataset.k}`)));
  }

  function renderAzkar(key) {
    const z = AZKAR[key] || AZKAR.morning;
    $('#pageTitle').textContent = z.title;
    const sk = `azkar:${key}:${todayKey()}`;
    const prog = store.get(sk, {});
    view.innerHTML = `<div class="progress"><div id="bar"></div></div>
      <ol class="yq-dhikr-flow">
      ${z.items.map((it, i) => `
        <li class="yq-dhikr-step zikr" data-i="${i}">
          <span class="yq-dhikr-step-num">${ar(i + 1)}</span>
          <div class="yq-dhikr-step-body"><p>${it.text}</p><small class="yq-small">${it.ref}${it.count > 1 ? ` • التكرار: ${ar(it.count)}` : ''}</small></div>
          <button class="yq-dhikr-count counter-btn"></button>
        </li>`).join('')}
      </ol>
      <button class="btn ghost block" id="resetAz">إعادة تعيين</button>`;

    const update = () => {
      let done = 0;
      $$('.zikr', view).forEach((el) => {
        const i = +el.dataset.i, it = z.items[i], c = prog[i] || 0;
        const isDone = c >= it.count;
        if (isDone) done++;
        el.classList.toggle('done', isDone);
        el.classList.toggle('yq-dhikr-step--done', isDone);
        $('.counter-btn', el).textContent = isDone ? '✓ تم' : `${ar(c)} / ${ar(it.count)}`;
      });
      $('#bar').style.width = (done / z.items.length) * 100 + '%';
      return done;
    };
    $$('.zikr', view).forEach((el) => {
      const handler = () => {
        const i = +el.dataset.i, it = z.items[i];
        if ((prog[i] || 0) >= it.count) return;
        prog[i] = (prog[i] || 0) + 1;
        store.set(sk, prog);
        navigator.vibrate && navigator.vibrate(prog[i] >= it.count ? [30, 40, 30] : 12);
        const done = update();
        if (prog[i] >= it.count) {
          if (done === z.items.length) toast('أتممت الأذكار، تقبّل الله منك 🤍');
          else { const nx = el.nextElementSibling; if (nx && nx.classList.contains('zikr')) setTimeout(() => nx.scrollIntoView({ behavior: 'smooth', block: 'center' }), 250); }
        }
      };
      $('.counter-btn', el).addEventListener('click', (e) => { e.stopPropagation(); handler(); });
      $('p', el).addEventListener('click', handler);
    });
    $('#resetAz').onclick = () => { for (const k in prog) delete prog[k]; store.set(sk, prog); update(); window.scrollTo({ top: 0, behavior: 'smooth' }); };
    update();
  }

  // ---------- السبحة ----------
  function renderTasbih() {
    const st = Object.assign({ zikr: 0, count: 0, target: 33, rounds: 0, total: 0, today: 0, day: '' }, store.get('tasbih', {}));
    if (st.day !== todayKey()) { st.today = 0; st.day = todayKey(); }
    const C = 2 * Math.PI * 126;
    view.innerHTML = `
      <div class="tasbih-wrap yq-page">
        <p class="yq-eyebrow" style="text-align:center">السبحة الإلكترونية — عدّاد الذكر</p>
        <div class="chips" id="presets">${TASBIH_PRESETS.map((t, i) => `<button class="chip" data-i="${i}">${t}</button>`).join('')}</div>
        <div class="tasbih-zikr" id="tz"></div>
        <button class="bead" id="bead" aria-label="تسبيح">
          <svg class="ring" viewBox="0 0 264 264"><circle class="bg" cx="132" cy="132" r="126"/><circle class="fg" id="ring" cx="132" cy="132" r="126" stroke-dasharray="${C}" stroke-dashoffset="${C}"/></svg>
          <div><div class="count" id="cnt"></div><div class="target" id="tgt"></div></div>
        </button>
        <div class="seg" id="targets" style="width:100%">
          ${[33, 100, 1000, 0].map((v) => `<button data-v="${v}">${v ? ar(v) : 'مفتوح'}</button>`).join('')}
        </div>
        <ul class="yq-gold-rows">
          <li class="yq-gold-row"><div class="yq-gold-row-body"><p class="yq-gold-row-title">الدورات</p></div><span class="yq-gold-row-status" id="sRounds"></span></li>
          <li class="yq-gold-row"><div class="yq-gold-row-body"><p class="yq-gold-row-title">ذكر اليوم</p></div><span class="yq-gold-row-status" id="sToday"></span></li>
          <li class="yq-gold-row"><div class="yq-gold-row-body"><p class="yq-gold-row-title">الإجمالي</p></div><span class="yq-gold-row-status" id="sTotal"></span></li>
        </ul>
        <button class="btn ghost block" id="reset">تصفير العداد</button>
      </div>`;
    const save = () => store.set('tasbih', st);
    const draw = () => {
      $('#tz').textContent = TASBIH_PRESETS[st.zikr];
      $('#cnt').textContent = ar(st.count);
      $('#tgt').textContent = st.target ? `من ${ar(st.target)}` : 'عدد مفتوح';
      $('#ring').style.strokeDashoffset = st.target ? C * (1 - st.count / st.target) : C * (1 - (st.count % 100) / 100);
      $('#sRounds').textContent = arG(st.rounds);
      $('#sToday').textContent = arG(st.today);
      $('#sTotal').textContent = arG(st.total);
      $$('#presets .chip').forEach((c) => c.classList.toggle('active', +c.dataset.i === st.zikr));
      $$('#targets button').forEach((b) => b.classList.toggle('active', +b.dataset.v === st.target));
    };
    $('#bead').addEventListener('click', () => {
      st.count++; st.total++; st.today++;
      if (st.target && st.count >= st.target) {
        st.rounds++;
        navigator.vibrate && navigator.vibrate([60, 60, 60]);
        toast(`أتممت ${ar(st.target)} — ${TASBIH_PRESETS[st.zikr]}`);
        setTimeout(() => { st.count = 0; save(); draw(); }, 350);
      } else {
        navigator.vibrate && navigator.vibrate(15);
      }
      save(); draw();
    });
    $$('#presets .chip').forEach((c) => c.addEventListener('click', () => { st.zikr = +c.dataset.i; st.count = 0; save(); draw(); }));
    $$('#targets button').forEach((b) => b.addEventListener('click', () => { st.target = +b.dataset.v; st.count = 0; save(); draw(); }));
    $('#reset').onclick = () => { st.count = 0; save(); draw(); };
    draw();
  }

  // ---------- القبلة ----------
  function renderQibla() {
    const { lat, lng, name } = settings.location;
    const q = PrayTimes.qibla(lat, lng);
    const dist = PrayTimes.distanceToMakkah(lat, lng);
    view.innerHTML = `
      <div class="compass-wrap yq-page">
        <p class="yq-eyebrow" style="text-align:center">اتجاه القبلة</p>
        <div class="compass" id="dial">
          <span class="mark n">ش</span><span class="mark e">ق</span><span class="mark s">ج</span><span class="mark w">غ</span>
          <div class="needle" style="transform:rotate(${q}deg)"><span class="kaaba"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-kaaba"/></svg></span></div>
          <div class="center"></div>
        </div>
        <div><div class="big-num">${ar(q.toFixed(1))}°</div><div class="muted">من الشمال باتجاه عقارب الساعة</div></div>
        <ul class="yq-gold-rows" style="width:100%">
          <li class="yq-gold-row"><div class="yq-gold-row-body"><p class="yq-gold-row-title">📍 ${esc(name)}</p></div></li>
          <li class="yq-gold-row"><div class="yq-gold-row-body"><p class="yq-gold-row-title">المسافة إلى مكة المكرمة</p><p class="yq-gold-row-meta">${arG(Math.round(dist))} كم</p></div></li>
        </ul>
        <button class="yq-btn yq-btn--block" id="compassBtn">تفعيل البوصلة</button>
        <p class="muted" id="hint" style="font-size:.85rem">ضع الهاتف بشكل مسطّح وبعيداً عن المعادن، ثم وجّه أعلى الهاتف نحو رمز الكعبة.</p>
      </div>`;
    const dial = $('#dial');
    let active = false;
    const onOrient = (e) => {
      let heading = null;
      if (typeof e.webkitCompassHeading === 'number') heading = e.webkitCompassHeading;
      else if (e.absolute && e.alpha != null) heading = 360 - e.alpha;
      if (heading == null) return;
      active = true;
      dial.style.transform = `rotate(${-heading}deg)`;
      const diff = Math.abs(((q - heading + 540) % 360) - 180);
      dial.classList.toggle('aligned', diff < 5);
      $('#hint').textContent = diff < 5 ? '✅ أنت متجه نحو القبلة' : 'أدِر الهاتف حتى يشير رمز الكعبة إلى الأعلى';
    };
    const start = async () => {
      try {
        if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
          const r = await DeviceOrientationEvent.requestPermission();
          if (r !== 'granted') { toast('لم يتم منح إذن البوصلة'); return; }
        }
        window.addEventListener('deviceorientationabsolute', onOrient);
        window.addEventListener('deviceorientation', onOrient);
        $('#compassBtn').hidden = true;
        setTimeout(() => { if (!active) $('#hint').textContent = 'البوصلة غير متاحة على هذا الجهاز. استخدم الزاوية الموضحة أعلاه.'; }, 2500);
      } catch { toast('البوصلة غير مدعومة'); }
    };
    $('#compassBtn').onclick = start;
    return () => {
      window.removeEventListener('deviceorientationabsolute', onOrient);
      window.removeEventListener('deviceorientation', onOrient);
    };
  }

  // ---------- الأسماء الحسنى ----------
  function renderNames() {
    view.innerHTML = `
      <div class="card center"><p class="hadith-text" style="font-size:1.15rem">«إِنَّ لِلَّهِ تِسْعَةً وَتِسْعِينَ اسْمًا، مِائَةً إِلَّا وَاحِدًا، مَنْ أَحْصَاهَا دَخَلَ الْجَنَّةَ»</p><div class="ref">متفق عليه</div></div>
      <ol class="yq-names-list">${ASMA_ALHUSNA.map((n, i) => `<li class="yq-name-row"><small>${ar(i + 1)}</small><b>${n}</b></li>`).join('')}</ol>`;
  }

  // ---------- الإعدادات ----------
  function renderSettings() {
    const cityIdx = CITIES.findIndex((c) => c.name === settings.location.name);
    view.innerHTML = `
    <div class="yq-page">
      <div class="card yq-card">
        <h3>📍 الموقع</h3>
        <button class="btn block" id="gps"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/><circle cx="12" cy="12" r="7"/></svg>تحديد موقعي تلقائياً</button>
        <div class="field yq-field" style="margin-top:12px"><label for="city">أو اختر مدينة</label>
          <select id="city" class="yq-input"><option value="-1">${cityIdx < 0 ? esc(settings.location.name) : '— اختر —'}</option>${CITIES.map((c, i) => `<option value="${i}" ${i === cityIdx ? 'selected' : ''}>${c.name}</option>`).join('')}</select>
        </div>
      </div>
      <div class="card yq-card">
        <h3>🕌 مواقيت الصلاة</h3>
        <div class="field yq-field"><label for="method">طريقة الحساب</label>
          <select id="method" class="yq-input">${Object.entries(PrayTimes.METHODS).map(([k, m]) => `<option value="${k}" ${k === settings.method ? 'selected' : ''}>${m.name}</option>`).join('')}</select>
        </div>
        <div class="field yq-field"><label>حساب وقت العصر</label>
          <div class="seg yq-seg" id="asr"><button data-v="1">الجمهور (شافعي/مالكي/حنبلي)</button><button data-v="2">الحنفي</button></div>
        </div>
        <div class="field yq-field"><label>تنبيه عند دخول وقت الصلاة</label>
          <div class="seg yq-seg" id="alerts"><button data-v="1">مفعّل</button><button data-v="0">معطّل</button></div>
          <small class="muted" id="adhanNote">${NATIVE ? 'يصلك إشعار عند دخول كل صلاة حتى لو كان الهاتف مقفولاً.' : 'في نسخة المتصفح يعمل الأذان أثناء فتح التطبيق فقط. ثبّت تطبيق أندرويد ليصلك الأذان والهاتف مقفول.'}</small>
        </div>
        <div class="field yq-field"><label>إعدادات كل صلاة</label>
          ${PRAY5.map((p) => { const off = (settings.alertOff || []).includes(p.key); const snd = adhanSoundFor(p.key); return `
          <div class="yq-adhan-row ${off ? 'yq-adhan-row--off' : ''}">
            <span class="yq-adhan-row-name">${p.ic} ${p.name} <small class="muted">${fmtTime(timesFor(new Date())[p.key])}</small></span>
            <button class="btn ${off ? 'ghost' : ''} adn-off" data-k="${p.key}">${off ? 'متوقف' : 'مفعّل'}</button>
            <select class="yq-input adn-snd" data-k="${p.key}" ${off ? 'disabled' : ''}>
              <option value="voice" ${snd === 'voice' ? 'selected' : ''}>الأذان الكامل</option>
              <option value="beep" ${snd === 'beep' ? 'selected' : ''}>تنبيه قصير</option>
              <option value="silent" ${snd === 'silent' ? 'selected' : ''}>صامت</option>
            </select>
          </div>`; }).join('')}
        </div>
        <div class="field yq-field"><label for="preSel">تذكير قبل الأذان</label>
          <select id="preSel" class="yq-input">${[0, 5, 10, 15, 30].map((m) => `<option value="${m}" ${(+settings.pre || 0) === m ? 'selected' : ''}>${m === 0 ? 'بدون تذكير' : `قبل ${ar(m)} دقيقة`}</option>`).join('')}</select>
        </div>
        ${NATIVE ? `<div class="field yq-field"><label>حالة نظام الأذان</label>
          <div class="yq-status" id="adnStatus">
            <div class="yq-status-row"><span>الإشعارات</span><b id="stNotif">…</b><button class="btn ghost" id="btnNotif">تفعيل</button></div>
            <div class="yq-status-row"><span>التنبيه في الوقت بالضبط</span><b id="stExact">…</b><button class="btn ghost" id="exactBtn">السماح</button></div>
            <div class="yq-status-row"><span>توفير البطارية</span><b id="stBatt">تحقق يدوياً</b><button class="btn ghost" id="btnBatt">فتح الإعدادات</button></div>
            <div class="yq-status-row"><span>الملء الكامل للشاشة (الأذان التلقائي)</span><b id="stFsi">…</b><button class="btn ghost" id="btnFsi">فتح إعدادات الإشعارات</button></div>
            <div class="yq-status-row"><span>وضع الرنين</span><b id="stRinger">…</b></div>
            <div class="yq-status-row"><span>عدم الإزعاج</span><b id="stDnd">…</b></div>
            <div class="yq-status-row"><span>صوت الإشعارات</span><b id="stVol">…</b></div>
          </div>
          <p id="phoneWarn" class="yq-status" style="margin:8px 0 0;color:#8a2f2f" hidden></p>
          <div id="volRaiseRow" hidden style="margin-top:8px">
            <button class="btn block" id="btnRaiseVol">🔊 ارفع صوت الإشعارات</button>
            <small class="muted" style="display:block;margin-top:6px">أو يدوياً: اضغط زر الصوت ← وسّع اللوحة ← شريط «الإشعارات»؛ أو الإعدادات ← الصوت والاهتزاز ← مستوى الصوت ← الإشعارات</small>
          </div>
          <div class="yq-status" id="adnChannels" style="margin-top:8px"><div class="yq-status-row"><span>قنوات الإشعار (كما يراها النظام)</span><b>…</b></div></div>
        </div>
        <div class="field yq-field"><label>تجربة الأذان</label>
          <button class="btn block" id="testAdhanScreen" style="margin-top:8px">🕌 جرّب شاشة الأذان الآن</button>
          <button class="btn ghost block" id="testAdhan" style="margin-top:8px">🔔 تجربة التنبيه بعد ١٠ ثوانٍ</button>
          <button class="btn block" id="testAdhanAuto" style="margin-top:8px">🕌 جرّب الأذان التلقائي بعد ١٠ ثوانٍ</button>
          <button class="btn ghost block" id="testAdhanDefault" style="margin-top:8px">🔔 جرّب صوت التنبيه الافتراضي</button>
        </div>
        <details style="margin-top:8px">
          <summary style="cursor:pointer">سجل التشخيص (للمشاكل فقط)</summary>
          <div class="yq-status" id="adnDiagList" style="max-height:220px;overflow-y:auto;display:block;margin-top:8px"><div class="yq-status-row"><span>لا توجد أحداث مسجلة بعد.</span></div></div>
          <div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap">
            <button class="btn ghost" id="adnDiagCopy" style="flex:1">📋 نسخ السجل</button>
            <button class="btn ghost" id="adnDiagShare" style="flex:1">↗ مشاركة السجل</button>
            <button class="btn ghost" id="adnDiagClear" style="flex:1">🗑 مسح السجل</button>
          </div>
          <small class="muted" style="display:block;margin-top:6px">يسجّل هذا السجل على جهازك فقط: الجدولة، وصول التنبيه، الضغط عليه، فتح شاشة الأذان، محاولات تشغيل الصوت، وحالة قنوات الإشعار كما يراها النظام. انسخه أو شاركه عند الإبلاغ عن مشكلة في الأذان.</small>
          <small class="muted" style="display:block;margin-top:6px">لضمان وصول الأذان والهاتف مقفول: فعّل الإشعارات والتنبيه الدقيق، وأعفِ التطبيق من توفير البطارية (الإعدادات ← التطبيقات ← يقين ← البطارية ← بلا قيود)، وفعّل «التشغيل التلقائي» إن وُجد في جهازك، وتأكد أن الهاتف ليس على الصامت وأن صوت الإشعارات مرفوع. بعد إعادة تشغيل الهاتف تُستعاد التنبيهات تلقائياً.</small>
        </details>` : ''}
          <button class="btn ghost block" id="hearAdhan" style="margin-top:8px">استمع لصوت الأذان</button>
          <small class="muted" style="display:block;margin-top:6px">تسجيل الأذان: «Beautiful adhan» من ويكيميديا كومنز (ترخيص حر CC0).</small>
        </div>
      </div>
      <div class="card yq-card">
        <h3>📖 القرآن الكريم</h3>
        <div class="field yq-field"><label for="reciter">القارئ</label>
          <select id="reciter" class="yq-input">${Object.entries(RECITERS).map(([k, r]) => `<option value="${k}" ${k === settings.reciter ? 'selected' : ''}>${r.name}</option>`).join('')}</select>
        </div>
        <div class="field yq-field" style="margin:0"><label for="translation">ترجمة معاني القرآن (تظهر عند الضغط على الآية)</label>
          <select id="translation" class="yq-input">${Object.entries(TRANSLATIONS).map(([k, v]) => `<option value="${k}" ${k === settings.translation ? 'selected' : ''}>${v}</option>`).join('')}</select>
        </div>
      </div>
      <div class="card yq-card">
        <h3>🎨 المظهر</h3>
        <div class="seg yq-seg" id="theme" style="flex-wrap:wrap"><button data-v="auto">تلقائي</button><button data-v="light">فاتح</button><button data-v="dark">داكن</button><button data-v="brown">أسمر</button></div>
      </div>
      
      <div class="card yq-card">
        <h3>عن التطبيق</h3>
        <p class="muted" style="font-size:.9rem;margin:0 0 10px">يقين — رفيق المسلم • ${versionLabel()}</p>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="yq-btn yq-btn--ghost" data-go="about" style="flex:1">عن التطبيق</button>
          <button class="yq-btn yq-btn--ghost" data-go="sources" style="flex:1">المصادر والتراخيص</button>
        </div>
      </div>
      <p class="center muted" style="font-size:.85rem">هذا التطبيق صدقة جارية على روح المرحوم عبدالناصر عمران<br>نسألكم الدعاء له بالرحمة والمغفرة 🤍</p>
      <p class="center muted" style="font-size:.8rem">يقين - رفيق المسلم • ${versionLabel()}</p></div>`;

    const seg = (id, key, cast) => {
      const sync = () => $$(`#${id} button`).forEach((b) => b.classList.toggle('active', cast(b.dataset.v) === settings[key]));
      $$(`#${id} button`).forEach((b) => b.addEventListener('click', () => {
        settings[key] = cast(b.dataset.v); saveSettings(); sync();
        if (key === 'theme') { store.set('themeChosen', true); applyTheme(); }
        if (key === 'alerts' && settings.alerts && 'Notification' in window && Notification.permission === 'default') Notification.requestPermission();
      }));
      sync();
    };
    seg('asr', 'asr', Number);
    seg('theme', 'theme', String);
    seg('alerts', 'alerts', (v) => v === '1' || v === true);

    // إعدادات كل صلاة: إيقاف/تفعيل + صوت — أي تغيير يعيد الجدولة فوراً
    $$('.adn-off').forEach((b) => b.addEventListener('click', () => {
      const k = b.dataset.k;
      const off = (settings.alertOff || []).includes(k);
      settings.alertOff = off ? settings.alertOff.filter((x) => x !== k) : [...(settings.alertOff || []), k];
      saveSettings(); renderSettings();
      toast(off ? 'تم تفعيل أذان هذه الصلاة' : 'تم إيقاف أذان هذه الصلاة');
    }));
    $$('.adn-snd').forEach((s) => s.addEventListener('change', () => {
      settings.adhanSound[s.dataset.k] = s.value; saveSettings();
      toast('تم حفظ صوت الأذان');
    }));
    if ($('#preSel')) $('#preSel').onchange = (e) => { settings.pre = +e.target.value; saveSettings(); toast('تم الحفظ'); };
    const renderAdhanDiag = () => {
      const box = $('#adnDiagList');
      if (!box) return;
      let log = [];
      try { log = store.get(ADHAN_DIAG_KEY, []); } catch { log = []; }
      if (!Array.isArray(log) || !log.length) {
        box.innerHTML = '<div class="yq-status-row"><span>لا توجد أحداث مسجلة بعد — جرّب الأذان أو انتظر وقت صلاة.</span></div>';
        return;
      }
      box.innerHTML = log.slice().reverse().map((e) => {
        const d = new Date(e.t || 0);
        return `<div class="yq-status-row" style="align-items:flex-start"><span style="text-align:start"><b>${esc(e.kind || '')}</b> — ${esc(e.detail || '')}<br><small class="muted">${esc(greg(d))} ${esc(fmtTime(d))}</small></span></div>`;
      }).join('');
    };
    if ($('#testAdhan')) $('#testAdhan').onclick = () => { testAdhan().then(() => renderAdhanDiag()).catch(() => renderAdhanDiag()); };
    if ($('#testAdhanAuto')) $('#testAdhanAuto').onclick = () => { testAdhanAuto().then(() => renderAdhanDiag()).catch(() => renderAdhanDiag()); };
    if ($('#testAdhanDefault')) $('#testAdhanDefault').onclick = () => { testAdhanDefault().then(() => renderAdhanDiag()).catch(() => renderAdhanDiag()); };
    if ($('#testAdhanScreen')) $('#testAdhanScreen').onclick = () => {
      const np = nextPrayer();
      adhanDiag('test-screen', `تجربة شاشة الأذان يدوياً (صلاة ${np.key})`);
      adhanTest = { key: np.key };
      go('adhan/' + np.key);
    };
    if ($('#adnDiagCopy')) $('#adnDiagCopy').onclick = async () => {
      const text = adhanDiagText() || 'سجل تشخيص الأذان فارغ.';
      try { await navigator.clipboard.writeText(text); toast('تم نسخ سجل التشخيص'); }
      catch { toast('تعذّر النسخ — انسخ السجل يدوياً من القائمة'); }
    };
    if ($('#adnDiagShare')) $('#adnDiagShare').onclick = () => {
      const text = adhanDiagText() || 'سجل تشخيص الأذان فارغ.';
      shareText(`سجل تشخيص الأذان — يقين\n${text}`);
    };
    if ($('#adnDiagClear')) $('#adnDiagClear').onclick = () => {
      try { store.set(ADHAN_DIAG_KEY, []); } catch { /* تجاهل */ }
      renderAdhanDiag();
      toast('تم مسح سجل التشخيص');
    };
    // حالة نظام الأذان (أندرويد فقط): إشعارات + تنبيه دقيق + بطارية + قنوات
    // + حالة الهاتف الأصلية (ملء الشاشة/رنين/عدم إزعاج/صوت إشعارات).
    // تُحدَّث حالة الهاتف كلما عُرضت الإعدادات.
    const refreshAdhanStatus = async () => {
      if (!LN && !ADHAN_AUTO()) return;
      if (LN) try {
        const perm = await LN.checkPermissions();
        const okN = perm.display === 'granted';
        const n = $('#stNotif'); if (n) n.textContent = okN ? 'مفعّلة ✓' : 'غير مفعّلة';
        const bN = $('#btnNotif'); if (bN) bN.hidden = okN;
        adhanDiag('permissions', `الإشعارات: ${okN ? 'مفعّلة' : 'غير مفعّلة'} (display=${perm.display || '؟'})`);
      } catch { /* تجاهل */ }
      if (LN) try {
        const okE = await exactAllowed();
        const e = $('#stExact'); if (e) e.textContent = okE ? 'مسموح ✓' : 'غير مسموح';
        const bE = $('#exactBtn'); if (bE) bE.hidden = okE;
        adhanDiag('permissions', `التنبيه في الوقت بالضبط: ${okE ? 'مسموح' : 'غير مسموح'}`);
      } catch { /* تجاهل */ }
      await refreshPhoneState();
      if (LN) try {
        const chans = await adhanChannelStates();
        const box = $('#adnChannels');
        if (box) {
          if (!chans) box.innerHTML = '<div class="yq-status-row"><span>قنوات الإشعار (كما يراها النظام)</span><b>تعذّرت القراءة</b></div>';
          else if (!chans.length) box.innerHTML = '<div class="yq-status-row"><span>قنوات الإشعار (كما يراها النظام)</span><b>لا توجد قنوات أذان</b></div>';
          // 2.6.4: بلا روابط URI خام — تسمية قصيرة فقط، فالروابط الطويلة
          // كانت تخرج عن الشاشة وتشوّه البطاقة (لقطتا المستخدم 22:47).
          // الصوت الكامل في سجل التشخيص فقط (channels-state أدناه).
          else box.innerHTML = chans.map((c) => {
            const label = c.id === 'adhan-voice-v3' ? 'صوت الأذان' : 'صوت النظام الافتراضي';
            return `<div class="yq-status-row"><span>${esc(c.id)}</span><b>${label} • أهمية: ${esc(String(c.importance))}</b></div>`;
          }).join('');
        }
        if (chans) adhanDiag('channels-state', chans.map((c) => `${c.id} (أهمية ${c.importance}، صوت ${c.sound})`).join('؛ '));
      } catch { /* تجاهل */ }
    };
    if (NATIVE) {
      refreshAdhanStatus();
      renderAdhanDiag();
      hasVoice().then((v) => { const n = $('#adhanNote'); if (n) n.textContent = v ? 'يصلك الأذان بصوت المؤذن عند دخول كل صلاة حتى لو كان الهاتف مقفولاً.' : 'يصلك إشعار بصوت التنبيه عند دخول كل صلاة.'; });
    }
    if ($('#btnNotif')) $('#btnNotif').onclick = async () => { await ensureNotify(); refreshAdhanStatus(); scheduleAdhan(); };
    if ($('#btnBatt')) $('#btnBatt').onclick = () => openAppSettings();
    // 2.6.4: زر رفع صوت الإشعارات — بارز بعرض البطاقة تحت شريط التحذير،
    // يظهر فقط عند انخفاض الصوت (≤ 3). المستخدم أكّد 22:51 أنه لم يستطع
    // رفعه بنفسه من إعدادات الهاتف، فالرفع من داخل التطبيق بنقرة واحدة
    // صار ضرورياً لا اختيارياً. الرفع إلى الحد الأقصى كاملاً (لا 80٪):
    // setStreamVolume يغيّر مستوى تدفق الإشعارات في النظام حتى يغيّره
    // المستخدم، فيبقى كل أذان قادم مسموعاً دون خطوة استعادة.
    if ($('#btnRaiseVol')) $('#btnRaiseVol').onclick = async () => {
      const AA = ADHAN_AUTO();
      try {
        if (AA && typeof AA.setNotificationVolume === 'function') {
          const max = (phoneState && typeof phoneState.notifVolumeMax === 'number') ? phoneState.notifVolumeMax : 15;
          const r = await AA.setNotificationVolume({ level: max });
          const got = r && typeof r.volume === 'number' ? r.volume : max;
          adhanDiag('phone-state', `رُفع صوت الإشعارات إلى ${got}/${max} من زر بطاقة الحالة`);
          toast('تم رفع صوت الإشعارات إلى الحد الأقصى');
        } else if (AA && typeof AA.openSoundSettings === 'function') {
          await AA.openSoundSettings();
          toast('ارفع صوت الإشعارات من الإعدادات');
        } else {
          toast('ارفع صوت الإشعارات من إعدادات الهاتف');
        }
      } catch { toast('تعذّر رفع صوت الإشعارات — ارفعه من إعدادات الهاتف'); }
      refreshPhoneState().catch(() => {});
    };
    if ($('#btnFsi')) $('#btnFsi').onclick = async () => {
      const AA = ADHAN_AUTO();
      // صفحة منح الملء الكامل للشاشة مباشرة (API 34+)، وإلا صفحة إشعارات التطبيق.
      const openFsi = AA && typeof AA.openFullScreenIntentSettings === 'function' && (!phoneState || phoneState.fsiSettingsAvailable !== false);
      adhanDiag('native-fsi', openFsi ? 'فتح صفحة منح الملء الكامل للشاشة من بطاقة الحالة' : 'فتح إعدادات الإشعارات من بطاقة الحالة لتمكين الملء الكامل للشاشة');
      try { if (AA && openFsi) await AA.openFullScreenIntentSettings(); else if (AA && AA.openNotificationSettings) await AA.openNotificationSettings(); } catch { toast('الإعدادات ← التطبيقات ← يقين ← الإشعارات'); }
      setTimeout(() => refreshAdhanStatus(), 1000);
    };
    $('#hearAdhan').onclick = () => { const a = adhanAudio(); if (!a.paused) { a.pause(); a.currentTime = 0; $('#hearAdhan').textContent = 'استمع لصوت الأذان'; return; } window.dispatchEvent(new CustomEvent('yaqeen:audio', { detail: 'adhan' })); a.play().then(() => { $('#hearAdhan').textContent = 'إيقاف الأذان'; }).catch(() => toast('تعذّر تشغيل صوت الأذان')); a.onended = () => { if ($('#hearAdhan')) $('#hearAdhan').textContent = 'استمع لصوت الأذان'; }; };
    if ($('#exactBtn')) {
      $('#exactBtn').onclick = async () => {
        try { await LN.changeExactNotificationSetting(); } catch { /* تجاهل */ }
        const ok = await exactAllowed();
        if ($('#exactBtn')) $('#exactBtn').hidden = ok;
        if (ok) { toast('تم، سيصلك الأذان في وقته بالضبط'); scheduleAdhan(); }
        refreshAdhanStatus();
      };
    }
    $('#method').onchange = (e) => { settings.method = e.target.value; saveSettings(); toast('تم الحفظ'); };
    $('#reciter').onchange = (e) => { settings.reciter = e.target.value; saveSettings(); toast('تم الحفظ'); };
    $('#translation').onchange = (e) => { settings.translation = e.target.value; saveSettings(); toast('تم الحفظ'); };
    $('#city').onchange = (e) => {
      const c = CITIES[+e.target.value];
      if (!c) return;
      settings.location = { name: c.name, lat: c.lat, lng: c.lng, tz: c.tz };
      settings.method = c.method;
      $('#method').value = c.method;
      saveSettings();
      toast(`تم اختيار ${c.name}`);
    };
    $('#gps').onclick = () => {
      if (!navigator.geolocation) return toast('تحديد الموقع غير مدعوم');
      toast('جاري تحديد الموقع...');
      navigator.geolocation.getCurrentPosition((pos) => {
        const { latitude: lat, longitude: lng } = pos.coords;
        settings.location = { name: `موقعي (${ar(lat.toFixed(2))}، ${ar(lng.toFixed(2))})`, lat, lng, tz: null };
        saveSettings();
        toast('تم تحديد موقعك بنجاح');
        renderSettings();
      }, () => toast('تعذّر تحديد الموقع، اختر مدينة يدوياً'), { enableHighAccuracy: false, timeout: 15000 });
    };
    $$('[data-go]', view).forEach((b) => b.addEventListener('click', () => go(b.dataset.go)));
  }

  // ---------- عن التطبيق ----------
  function renderAbout() {
    view.innerHTML = `
      <div class="yq-page yq-container">
        <header class="yq-wordmark" style="text-align:center">
          <svg class="lg lg-hero-emb" viewBox="0 0 100 124" role="img" aria-label="شعار يقين"><use href="#logo-emblem"/></svg>
          <svg class="lg lg-hero" viewBox="90 20 200 115" role="img" aria-label="يقين"><use href="#logo-word"/></svg>
          <span class="yq-wordmark-en">YAQEEN — رفيق المسلم</span>
        </header>
        <div class="yq-dedication">
          <p class="yq-dedication-label">صدقة جارية</p>
          <p class="yq-dedication-name">عبدالناصر عمران</p>
          <p class="yq-dedication-dua">صدقة جارية على روح والدي عبدالناصر عمران، رحمه الله وغفر له</p>
          <p class="yq-lead">اللَّهُمَّ اغْفِرْ لَهُ وَارْحَمْهُ، وَعَافِهِ وَاعْفُ عَنْهُ، وَأَكْرِمْ نُزُلَهُ، وَوَسِّعْ مُدْخَلَهُ، وَاغْسِلْهُ بِالْمَاءِ وَالثَّلْجِ وَالْبَرَدِ</p>
        </div>
        <section class="yq-section">
          <h2 class="yq-title">عن التطبيق</h2>
          <p class="yq-body" style="margin-top:12px">«يقين — رفيق المسلم» تطبيق إسلامي شامل: مواقيت الصلاة، والقرآن الكريم مع التفسير والتلاوة، والأذكار، والسبحة، واتجاه القبلة، وأسماء الله الحسنى، والموسوعات الإسلامية والمكتبة الدعوية.</p>
          <p class="yq-small" style="margin-top:12px">${versionLabel()}</p>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:16px">
            <button class="yq-btn" data-go="sources">المصادر والتراخيص</button>
            <button class="yq-btn yq-btn--ghost" data-go="settings">الإعدادات</button>
          </div>
        </section>
      </div>`;
    $$('[data-go]', view).forEach((b) => b.addEventListener('click', () => go(b.dataset.go)));
  }

  // ---------- المصادر والتراخيص ----------
  function renderSources() {
    const rows = [
      ['القرآن الكريم — نص عثماني', 'نص غير معدَّل، من مشروع <a href="https://tanzil.net/" target="_blank" rel="noopener">Tanzil</a> عبر <a href="https://alquran.cloud/" target="_blank" rel="noopener">AlQuran Cloud</a>.'],
      ['التفاسير', 'الميسر، والجلالين، والوسيط (طنطاوي)، والبغوي، والقرطبي — عبر AlQuran Cloud.'],
      ['التلاوة والقرّاء', 'الاستماع (بثّ) فقط عبر cdn.islamic.network و mp3quran.net؛ لا تُضمَّن ملفات صوتية في التطبيق.'],
      ['الموسوعات — ويكيبيديا', 'المقالات من ويكيبيديا العربية بترخيص <a href="https://creativecommons.org/licenses/by-sa/4.0/deed.ar" target="_blank" rel="noopener">CC BY-SA 4.0</a>.'],
      ['حصن المسلم', 'النص والصوت من الموقع الرسمي لحصن المسلم؛ تأليف الشيخ سعيد بن وهف القحطاني رحمه الله. لا يُدَّعى هنا ترخيص محدد للمحتوى.'],
      ['الحديث الشريف', 'نصوص تسعة كتب عبر hadith-api (ترخيص Unlicense — ملكية عامة).'],
      ['الخطوط', 'Amiri و Noto Sans Arabic — رخصة SIL Open Font License، عبر Google Fonts.'],
      ['صوت الأذان', 'تسجيل «Beautiful adhan» — ملكية عامة (CC0)، من ويكيميديا كومنز، الرافع Adam-synagda.'],
    ];
    view.innerHTML = `
      <div class="yq-page yq-container">
        <section class="yq-section">
          <p class="yq-eyebrow">الشفافية</p>
          <h2 class="yq-title">المصادر والتراخيص</h2>
          <p class="yq-lead" style="margin-top:8px">مصادر محتوى تطبيق «يقين» والتراخيص التي يُستخدم بموجبها، كما هي موثّقة في التطبيق.</p>
        </section>
        <section class="yq-section">
          <ul class="yq-gold-rows">
            ${rows.map(([t, m]) => `<li class="yq-gold-row"><div class="yq-gold-row-body"><p class="yq-gold-row-title">${t}</p><p class="yq-gold-row-meta">${m}</p></div></li>`).join('')}
          </ul>
          <div style="margin-top:16px">
            <button class="yq-btn yq-btn--ghost" data-go="about">عن التطبيق</button>
          </div>
        </section>
      </div>`;
    $$('[data-go]', view).forEach((b) => b.addEventListener('click', () => go(b.dataset.go)));
  }

  // ---------- قراءة جزء كامل ----------
  function renderJuz(arg) {
    const j = Math.min(30, Math.max(1, parseInt(arg, 10) || 1));
    $('#pageTitle').textContent = `الجزء ${ar(j)} • ${JUZ_NAMES[j - 1]}`;
    view.innerHTML = '<div class="loader"></div>';
    let alive = true;
    fetchJSON(`${API}/juz/${j}/quran-uthmani`, `juz:${j}`).then((d) => {
      if (!alive) return;
      let html = '';
      let curS = 0;
      d.ayahs.forEach((a) => {
        if (a.surah.number !== curS) {
          if (curS) html += '</p>';
          curS = a.surah.number;
          if (a.numberInSurah === 1) {
            html += `<div class="surah-header small yq-surah-head"><h2>${a.surah.name}</h2></div>`;
            if (curS !== 1 && curS !== 9) html += '<div class="basmala">بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ</div>';
          } else {
            html += `<div class="juz-surah">${a.surah.name}</div>`;
          }
          html += '<p class="quran-text">';
        }
        let t = a.text;
        if (a.numberInSurah === 1 && curS !== 1 && curS !== 9 && /^بِسْمِ|^بِسۡمِ/.test(t)) t = t.split(' ').slice(4).join(' ');
        html += `<span class="ayah" data-s="${curS}" data-a="${a.numberInSurah}">${t}</span> <span class="ayah-num yq-ayah-num">${ar(a.numberInSurah)}</span> `;
      });
      html += '</p>';
      const k = khatmaState();
      view.innerHTML = `
        <p class="muted center" style="font-size:.85rem;margin:0 0 10px">اضغط على أي آية لفتح السورة والاستماع والتفسير</p>
        <article class="mushaf yq-reading">${html}</article>
        <button class="btn block" id="doneJuz" style="margin-top:14px">${k.done[j - 1] ? '✓ هذا الجزء مُسجَّل في ختمتك' : '✓ أتممت قراءة هذا الجزء'}</button>
        <div style="display:flex;gap:10px;margin-top:10px">
          ${j > 1 ? `<button class="btn ghost block" data-go="juz/${j - 1}">→ الجزء السابق</button>` : ''}
          ${j < 30 ? `<button class="btn ghost block" data-go="juz/${j + 1}">الجزء التالي ←</button>` : ''}
        </div>
        <p class="yq-small" style="text-align:center;margin:12px 0 0">نص القرآن الكريم من <a href="https://tanzil.net/" target="_blank" rel="noopener">Tanzil</a> عبر AlQuran Cloud — نص غير معدَّل</p>`;
      document.documentElement.style.setProperty('--qsize', settings.qsize + 'rem');
      $$('[data-go]', view).forEach((b) => b.addEventListener('click', () => go(b.dataset.go)));
      $$('.ayah', view).forEach((el) => el.addEventListener('click', () => go(`surah/${el.dataset.s}/${el.dataset.a}`)));
      $('#doneJuz').onclick = () => {
        const s = khatmaState();
        s.done[j - 1] = true;
        saveKhatma(s);
        toast(`بارك الله فيك، أتممت الجزء ${ar(j)}`);
        go('khatma');
      };
    }).catch(() => alive && errorBox(() => renderJuz(arg)));
    return () => { alive = false; };
  }

  // ---------- ختمة القرآن ----------
  function khatmaState() {
    const k = Object.assign({ days: 30, start: todayKey(), done: [], completed: 0 }, store.get('khatma', {}));
    if (!Array.isArray(k.done) || k.done.length !== 30) k.done = Array(30).fill(false);
    return k;
  }
  const saveKhatma = (k) => store.set('khatma', k);
  const dayNumber = (key) => { const [y, m, d] = key.split('-').map(Number); return Math.floor(Date.UTC(y, m - 1, d) / 86400000); };

  function renderKhatma() {
    const k = khatmaState();
    const doneN = k.done.filter(Boolean).length;
    const elapsed = Math.max(0, dayNumber(todayKey()) - dayNumber(k.start));
    const daysLeft = Math.max(1, k.days - elapsed);
    const pagesPerDay = Math.ceil(((30 - doneN) * 20) / daysLeft);
    const nextJ = k.done.indexOf(false);
    view.innerHTML = `
      <section class="yq-hero">
        <p class="yq-eyebrow">الختمة رقم ${ar(k.completed + 1)}${k.completed ? ` • أتممت ${ar(k.completed)} ختمة من قبل` : ''}</p>
        <div class="yq-hero-title">${ar(doneN)} من ٣٠ جزءاً</div>
        <div class="yq-khatmah-progress"><span style="width:${(doneN / 30) * 100}%"></span></div>
        <div class="yq-hero-foot">${doneN === 30 ? 'ختمت القرآن الكريم، تقبّل الله منك' : `وردك اليومي: ${ar(pagesPerDay)} صفحة تقريباً • متبقٍ ${ar(daysLeft)} يوم`}</div>
      </section>
      ${doneN === 30 ? `
        <div class="card center" style="margin-top:14px"><h3 style="justify-content:center">🎉 مبارك ختم القرآن</h3>
          <p class="hadith-text" style="font-size:1.15rem">صدقة جارية على روح والدي عبدالناصر عمران، رحمه الله وغفر له</p>
          <button class="btn block" id="newK">ابدأ ختمة جديدة</button></div>` : `
        <button class="btn block" style="margin-top:14px" data-go="juz/${nextJ + 1}">تابع القراءة: الجزء ${ar(nextJ + 1)} (${JUZ_NAMES[nextJ]})</button>`}
      <div class="section-title">مدة الختمة</div>
      <div class="seg" id="kdays">${[7, 15, 30, 60].map((v) => `<button data-v="${v}">${ar(v)} يوم</button>`).join('')}</div>
      <div class="section-title">الأجزاء <small class="muted" style="font-weight:500">(اضغط على الدائرة لتسجيل القراءة)</small></div>
      <ol class="yq-index">
        ${JUZ_NAMES.map((nm, i) => `
          <li class="yq-index-item juz-row ${k.done[i] ? 'done' : ''}">
            <span class="yq-index-num">${toAr(String(i + 1).padStart(2, '0'))}</span>
            <button class="check" data-t="${i}" aria-label="تسجيل الجزء ${i + 1}">${k.done[i] ? '✓' : ''}</button>
            <button class="juz-open" data-go="juz/${i + 1}"><b>الجزء ${ar(i + 1)}</b><small class="muted">${nm}</small></button>
          </li>`).join('')}
      </ol>
      <button class="btn ghost block" id="resetK" style="margin-top:10px">إعادة ضبط الختمة الحالية</button>`;
    $$('[data-go]', view).forEach((b) => b.addEventListener('click', () => go(b.dataset.go)));
    $$('#kdays button').forEach((b) => {
      b.classList.toggle('active', +b.dataset.v === k.days);
      b.addEventListener('click', () => { k.days = +b.dataset.v; k.start = todayKey(); saveKhatma(k); renderKhatma(); });
    });
    $$('[data-t]', view).forEach((b) => b.addEventListener('click', () => { const i = +b.dataset.t; k.done[i] = !k.done[i]; saveKhatma(k); renderKhatma(); }));
    if ($('#newK')) $('#newK').onclick = () => { k.completed++; k.done = Array(30).fill(false); k.start = todayKey(); saveKhatma(k); toast('بدأت ختمة جديدة، وفقك الله'); renderKhatma(); };
    $('#resetK').onclick = (e) => {
      if (e.currentTarget.dataset.sure) { k.done = Array(30).fill(false); k.start = todayKey(); saveKhatma(k); renderKhatma(); return; }
      e.currentTarget.dataset.sure = '1';
      e.currentTarget.textContent = 'اضغط مرة أخرى للتأكيد';
    };
  }

  // ---------- متابعة الصلوات وقضاء الفوائت ----------
  const PRAY5 = PRAYERS.filter((p) => !p.sun);
  function renderTracker() {
    const all = store.get('tracker', {});
    const qada = Object.assign({ fajr: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 }, store.get('qada', {}));
    const keyOf = (d) => ymdIn(d, tz()).join('-');
    const today = keyOf(new Date());
    const day = all[today] || {};
    const days = Array.from({ length: 7 }, (_, i) => new Date(Date.now() - (6 - i) * 86400000));
    let streak = 0;
    for (let i = 0; i < 400; i++) {
      const d = all[keyOf(new Date(Date.now() - i * 86400000))] || {};
      if (PRAY5.every((p) => d[p.key])) streak++;
      else if (i > 0) break;
    }
    const doneToday = PRAY5.filter((p) => day[p.key]).length;
    view.innerHTML = `
      <div class="stats">
        <div class="stat"><b>${ar(doneToday)} / ٥</b><small>صلوات اليوم</small></div>
        <div class="stat"><b>${ar(streak)}</b><small>أيام متتالية كاملة</small></div>
      </div>
      <div class="section-title">صلوات اليوم</div>
      <ul class="yq-timeline">
        ${PRAY5.map((p) => `<button class="yq-timeline-item prayer-row track ${day[p.key] ? 'on' : ''}" data-p="${p.key}"><span class="yq-timeline-dot"></span><span class="yq-timeline-label">${p.ic} ${p.name}</span><span class="yq-timeline-time check">${day[p.key] ? '✓' : ''}</span></button>`).join('')}
      </ul>
      <div class="section-title">آخر ٧ أيام</div>
      <div class="card week">
        <div class="week-grid">
          <span></span>${days.map((d) => `<span class="wd">${d.toLocaleDateString('ar-EG', { weekday: 'short', timeZone: tz() })}</span>`).join('')}
          ${PRAY5.map((p) => `<span class="wp">${p.name}</span>${days.map((d) => `<span class="dot ${(all[keyOf(d)] || {})[p.key] ? 'on' : ''}"></span>`).join('')}`).join('')}
        </div>
      </div>
      <div class="section-title">الصلوات الفائتة (القضاء)</div>
      <div class="card">
        ${PRAY5.map((p) => `<div class="yq-gold-row qada-row"><span>${p.name}</span><div class="qada-ctrl"><button class="icon-btn" data-q="${p.key}" data-d="-1" aria-label="قضيت صلاة">−</button><b>${arG(qada[p.key])}</b><button class="icon-btn" data-q="${p.key}" data-d="1" aria-label="إضافة فائتة">+</button></div></div>`).join('')}
        <small class="muted">أضف عدد الصلوات الفائتة بزر (+)، واضغط (−) كلما قضيت صلاة منها.</small>
      </div>`;
    $$('[data-p]', view).forEach((b) => b.addEventListener('click', () => {
      day[b.dataset.p] = !day[b.dataset.p];
      all[today] = day;
      store.set('tracker', all);
      if (day[b.dataset.p]) navigator.vibrate && navigator.vibrate(15);
      if (PRAY5.every((p) => day[p.key])) toast('ما شاء الله، أتممت صلوات اليوم 🤍');
      renderTracker();
    }));
    $$('[data-q]', view).forEach((b) => b.addEventListener('click', () => {
      qada[b.dataset.q] = Math.max(0, qada[b.dataset.q] + +b.dataset.d);
      store.set('qada', qada);
      renderTracker();
    }));
  }

  // ---------- التقويم الهجري والمناسبات ----------
  function hijriParts(d) {
    const p = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn', { day: 'numeric', month: 'numeric', year: 'numeric', timeZone: tz() }).formatToParts(d);
    const g = (t) => parseInt(p.find((x) => x.type === t).value, 10);
    return { d: g('day'), m: g('month'), y: g('year') };
  }
  const HIJRI_EVENTS = [
    { m: 1, d: 1, name: 'رأس السنة الهجرية', ic: '🌙' },
    { m: 1, d: 10, name: 'يوم عاشوراء', ic: '🤲', note: 'يُستحب صيامه مع يوم قبله' },
    { m: 9, d: 1, name: 'أول أيام شهر رمضان', ic: '🏮' },
    { m: 9, d: 21, name: 'العشر الأواخر من رمضان', ic: '✨', note: 'تُتحرّى فيها ليلة القدر' },
    { m: 10, d: 1, name: 'عيد الفطر المبارك', ic: '🎉' },
    { m: 12, d: 1, name: 'العشر الأوائل من ذي الحجة', ic: '🕋', note: 'أفضل أيام الدنيا' },
    { m: 12, d: 9, name: 'يوم عرفة', ic: '⛰️', note: 'صيامه يكفّر السنة الماضية والباقية' },
    { m: 12, d: 10, name: 'عيد الأضحى المبارك', ic: '🐑' },
  ];
  function renderCalendar() {
    const DAY = 86400000;
    const now = Date.now();
    const found = [];
    let white = null;
    for (let i = 0; i < 390 && found.length < HIJRI_EVENTS.length; i++) {
      const d = new Date(now + i * DAY);
      const h = hijriParts(d);
      HIJRI_EVENTS.forEach((e) => { if (e.m === h.m && e.d === h.d && !found.some((f) => f.e === e)) found.push({ e, d, i }); });
      if (!white && h.d >= 13 && h.d <= 15) white = { d, i, h };
    }
    found.sort((a, b) => a.i - b.i);

    let anchor = new Date(now);
    const drawMonth = () => {
      const h0 = hijriParts(anchor);
      const first = new Date(anchor.getTime() - (h0.d - 1) * DAY);
      const cells = [];
      for (let i = 0; i < 31; i++) {
        const d = new Date(first.getTime() + i * DAY);
        const h = hijriParts(d);
        if (h.m !== h0.m) break;
        cells.push({ d, h });
      }
      const lead = (first.getDay() + 1) % 7; // السبت أول الأسبوع
      const todayK = ymdIn(new Date(), tz()).join('-');
      const title = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura-nu-arab', { month: 'long', year: 'numeric', timeZone: tz() }).format(first);
      $('#cal').innerHTML = `
        <div class="date-nav"><button class="icon-btn" id="cp" aria-label="الشهر السابق"><svg viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></svg></button>
          <div class="d"><b>${title}</b><small>${first.toLocaleDateString('ar-EG', { month: 'long', year: 'numeric', timeZone: tz() })}</small></div>
          <button class="icon-btn" id="cn" aria-label="الشهر التالي"><svg viewBox="0 0 24 24"><path d="M15 6l-6 6 6 6"/></svg></button></div>
        <div class="cal-grid">
          ${['سبت', 'أحد', 'إثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة'].map((w) => `<span class="cw">${w}</span>`).join('')}
          ${'<span></span>'.repeat(lead)}
          ${cells.map(({ d, h }) => {
            const ev = HIJRI_EVENTS.some((e) => e.m === h.m && e.d === h.d);
            const wh = h.d >= 13 && h.d <= 15;
            const isToday = ymdIn(d, tz()).join('-') === todayK;
            return `<span class="cd ${isToday ? 'today' : ''} ${ev ? 'ev' : ''} ${wh ? 'white' : ''}"><b>${ar(h.d)}</b><small>${ar(ymdIn(d, tz())[2])}</small></span>`;
          }).join('')}
        </div>
        <div class="cal-legend"><span><i class="lg ev"></i>مناسبة</span><span><i class="lg white"></i>الأيام البيض</span><span><i class="lg today"></i>اليوم</span></div>`;
      $('#cp').onclick = () => { anchor = new Date(first.getTime() - 2 * DAY); drawMonth(); };
      $('#cn').onclick = () => { anchor = new Date(cells[cells.length - 1].d.getTime() + 2 * DAY); drawMonth(); };
    };

    const inDays = (i) => (i === 0 ? 'اليوم' : i === 1 ? 'غداً' : `بعد ${arG(i)} يوم`);
    view.innerHTML = `
      <div class="card" id="cal"></div>
      <div class="section-title">المناسبات القادمة</div>
      <ul class="yq-timeline">
        ${white ? `<li class="yq-timeline-item"><span class="yq-timeline-dot"></span><span class="yq-timeline-label">🌕 الأيام البيض (صيام ١٣ و١٤ و١٥)<br><small class="muted">${white.d.toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'long', timeZone: tz() })}</small></span><span class="yq-timeline-time">${inDays(white.i)}</span></li>` : ''}
        ${found.map(({ e, d, i }) => `<li class="yq-timeline-item"><span class="yq-timeline-dot"></span><span class="yq-timeline-label">${e.ic} ${e.name}<br><small class="muted">${d.toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: tz() })}${e.note ? ' • ' + e.note : ''}</small></span><span class="yq-timeline-time">${inDays(i)}</span></li>`).join('')}
      </ul>
      <p class="muted center" style="font-size:.8rem;margin-top:14px">التواريخ حسب تقويم أم القرى، وقد تختلف يوماً حسب رؤية الهلال في بلدك.</p>`;
    drawMonth();
  }

  // ---------- حاسبة الزكاة ----------
  function renderZakat() {
    const z = Object.assign({ cash: '', g24: '', g21: '', g18: '', silver: '', gp: '', sp: '', debts: '' }, store.get('zakat', {}));
    const F = [
      ['cash', 'النقود والمدخرات وأرصدة البنوك', 'المبلغ'],
      ['g24', 'ذهب عيار ٢٤', 'جرام'],
      ['g21', 'ذهب عيار ٢١', 'جرام'],
      ['g18', 'ذهب عيار ١٨', 'جرام'],
      ['silver', 'الفضة', 'جرام'],
      ['debts', 'ديون عليك مستحقة الآن', 'المبلغ'],
    ];
    view.innerHTML = `
      <div class="card">
        <h3>💰 أسعار اليوم</h3>
        <div class="field"><label for="z-gp">سعر جرام الذهب عيار ٢٤ (بعملتك)</label><input class="search" id="z-gp" inputmode="decimal" value="${esc(z.gp)}" placeholder="مثال: 4500"></div>
        <div class="field" style="margin:0"><label for="z-sp">سعر جرام الفضة (اختياري)</label><input class="search" id="z-sp" inputmode="decimal" value="${esc(z.sp)}" placeholder="مثال: 55"></div>
      </div>
      <div class="card">
        <h3>📋 أموالك</h3>
        ${F.map(([k, l, u]) => `<div class="field"><label for="z-${k}">${l}</label><input class="search" id="z-${k}" inputmode="decimal" value="${esc(z[k])}" placeholder="${u}"></div>`).join('')}
      </div>
      <div class="card zakat-result" id="zres"></div>
      <div class="card"><h3>📌 شروط وجوب الزكاة</h3>
        <ul class="muted" style="margin:0;padding-inline-start:20px;font-size:.9rem;line-height:1.9">
          <li>بلوغ النصاب: قيمة ٨٥ جراماً من الذهب عيار ٢٤.</li>
          <li>مرور عام هجري كامل على بلوغ المال النصاب.</li>
          <li>مقدار الزكاة: ربع العشر (٢٫٥٪) من إجمالي المال.</li>
          <li>ذهب الزينة المستعمل فيه خلاف بين العلماء، فاسأل أهل العلم في بلدك.</li>
        </ul></div>`;
    const num = (v) => { const n = parseFloat(String(v).replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[٫,]/g, '.')); return isNaN(n) ? 0 : n; };
    const money = (n) => n.toLocaleString('ar-EG', { maximumFractionDigits: 2 });
    const calc = () => {
      ['gp', 'sp', ...F.map((f) => f[0])].forEach((k) => { z[k] = $(`#z-${k}`).value; });
      store.set('zakat', z);
      const gp = num(z.gp);
      const goldEq = num(z.g24) + (num(z.g21) * 21) / 24 + (num(z.g18) * 18) / 24;
      const total = num(z.cash) + goldEq * gp + num(z.silver) * num(z.sp) - num(z.debts);
      const res = $('#zres');
      if (!gp) { res.innerHTML = '<p class="center muted" style="margin:0">أدخل سعر جرام الذهب عيار ٢٤ لحساب النصاب.</p>'; return; }
      const nisab = 85 * gp;
      const due = total >= nisab;
      res.innerHTML = `
        <div class="z-line"><span>إجمالي أموالك الزكوية</span><b>${money(Math.max(0, total))}</b></div>
        <div class="z-line"><span>النصاب (٨٥ جرام ذهب)</span><b>${money(nisab)}</b></div>
        <div class="z-total ${due ? 'due' : ''}">${due ? `<small>الزكاة الواجبة</small><b>${money(total * 0.025)}</b>` : '<b style="font-size:1.1rem">لم يبلغ مالك النصاب، فلا زكاة عليك</b>'}</div>`;
    };
    $$('input', view).forEach((i) => i.addEventListener('input', calc));
    calc();
  }

  // ---------- العلامات المحفوظة ----------
  function renderBookmarks() {
    const bm = getBM();
    if (!bm.length) {
      view.innerHTML = `<div class="card center"><p style="font-size:2.5rem;margin:0">🔖</p><p>لا توجد علامات بعد.</p><p class="muted" style="font-size:.9rem">أثناء القراءة اضغط على أي آية ثم اختر «حفظ علامة».</p><button class="btn" data-go="quran">افتح المصحف</button></div>`;
      $('[data-go]', view).onclick = () => go('quran');
      return;
    }
    view.innerHTML = '<ul class="yq-gold-rows">' + bm.map((b, i) => `
      <li class="yq-gold-row bm">
        <button class="bm-open" data-i="${i}"><p class="bm-text">${b.text}${b.text.length >= 90 ? '…' : ''}</p><small class="muted">${b.name} • الآية ${ar(b.ayah)}</small></button>
        <button class="icon-btn" data-del="${i}" aria-label="حذف العلامة"><svg viewBox="0 0 24 24"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg></button>
      </li>`).join('') + '</ul>';
    $$('[data-i]', view).forEach((b) => b.addEventListener('click', () => { const x = bm[+b.dataset.i]; go(`surah/${x.n}/${x.ayah}`); }));
    $$('[data-del]', view).forEach((b) => b.addEventListener('click', () => { bm.splice(+b.dataset.del, 1); store.set('bookmarks', bm); renderBookmarks(); }));
  }


  // ---------- الأذان في تطبيق أندرويد (إشعارات مجدولة تعمل والهاتف مقفول) ----------
  // كيف يعمل صوت المؤذن في الخلفية: ملف adhan/adhan.mp3 يُنسخ أثناء بناء
  // أندرويد إلى res/raw/adhan.mp3، وقناة الإشعار adhan-voice-v2 تشغّل
  // مقطعاً قصيراً منه (res/raw/adhan_short.mp3، أول 30 ثانية) لأن
  // أندرويد 8+ يربط الصوت بالقناة لا بالإشعار. build-web.js يضبط
  // window.NOOR_NATIVE_ADHAN = true عند وجود adhan/adhan.mp3.
  // لماذا قنوات ‎-v2؟ قنوات أندرويد غير قابلة للتعديل بعد إنشائها: النسخة
  // الأصلية (Athar) أنشأت adhan-voice بصوت يشير إلى ملف غير موجود، فبقيت
  // القناة صامتة مهما أعدنا إنشاءها بالمعرّف نفسه. القنوات الجديدة
  // بمعرّفات مختلفة، والقديمة تُحذف صراحة عند كل ensureNotify.
  const ADHAN_DIAG_KEY = 'adhan-diag'; // localStorage: yaqeen:adhan-diag
  const ADHAN_DIAG_MAX = 200;
  // سجل تشخيص دائم لمسار الأذان (تشخيص/جدولة/استقبال/ضغطة/فتح شاشة/صوت/
  // حالة قنوات/أذونات). لا يرمي أبداً ولا يعطّل الجدولة إن فشل التخزين.
  function adhanDiag(kind, detail) {
    try {
      const log = store.get(ADHAN_DIAG_KEY, []);
      const arr = Array.isArray(log) ? log : [];
      arr.push({ t: Date.now(), kind, detail: typeof detail === 'string' ? detail : JSON.stringify(detail == null ? '' : detail) });
      while (arr.length > ADHAN_DIAG_MAX) arr.shift();
      store.set(ADHAN_DIAG_KEY, arr);
    } catch { /* السجل تشخيصي فقط — لا يعطّل شيئاً */ }
  }
  function adhanDiagText() {
    try {
      const log = store.get(ADHAN_DIAG_KEY, []);
      if (!Array.isArray(log) || !log.length) return '';
      return log.slice().reverse().map((e) => {
        const d = new Date(e.t || 0);
        return `[${greg(d)} ${fmtTime(d)}] ${e.kind}: ${e.detail || ''}`;
      }).join('\n');
    } catch { return ''; }
  }
  const ADHAN_LEGACY_CHANNEL_IDS = ['adhan-voice-v2', 'adhan-voice', 'adhan-beep', 'adhan-silent', 'adhan-alert'];
  const LN = NATIVE && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications;
  // الإضافة الأصلية «AdhanAuto» (2.6.2): منبّهات دقيقة + نيّة ملء الشاشة
  // (full-screen intent) ليعمل الأذان تلقائياً والهاتف مقفول والتطبيق مغلق.
  // كل استدعاء محمي: إن غابت الإضافة (متصفح/بناء ويب) نعود إلى LN كما في
  // 2.6.1 ولا نرمي أبداً.
  const ADHAN_AUTO = () => (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.AdhanAuto) || null;
  let phoneState = null; // آخر حالة هاتف مقروءة عبر AdhanAuto.getPhoneState()
  let nativeAdhanExact = null; // null = غير معروف؛ true/false من نتيجة scheduleAlarms
  const ADHAN_CHANNELS = {
    voice: { id: 'adhan-voice-v3', name: 'الأذان ومواقيت الصلاة', description: 'تنبيه عند دخول وقت كل صلاة بصوت المؤذن (الأذان كاملاً)', importance: 5, sound: 'adhan.mp3' },
    beep: { id: 'adhan-beep-v2', name: 'تنبيه الصلاة (قصير)', description: 'تنبيه قصير عند دخول وقت الصلاة', importance: 4 },
    silent: { id: 'adhan-silent-v2', name: 'تنبيه الصلاة (صامت)', description: 'إشعار بصري فقط عند دخول وقت الصلاة، بلا صوت', importance: 2 },
  };
  let voiceKnown = null;
  async function hasVoice() {
    if (voiceKnown === null) voiceKnown = !!window.NOOR_NATIVE_ADHAN;
    return voiceKnown;
  }
  function adhanChannelFor(key) {
    const s = (settings.adhanSound && settings.adhanSound[key]) || 'voice';
    return (ADHAN_CHANNELS[s] || ADHAN_CHANNELS.voice).id;
  }
  let channelReady = false;
  let notifyGranted = null; // null = لم يُفحص بعد؛ true/false بعد ensureNotify
  async function ensureNotify() {
    if (!LN) return false;
    let perm = await LN.checkPermissions();
    if (perm.display !== 'granted') perm = await LN.requestPermissions();
    notifyGranted = perm.display === 'granted';
    if (!notifyGranted) return false;
    if (!channelReady) {
      // أولاً: حذف قنوات الإصدارات القديمة (ومنها adhan-voice المسمومة
      // بصوت يشير إلى ملف غير موجود) — إعادة الإنشاء بالمعرّف نفسه لا
      // تغيّر شيئاً في أندرويد لأن القناة غير قابلة للتعديل بعد إنشائها.
      const deleted = [];
      for (const id of ADHAN_LEGACY_CHANNEL_IDS) {
        try { await LN.deleteChannel({ id }); deleted.push(id); } catch { /* قد لا توجد */ }
      }
      const voice = await hasVoice();
      for (const k of ['voice', 'beep', 'silent']) {
        const c = ADHAN_CHANNELS[k];
        await LN.createChannel({
          id: c.id, name: c.name, description: c.description,
          importance: c.importance, visibility: 1,
          vibration: c.importance >= 4, lights: c.importance >= 4,
          ...(k === 'voice' && voice ? { sound: 'adhan.mp3' } : {}),
        });
      }
      adhanDiag('channels', `حذف قنوات قديمة: ${deleted.join(', ') || 'لا شيء'}؛ أُنشئت adhan-voice-v3 (صوت adhan.mp3 كاملاً، أهمية 5) وadhan-beep-v2 (4) وadhan-silent-v2 (2)`);
      channelReady = true;
    }
    return true;
  }
  // قراءة حالة القنوات الفعلية كما يراها النظام (لا كما نفترضها): تُعرض
  // في بطاقة الحالة وتُسجَّل في سجل التشخيص. القناة المسمومة تظهر هنا.
  async function adhanChannelStates() {
    if (!LN || !LN.listChannels) return null;
    try {
      const r = await LN.listChannels();
      const all = (r && r.channels) || [];
      return all.filter((c) => c && typeof c.id === 'string' && (c.id.startsWith('adhan-') || c.id === 'adhan-alert'))
        .map((c) => ({ id: c.id, name: c.name || '', importance: c.importance == null ? '؟' : c.importance, sound: c.sound || 'بلا صوت' }));
    } catch { return null; }
  }
  let scheduling = null;
  // الجدولة (2.6.2): AdhanAuto هو المصدر الوحيد لتنبيهات الأذان — لا ازدواج.
  // تُبنى القائمة نفسها كما في 2.6.1 (المعرّفات الحتمية day*10+i+1 نفسها،
  // والعناوين والنصوص والقنوات نفسها)، ثم: cancelAlarms ثم scheduleAlarms.
  // LN يبقى فقط لتذكيرات الأذكار (200+) والتذكير قبل الأذان (400+).
  // إن غابت الإضافة الأصلية: الأذان عبر LN كما في 2.6.1 تماماً + سجل
  // native-missing-fallback. إن كان exact:false: تحذير في السجل والبطاقة
  // فقط — لا جدولة مزدوجة عبر LN أبداً.
  function scheduleAdhan() {
    if (!LN && !ADHAN_AUTO()) return;
    clearTimeout(scheduling);
    scheduling = setTimeout(async () => {
      try {
        const AA = ADHAN_AUTO();
        const after = window.Noor && window.Noor.azAfterPrayer && window.Noor.azAfterPrayer();
        if (!settings.alerts && !after) { adhanDiag('schedule-skip', 'التنبيهات متوقفة من الإعدادات ولا تذكير بعد الصلاة — لم تُجدول إشعارات'); return; }
        // تغيير المنطقة الزمنية: مواقيت الجدولة المطلقة تصبح خاطئة بفرق
        // الإزاحة؛ نكتشف التغيير هنا (يُستدعى عند كل فتح للتطبيق) ونعيد
        // الجدولة فوراً من المواقيت الجديدة.
        const off = new Date().getTimezoneOffset();
        const prevOff = store.get('tzOff', null);
        if (prevOff !== null && prevOff !== off) toast('تم تحديث مواقيت الصلاة بعد تغيير المنطقة الزمنية');
        store.set('tzOff', off);
        if (LN) {
          const pending = await LN.getPending();
          const old = pending.notifications.filter((n) => n.id < 1000);
          if (old.length) await LN.cancel({ notifications: old.map((n) => ({ id: n.id })) });
          if (!(await ensureNotify())) { adhanDiag('schedule-fail', 'الإشعارات غير مفعّلة — لم تُجدول إشعارات الأذان'); toast('فعّل الإشعارات للتطبيق ليصلك الأذان'); return; }
          if (after || +settings.pre > 0) await LN.createChannel({ id: 'azkar', name: 'تذكير الأذكار', description: 'أذكار الصباح والمساء والنوم والتذكير بالذكر خلال اليوم', importance: 4, visibility: 1 });
        } else if (AA && AA.getPhoneState) {
          // بلا LN: أفضل جهد عبر حالة الهاتف — إن كانت الإشعارات مرفوضة
          // صراحة لا نجدول؛ وإلا نمضي (المنبّه الأصلي يتحقق بنفسه).
          try {
            const st = await AA.getPhoneState();
            if (st && st.notificationsEnabled === false) { adhanDiag('schedule-fail', 'الإشعارات غير مفعّلة — لم تُجدول إشعارات الأذان'); toast('فعّل الإشعارات للتطبيق ليصلك الأذان'); return; }
          } catch { /* أفضل جهد — نمضي بالجدولة */ }
        }
        const now = Date.now();
        const adhanList = []; // للأذان: AdhanAuto أو LN (شكل LN أدناه)
        const lnList = []; // لـ LN فقط: أذكار ما بعد الصلاة (200+) + قبل الأذان (400+)
        for (let day = 0; day < 20; day++) {
          const t = timesFor(new Date(now + day * 86400000));
          PRAY5.forEach((p, i) => {
            const at = t[p.key];
            const at2 = new Date(at.getTime() + 15 * 60000);
            if (day < 14 && after && at2.getTime() > now + 5000) lnList.push({ id: 200 + day * 10 + i + 1, title: `📿 أذكار ما بعد صلاة ${p.name}`, body: 'أستغفر الله (ثلاثاً)، اللهم أنت السلام ومنك السلام، تباركت يا ذا الجلال والإكرام — افتح «يقين» لإتمام الأذكار', channelId: 'azkar', extra: { route: 'azcat/azkar/prayer' }, schedule: { at: at2, allowWhileIdle: true }, autoCancel: true });
            const pre = day < 14 ? (+settings.pre || 0) : 0;
            const offP = (settings.alertOff || []).includes(p.key);
            if (settings.alerts && !offP && pre > 0) { const atP = new Date(at.getTime() - pre * 60000); if (atP.getTime() > now + 5000) lnList.push({ id: 400 + day * 10 + i + 1, title: `⏳ بقي ${ar(pre)} دقيقة على أذان ${p.name}`, body: `${fmtTime(at)} • تهيّأ للصلاة`, channelId: 'azkar', schedule: { at: atP, allowWhileIdle: true }, autoCancel: true }); }
            if (!settings.alerts || offP || at.getTime() <= now + 5000) return;
            adhanList.push({
              id: day * 10 + i + 1,
              key: p.key,
              title: `حان الآن موعد صلاة ${p.name}`,
              body: `${fmtTime(at)} • ${settings.location.name}\nحيّ على الصلاة، حيّ على الفلاح`,
              channelId: adhanChannelFor(p.key),
              at: at.getTime(),
              extra: { route: 'adhan/' + p.key, adhan: p.key, at: at.getTime() },
              schedule: { at, allowWhileIdle: true },
              autoCancel: true,
            });
          });
        }
        if (AA) {
          // المسار الأصلي: إلغاء ثم جدولة — الأذان عبر AdhanAuto فقط.
          // 2.6.3 — منع الازدواج نهائياً: scheduleAlarms يعيد عدد ما جُدول
          // فعلاً (scheduled). لا نعود إلى LN إلا في إحدى حالتين:
          // (أ) رفضت الإضافة الوعد (catch أدناه): نلغي الأصلي أولاً (أفضل
          // جهد — يمسح أي منبّهات جُدولت جزئياً قبل الفشل) ثم نجدول عبر LN؛
          // (ب) نجح الاستدعاء لكن scheduled === 0 رغم وجود قائمة مستقبلية:
          // الأصلي لم يجدول شيئاً، فالعودة إلى LN آمنة. أما إن جُدول بعضها
          // أو كلها — حتى لو عبر setAndAllowWhileIdle غير الدقيق
          // (inexactCount) بعد رفض التنبيه الدقيق — فلا LN أبداً.
          try {
            if (AA.cancelAlarms) await AA.cancelAlarms();
            let exact = null;
            let scheduled = 0;
            let inexactCount = 0;
            if (adhanList.length) {
              const res = await AA.scheduleAlarms({ alarms: adhanList.map((n) => ({ id: n.id, key: n.key, at: n.at, title: n.title, body: n.body, channelId: n.channelId })) });
              exact = res ? res.exact : null;
              scheduled = res && typeof res.scheduled === 'number' ? res.scheduled : 0;
              inexactCount = res && typeof res.inexactCount === 'number' ? res.inexactCount : 0;
            }
            nativeAdhanExact = exact === false ? false : (exact === true ? true : null);
            if (adhanList.length && scheduled === 0) {
              // الأصلي أكّد أنه لم يجدول شيئاً — العودة إلى LN آمنة.
              adhanDiag('native-schedule', `AdhanAuto أعاد scheduled=0 رغم وجود ${adhanList.length} تنبيهاً — عودة إلى LN`);
              adhanDiag('native-missing-fallback', `AdhanAuto لم يجدول شيئاً — جُدول الأذان عبر LocalNotifications (${adhanList.length} تنبيهاً)`);
              if (LN) await LN.schedule({ notifications: adhanList });
            } else if (exact === false) {
              adhanDiag('native-schedule', `⚠️ جُدول ${scheduled} تنبيه أذان عبر AdhanAuto لمدة 14 يوماً لكن التنبيه الدقيق غير مسموح (exact:false${inexactCount ? `، غير دقيق: ${inexactCount}` : ''}) — قد يتأخر الأذان`);
            } else {
              adhanDiag('native-schedule', `جُدول ${scheduled} تنبيه أذان عبر AdhanAuto لمدة 14 يوماً (exact: ${exact === null ? '؟' : exact}${inexactCount ? `، غير دقيق: ${inexactCount}` : ''})`);
            }
          } catch (e) {
            // الإضافة موجودة لكن الجدولة الأصلية فشلت: ألغِ الأصلي أولاً
            // (يمسح أي منبّهات جُدولت جزئياً قبل الفشل) ثم عُد إلى LN حتى
            // لا يضيع الأذان — ولا ازدواج بعد الإلغاء.
            let cancelled = null;
            try {
              if (AA.cancelAlarms) {
                const c = await AA.cancelAlarms();
                cancelled = c && typeof c.cancelled === 'number' ? c.cancelled : null;
              }
            } catch { /* أفضل جهد — نمضي إلى LN مع توثيق ذلك */ }
            adhanDiag('native-schedule', `فشلت الجدولة عبر AdhanAuto (${String((e && e.message) || e)}) — أُلغي الأصلي (${cancelled === null ? '؟' : cancelled} منبّهاً) ثم عودة إلى LN`);
            adhanDiag('native-missing-fallback', `AdhanAuto فشل أثناء الجدولة — جُدول الأذان عبر LocalNotifications (${adhanList.length} تنبيهاً) بعد إلغاء الأصلي`);
            if (LN && adhanList.length) await LN.schedule({ notifications: adhanList });
          }
        } else {
          // لا إضافة أصلية: الأذان عبر LN كما في 2.6.1 تماماً.
          if (LN && adhanList.length) await LN.schedule({ notifications: adhanList });
          const chans = [...new Set(adhanList.map((n) => n.channelId))].join(', ');
          adhanDiag('schedule', `جُدول ${adhanList.length + lnList.length} إشعاراً (أذان ${adhanList.length}، قنوات: ${chans || '—'}) لمدة 14 يوماً`);
          adhanDiag('native-missing-fallback', `AdhanAuto غير متوفر — جُدول الأذان عبر LocalNotifications (${adhanList.length} تنبيه أذان) لمدة 14 يوماً`);
        }
        if (LN && lnList.length) await LN.schedule({ notifications: lnList });
      } catch (e) { adhanDiag('schedule-error', String((e && e.message) || e)); console.warn('adhan schedule', e); }
    }, 400);
  }
  async function exactAllowed() {
    // 2.6.4: عند الفشل لا نفترض السماح أبداً — الإرجاع السابق true كان
    // يُظهر «مسموح ✓» ويخفي مشكلة التنبيه الدقيق عن المستخدم.
    try { const r = await LN.checkExactNotificationSetting(); return r.exact_alarm !== 'denied'; } catch { return false; }
  }
  async function testAdhan() {
    if (!(await ensureNotify())) { adhanDiag('test-fail', 'تجربة التنبيه: الإشعارات غير مفعّلة'); toast('الإشعارات غير مفعّلة للتطبيق'); return; }
    const np = nextPrayer();
    await LN.schedule({ notifications: [{ id: 5000, title: 'تجربة تنبيه الأذان 🕌', body: 'هكذا سيصلك التنبيه عند دخول وقت الصلاة', channelId: ADHAN_CHANNELS.voice.id, extra: { route: 'adhan/' + np.key, adhan: np.key, at: Date.now() + 10000, test: true }, schedule: { at: new Date(Date.now() + 10000), allowWhileIdle: true } }] });
    adhanDiag('test-notification', `تجربة تنبيه بعد 10 ثوانٍ (صلاة ${np.key}، قناة ${ADHAN_CHANNELS.voice.id}، id 5000)`);
    toast('سيصلك التنبيه بعد ١٠ ثوانٍ، يمكنك قفل الهاتف');
  }
  // تجربة الأذان التلقائي (2.6.2): منبّه أصلي واحد بعد 10 ثوانٍ ينشر
  // إشعار ملء الشاشة الحقيقي — الصوت والشاشة يظهران تلقائياً والهاتف مقفول.
  // 2.6.4: فحص مسبق صادق — لا نعد بالشاشة إن كان الملء الكامل للشاشة
  // مرفوضاً، ولا نعد بالوقت الدقيق إن كان التنبيه الدقيق مرفوضاً؛
  // ونتيجة testAutomatic {ok, exact} تُقرأ ولا تُفترض.
  async function testAdhanAuto() {
    const AA = ADHAN_AUTO();
    if (!AA || !AA.testAutomatic) { adhanDiag('test-auto', 'تجربة الأذان التلقائي: AdhanAuto غير متوفر في هذه النسخة'); toast('الأذان التلقائي غير متوفر في هذه النسخة'); return; }
    const np = nextPrayer();
    let fsiOk = null;
    let exactDenied = false;
    try {
      const st = await refreshPhoneState();
      if (st) {
        fsiOk = st.fullScreenAllowed === true;
        exactDenied = st.exactAlarm === false || nativeAdhanExact === false;
      }
    } catch { /* أفضل جهد — نمضي بالتجربة مع توثيق أن الحالة غير معروفة */ }
    if (fsiOk === false) {
      adhanDiag('test-auto', 'الملء الكامل للشاشة غير مسموح — الاختبار سيظهر إشعاراً فقط ولن تظهر الشاشة والهاتف مقفول');
      toast('الملء الكامل للشاشة غير مسموح — الاختبار سيظهر إشعاراً فقط');
    }
    if (exactDenied) {
      adhanDiag('test-auto', 'التنبيه في الوقت بالضبط غير مسموح — قد يتأخر اختبار الأذان التلقائي');
      toast('التنبيه الدقيق غير مسموح — قد يتأخر الاختبار');
    }
    try {
      const res = await AA.testAutomatic({ delayMs: 10000, key: np.key });
      if (res && res.ok === false) {
        adhanDiag('test-auto', 'تعذّرت جدولة تجربة الأذان التلقائي (testAutomatic أعاد ok:false)');
        toast('تعذّرت جدولة الاختبار');
        return;
      }
      if (res && res.exact === false) adhanDiag('test-auto', `تجربة الأذان التلقائي بعد 10 ثوانٍ (صلاة ${np.key}) — التنبيه غير دقيق، قد يتأخر`);
      else adhanDiag('test-auto', `تجربة الأذان التلقائي بعد 10 ثوانٍ (صلاة ${np.key})`);
      toast(fsiOk === false ? 'سيصلك إشعار بعد ١٠ ثوانٍ (بلا شاشة تلقائية — الملء الكامل للشاشة غير مسموح)' : 'اقفل الهاتف فوراً — ستظهر شاشة الأذان تلقائياً مع الصوت');
    } catch (e) { adhanDiag('test-auto', `فشلت تجربة الأذان التلقائي: ${String((e && e.message) || e)}`); toast('تعذّرت تجربة الأذان التلقائي'); }
  }
  // تجربة عزل (2.6.2): تنبيه بعد 10 ثوانٍ بصوت النظام الافتراضي على قناة
  // اختبار — يفرّق بين خلل ملف الصوت وخلل الهاتف (صامت/عدم إزعاج/صوت صفر).
  // 2.6.4: نتيجة testDefaultSound {ok} تُقرأ — ok:false تعني فشل الجدولة.
  async function testAdhanDefault() {
    const AA = ADHAN_AUTO();
    if (!AA || !AA.testDefaultSound) { adhanDiag('test-default', 'تجربة الصوت الافتراضي: AdhanAuto غير متوفر في هذه النسخة'); toast('تجربة الصوت الافتراضي غير متوفرة في هذه النسخة'); return; }
    try {
      const res = await AA.testDefaultSound({ delayMs: 10000 });
      if (res && res.ok === false) {
        adhanDiag('test-default', 'تعذّرت جدولة تجربة الصوت الافتراضي (testDefaultSound أعاد ok:false)');
        toast('تعذّرت جدولة الاختبار');
        return;
      }
      adhanDiag('test-default', 'تجربة صوت التنبيه الافتراضي بعد 10 ثوانٍ (قناة adhan-test-default)');
      toast('اقفل الهاتف فوراً — تنبيه بصوت النظام الافتراضي');
    } catch (e) { adhanDiag('test-default', `فشلت تجربة الصوت الافتراضي: ${String((e && e.message) || e)}`); toast('تعذّرت تجربة الصوت الافتراضي'); }
  }
  // حالة الهاتف (2.6.2): رنين/عدم إزعاج/صوت إشعارات/ملء الشاشة — تُقرأ
  // عبر AdhanAuto وتُعرض في بطاقة الحالة وتُسجَّل في سجل التشخيص.
  async function refreshPhoneState() {
    const AA = ADHAN_AUTO();
    if (!AA || !AA.getPhoneState) return null;
    let st = null;
    try { st = await AA.getPhoneState(); } catch { return null; }
    if (!st || typeof st !== 'object') return null;
    phoneState = st;
    adhanDiag('phone-state', JSON.stringify(st));
    const ringerLabel = { normal: 'عادي ✓', silent: 'صامت ⚠️', vibrate: 'اهتزاز ⚠️' }[st.ringerMode] || (st.ringerMode || '؟');
    const dndLabel = { all: 'متوقف ✓', priority: 'الأولوية فقط ⚠️', none: 'مفعّل — الكل محجوب ⚠️', alarms: 'المنبهات فقط ⚠️', unknown: '؟' }[st.interruptionFilter] || (st.interruptionFilter || '؟');
    // 2.6.4: صوت الإشعارات منخفض جداً (≤ 3 من الحد الأقصى) يُحذَّر منه
    // كما الصفر تماماً — سجل المستخدم أظهر 2/15 فلم يُسمع الأذان.
    const volLow = typeof st.notifVolume === 'number' && st.notifVolume <= 3;
    const volLabel = (typeof st.notifVolume === 'number' && typeof st.notifVolumeMax === 'number')
      ? `${ar(st.notifVolume)} / ${ar(st.notifVolumeMax)}${volLow ? ' ⚠️' : ' ✓'}`
      : '؟';
    const setText = (id, txt) => { const el = $(id); if (el) el.textContent = txt; };
    setText('#stRinger', ringerLabel);
    setText('#stDnd', dndLabel);
    setText('#stVol', volLabel);
    // 2.6.4: صف البطارية يعرض الحالة الحقيقية من getPhoneState
    // (batteryOptimized) بدل «تحقق يدوياً» الثابتة.
    const battLabel = st.batteryOptimized === true ? 'بلا قيود ✓' : st.batteryOptimized === false ? 'مقيّد ⚠️' : 'تحقق يدوياً';
    setText('#stBatt', battLabel);
    adhanDiag('permissions', `توفير البطارية: ${battLabel}`);
    const vr = $('#volRaiseRow'); if (vr) vr.hidden = !volLow;
    const fsiOk = st.fullScreenAllowed === true;
    setText('#stFsi', fsiOk ? 'مسموح ✓' : 'غير مسموح ⚠️');
    const bF = $('#btnFsi'); if (bF) bF.hidden = fsiOk;
    if (!fsiOk) adhanDiag('native-fsi', 'الملء الكامل للشاشة غير مسموح — الأذان التلقائي لن يفتح الشاشة والهاتف مقفول');
    const warns = [];
    if (st.ringerMode === 'silent') warns.push('الهاتف على الصامت — لن يُسمع صوت الأذان');
    else if (st.ringerMode === 'vibrate') warns.push('الهاتف على الاهتزاز — لن يُسمع صوت الأذان');
    if (st.interruptionFilter === 'none') warns.push('وضع «عدم الإزعاج» يحجب كل الإشعارات');
    else if (st.interruptionFilter === 'priority') warns.push('وضع «عدم الإزعاج» يسمح بالأولوية فقط — قد يُحجب الأذان');
    else if (st.interruptionFilter === 'alarms') warns.push('وضع «عدم الإزعاج» يسمح بالمنبهات فقط — قد يُحجب الأذان');
    if (typeof st.notifVolume === 'number' && st.notifVolume === 0) warns.push('صوت الإشعارات صفر — لن يُسمع صوت الأذان');
    else if (typeof st.notifVolume === 'number' && st.notifVolume <= 3) warns.push(`صوت الإشعارات منخفض جداً (${ar(st.notifVolume)}/${ar(st.notifVolumeMax || 15)}) — قد لا يُسمع الأذان`);
    // 2.6.4: حالة الملء الكامل للشاشة في شريط التحذير نفسه — بدونها
    // لن تظهر شاشة الأذان والهاتف مقفول حتى لو نُشر الإشعار.
    if (!fsiOk) warns.push('الملء الكامل للشاشة غير مسموح — الشاشة لن تظهر والهاتف مقفول');
    if (nativeAdhanExact === false) warns.push('التنبيه في الوقت بالضبط غير مسموح للأذان التلقائي — قد يتأخر الأذان');
    const warnEl = $('#phoneWarn');
    if (warnEl) { warnEl.hidden = !warns.length; warnEl.textContent = warns.length ? `⚠️ ${warns.join(' • ')}` : ''; }
    return st;
  }
  // الضغط على إشعار: يفتح مساره (شاشة الأذان للإشعارات adhan/*، أو مسار
  // الأذكار). مع منع التكرار لإشعارات الأذان عبر adhan:played.
  function handleNotificationTap(e) {
    try {
      const n = e && e.notification;
      const ex = (n && n.extra) || {};
      const route = ex.route;
      if (!route) return;
      adhanDiag('tap', `ضُغط إشعار (id ${n.id != null ? n.id : '؟'}): route=${route}${ex.adhan ? ` صلاة=${ex.adhan}` : ''}${ex.at ? ` at=${new Date(ex.at).toISOString()}` : ''}`);
      if (ex.adhan) {
        if (adhanHandled(ex.adhan, ex.at || Date.now())) { adhanDiag('tap-dedup', `تجاهل ضغطة مكررة لصلاة ${ex.adhan}`); return; }
      }
      go(route);
    } catch (err) { console.warn('notification tap', err); }
  }
  // استرداد عند التشغيل البارد: إن ضُغط إشعار أذان وفتح التطبيق دون أن
  // يصل حدث الضغطة (حدث وحيد قد يضيع)، نجد الإشعار ما زال في شريط
  // الإشعارات ونفتح مساره. نافذة 15 دقيقة فقط حتى لا تُفتح شاشة قديمة.
  async function recoverDeliveredAdhanTap() {
    // أولاً: إشعار أصلي ما زال في شريط الإشعارات (AdhanAuto) — المصدر
    // الجديد لتنبيهات الأذان منذ 2.6.2.
    const AA0 = ADHAN_AUTO();
    if (AA0 && AA0.getActiveAdhan) {
      try {
        const a = await AA0.getActiveAdhan();
        const now0 = Date.now();
        if (a && a.key && typeof a.at === 'number' && a.at > now0 - 15 * 60000 && a.at <= now0 + 60000 && !wasAdhanPlayed(a.key, a.at)) {
          adhanDiag('recovery-native', `استرداد أصلي عند التشغيل: إشعار أذان (id ${a.id != null ? a.id : '؟'}) لصلاة ${a.key} ما زال في شريط الإشعارات — فتح adhan/${a.key}`);
          go('adhan/' + a.key);
          return;
        }
      } catch (err) { console.warn('adhan native recovery', err); }
    }
    if (!LN || !LN.getDeliveredNotifications) return;
    try {
      const r = await LN.getDeliveredNotifications();
      const list = (r && r.notifications) || [];
      const now = Date.now();
      const fresh = list
        .filter((n) => n && n.extra && n.extra.adhan && n.extra.route && typeof n.extra.at === 'number' && n.extra.at > now - 15 * 60000 && n.extra.at <= now + 60000)
        .sort((a, b) => b.extra.at - a.extra.at);
      if (!fresh.length) return;
      const n = fresh[0];
      if (wasAdhanPlayed(n.extra.adhan, n.extra.at)) return;
      adhanDiag('recovery', `استرداد عند التشغيل: إشعار أذان (id ${n.id}) لصلاة ${n.extra.adhan} وُجد في شريط الإشعارات دون حدث ضغطة — فتح ${n.extra.route}`);
      try {
        if (LN.removeDeliveredNotificationsById) await LN.removeDeliveredNotificationsById({ ids: [n.id] });
        else if (LN.removeDeliveredNotifications) await LN.removeDeliveredNotifications({ notifications: [{ id: n.id }] });
      } catch { /* أفضل جهد */ }
      go(n.extra.route);
    } catch (err) { console.warn('adhan recovery', err); }
  }
  // استرداد عند عودة التطبيق للمقدمة (2.6.4): نفس نافذة الـ 15 دقيقة
  // ومنع التكرار كما في استرداد التشغيل البارد — يغطي وصول الأذان أثناء
  // وجود التطبيق في الخلفية دون ضغطة. Idempotent: consumePendingRoute
  // يمسح المسار المعلق، وwasAdhanPlayed يمنع إعادة فتح شاشة عُرضت.
  async function checkPendingAdhanRoute() {
    const AA = ADHAN_AUTO();
    if (!AA) return;
    try {
      if (AA.consumePendingRoute) {
        const p = await AA.consumePendingRoute();
        const route = p && (p.route || (p.key ? 'adhan/' + p.key : ''));
        const at = p && typeof p.at === 'number' ? p.at : 0;
        if (route) {
          const key = p && p.key ? p.key : (route.startsWith('adhan/') ? route.slice(6) : '');
          if (key && at && wasAdhanPlayed(key, at)) {
            adhanDiag('recovery-native', `مسار معلّق مكرر تُجاهل عند العودة للمقدمة: ${route} (عُرضت شاشته من قبل)`);
          } else if (!at || (at > Date.now() - 15 * 60000 && at <= Date.now() + 60000)) {
            adhanDiag('recovery-native', `مسار معلّق عند العودة للمقدمة: ${route} — فتحه`);
            go(route);
            return;
          } else {
            adhanDiag('recovery-native', `مسار معلّق قديم تُجاهل عند العودة للمقدمة: ${route}`);
          }
        }
      }
    } catch (err) { console.warn('adhan pending route on resume', err); }
    // إشعار أصلي ما زال في شريط الإشعارات (بلا مسار معلّق)
    try {
      if (AA.getActiveAdhan) {
        const a = await AA.getActiveAdhan();
        const now = Date.now();
        if (a && a.key && typeof a.at === 'number' && a.at > now - 15 * 60000 && a.at <= now + 60000 && !wasAdhanPlayed(a.key, a.at)) {
          adhanDiag('recovery-native', `استرداد أصلي عند العودة للمقدمة: إشعار أذان (id ${a.id != null ? a.id : '؟'}) لصلاة ${a.key} ما زال في شريط الإشعارات — فتح adhan/${a.key}`);
          go('adhan/' + a.key);
        }
      }
    } catch (err) { console.warn('adhan active recovery on resume', err); }
  }
  // تسلسل تشغيل الأذان التلقائي (2.6.2): بعد تسجيل مستمعي LN واسترداد
  // الضغطة: (1) مسار معلّق من نيّة ملء الشاشة، (2) تفريغ أحداث الإضافة
  // الأصلية إلى سجل التشخيص، (3) قراءة حالة الهاتف للبطاقة والسجل.
  async function bootAdhanAuto() {
    const AA = ADHAN_AUTO();
    if (!AA) return; // متصفح/ويب: لا إضافة أصلية — الجدولة عبر LN وتسجّل ذلك
    try {
      if (AA.consumePendingRoute) {
        const p = await AA.consumePendingRoute();
        const route = p && (p.route || (p.key ? 'adhan/' + p.key : ''));
        const at = p && typeof p.at === 'number' ? p.at : 0;
        if (route) {
          if (!at || (at > Date.now() - 15 * 60000 && at <= Date.now() + 60000)) {
            adhanDiag('recovery-native', `مسار معلّق من نيّة ملء الشاشة: ${route} — فتحه عند التشغيل`);
            go(route);
          } else {
            adhanDiag('recovery-native', `مسار معلّق قديم تُجاهل: ${route}`);
          }
        }
      }
    } catch (err) { console.warn('adhan pending route', err); }
    try {
      if (AA.drainNativeEvents) {
        const evs = await AA.drainNativeEvents();
        const evList = Array.isArray(evs) ? evs : (evs && Array.isArray(evs.events) ? evs.events : []);
        for (const e of evList) {
          adhanDiag('native-boot', `${(e && e.type) || 'event'}: ${(e && e.msg) || ''}${e && e.at ? ` (${new Date(e.at).toISOString()})` : ''}`);
        }
      }
    } catch (err) { console.warn('adhan drain events', err); }
    // 2.6.3: refreshPhoneState نفسه يلتقط رفض getPhoneState ويعيد null،
    // لكن الحارس هنا يمنع أي رفض غير متوقع من إسقاط bootAdhanAuto كله.
    try { await refreshPhoneState(); } catch (err) { adhanDiag('boot-error', `فشلت قراءة حالة الهاتف عند التشغيل: ${String((err && err.message) || err)}`); console.warn('adhan phone state', err); }
    // 2.6.4: تذكير لمرة واحدة (بحد أقصى مرتين إجمالاً) بمنح الملء الكامل
    // للشاشة — بدونه لا تظهر شاشة الأذان والهاتف مقفول، والمستخدم قد لا
    // يفتح بطاقة الحالة أبداً. لا يُعرض إطلاقاً إن كان مسموحاً أصلاً.
    try {
      if (phoneState && phoneState.fullScreenAllowed === false) {
        let count = 0;
        try { count = +(store.get('fsi-prompted', 0) || 0); } catch { count = 0; }
        if (Number.isFinite(count) && count < 2) {
          try { store.set('fsi-prompted', count + 1); } catch { /* تجاهل */ }
          adhanDiag('fsi-prompt', `تذكير بمنح الملء الكامل للشاشة عند التشغيل (مرة ${count + 1} من 2) — بدونه لن تظهر شاشة الأذان والهاتف مقفول`);
          toast('لظهور شاشة الأذان والهاتف مقفول: اسمح بالملء الكامل للشاشة');
          if (typeof AA.openFullScreenIntentSettings === 'function') {
            try { await AA.openFullScreenIntentSettings(); } catch { /* تجاهل — المستخدم يرفض أو يغلق الصفحة */ }
          }
        }
      }
    } catch (err) { console.warn('adhan fsi prompt', err); }
  }
  if (LN || ADHAN_AUTO()) {
    scheduleAdhan();
    // 2.6.4: عند العودة للمقدمة تُحدَّث حالة الهاتف (فلا تبقى قيم الصوت/
    // الملء الكامل قديمة بعد عودة المستخدم من إعدادات النظام) ويُعاد
    // فحص المسار المعلق — إضافة إلى الجدولة الموجودة.
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        scheduleAdhan();
        refreshPhoneState().catch(() => {});
        checkPendingAdhanRoute().catch((e) => { console.warn('adhan resume route', e); });
      }
    });
    // إشعار وصل والتطبيق مفتوح: اعرض شاشة الأذان (الصوت يأتي من الإشعار نفسه).
    // الضغط على الإشعار يفتح الشاشة عبر extra.route (المستمع أدناه).
    if (LN) try {
      LN.addListener('localNotificationReceived', (e) => {
        const ex = e && e.notification && e.notification.extra;
        if (!ex || !ex.adhan) return;
        adhanDiag('received', `وصل إشعار أذان والتطبيق مفتوح: صلاة ${ex.adhan}${ex.at ? ` at=${new Date(ex.at).toISOString()}` : ''}${ex.test ? ' (تجربة)' : ''}`);
        if (ex.test) adhanTest = { key: ex.adhan };
        if (adhanHandled(ex.adhan, ex.at || Date.now())) return;
        go('adhan/' + ex.adhan);
      });
    } catch (e) { /* تجاهل */ }
    // الضغط على الإشعار — كان في js/azkar.js، نُقل هنا ليبقى مسار الأذان
    // مع كود الأذان ويُسجَّل عند التشغيل قبل أول router() (انظر أسفل الملف).
    if (LN) try { LN.addListener('localNotificationActionPerformed', handleNotificationTap); } catch (e) { /* تجاهل */ }
    // استرداد التشغيل البارد بعد تسجيل المستمع مباشرة.
    // 2.6.3: الاستدعاءان العائمان كانا بلا .catch — أي رفض غير ملتقط
    // يظهر كـ unhandled rejection؛ الآن يُسجَّل في سجل التشخيص.
    recoverDeliveredAdhanTap().catch((e) => { adhanDiag('boot-error', `فشل استرداد التشغيل البارد: ${String((e && e.message) || e)}`); console.warn('adhan recovery', e); });
    // تسلسل الأذان التلقائي الأصلي (مسار معلّق + أحداث + حالة الهاتف).
    bootAdhanAuto().catch((e) => { adhanDiag('boot-error', `فشل bootAdhanAuto: ${String((e && e.message) || e)}`); console.warn('adhan boot', e); });
  }


  // فتح صفحة التطبيق في إعدادات أندرويد (لإعفائه من توفير البطارية) —
  // أفضل جهد عبر intent:؛ إن لم يستجب الجهاز تظهر الإرشادات اليدوية.
  function openAppSettings() {
    try {
      window.location.href = 'intent://#Intent;action=android.settings.APPLICATION_DETAILS_SETTINGS;data=package:com.abdelnaser.athar;end';
      setTimeout(() => toast('إن لم تُفتح الإعدادات: الإعدادات ← التطبيقات ← يقين ← البطارية ← بلا قيود'), 1500);
    } catch { toast('الإعدادات ← التطبيقات ← يقين ← البطارية ← بلا قيود'); }
  }

  // ---------- تنبيه الأذان داخل التطبيق ----------
  // مراقب كل 20 ثانية: عند دخول وقت صلاة مفعّلة والتطبيق مفتوح، يعرض شاشة
  // الأذان. الصوت يأتي من إشعار الخلفية نفسه إن كان مفعّلاً؛ وشاشة الأذان
  // تشغّل الصوت داخلياً فقط عند غياب تغطية الإشعار (متصفح أو إشعارات
  // مرفوضة). منع التكرار: adhanHandled (صلاة+يوم) يمنع العرض مرتين حتى مع
  // إعادة تحميل الصفحة داخل نافذة الدقيقة نفسها.
  let adhanEl = null;
  const adhanAudio = () => (adhanEl = adhanEl || new Audio('adhan/adhan.mp3'));
  function stopAdhanAudio() { try { if (adhanEl && !adhanEl.paused) { adhanEl.pause(); adhanEl.currentTime = 0; } } catch { /* تجاهل */ } }
  window.addEventListener('yaqeen:audio', (e) => { if (e.detail !== 'adhan' && adhanEl && !adhanEl.paused) adhanEl.pause(); });
  setInterval(() => {
    if (!settings.alerts || document.visibilityState !== 'visible') return;
    const now = new Date();
    const t = timesFor(now);
    for (const p of PRAY5) {
      if ((settings.alertOff || []).includes(p.key)) continue;
      const diff = now - t[p.key];
      if (diff >= 0 && diff < 60000 && !adhanHandled(p.key, t[p.key].getTime())) {
        go('adhan/' + p.key);
      }
    }
  }, 20000);

  // ---------- واجهة الوحدات الإضافية (المكتبة الصوتية، الأكاديمية، ...) ----------
  window.Noor = {
    $, $$, view, store, toast, go, ar, arG, toAr, esc, routes, settings, saveSettings,
    fetchJSON, API, sheet, shareText, todayKey, ymdIn, tz, hijri, greg, NATIVE, applyTheme, AZKAR, scheduleAdhan,
    fmtBytes,
    timesFor, nextPrayer, fmtTime, countdown, PRAYERS, TAFSIRS, normAr,
    setTitle: (t) => { $('#pageTitle').textContent = t; },
    homeExtras: [],
  };
  (window.NoorModules || []).forEach((m) => { try { m(window.Noor); } catch (e) { console.error('module', e); } });

  // ---------- التشغيل ----------
  applyTheme();
  router();
  if (!NATIVE && 'serviceWorker' in navigator && location.protocol !== 'file:') {
    const hadController = !!navigator.serviceWorker.controller;
    let reloaded = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (hadController && !reloaded) { reloaded = true; location.reload(); }
    });
    navigator.serviceWorker.register('sw.js', { updateViaCache: 'none' }).then((r) => r.update()).catch(() => {});
  }
})();
