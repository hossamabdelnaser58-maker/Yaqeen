/* منتخبات إيمانية — صفحة جامعة + مجموعات أذكار مشتقة من بيانات المشروع الموثقة.
 * لا يحتوي هذا الملف على أي نص قرآني أو حديثي مكتوب يدوياً:
 *  - مجموعات الأذكار تُشتق وقت التشغيل من js/azkar-data.js بحسب الحكم المنقول من نص التخريج نفسه.
 *  - الآيات تُفتح في المصحف بالرقم فقط، ونصها يُجلب من المصدر نفسه الذي يعتمده المصحف.
 *  - أسماء السور من js/quran-meta.js. */
(window.NoorModules = window.NoorModules || []).push((N) => {
  'use strict';
  const { go, esc, ar, routes } = N;
  const DB = window.AZ_DB;
  const NAMES = typeof SURAH_NAMES === 'undefined' ? [] : SURAH_NAMES;

  // ---------- مجموعات أذكار موثقة (مشتقة من البيانات الموجودة، بلا نصوص جديدة) ----------
  if (DB && Array.isArray(DB.azkar) && DB.items) {
    const byGrade = (g) => Object.keys(DB.items).filter((k) => DB.items[k] && DB.items[k].g === g);
    const add = (k, t, ic, g) => {
      if (DB.azkar.some((c) => c.k === k)) return;
      const items = byGrade(g);
      if (items.length) DB.azkar.push({ k, t, ic, items });
    };
    add('sahihayn-agreed', 'أذكار وأحاديث متفق عليها (البخاري ومسلم)', '🌟', 'muttafaq');
    add('sahih-bukhari', 'من صحيح البخاري', '📗', 'bukhari');
    add('sahih-muslim', 'من صحيح مسلم', '📘', 'muslim');
    add('sahih-graded', 'أذكار وأدعية صحيحة (بتصحيح أهل العلم)', '✅', 'sahih');
    add('hasan-graded', 'أذكار وأدعية حسنة', '🌿', 'hasan');
    add('maqbul-graded', 'أذكار وأدعية مقبولة (صحيحة أو حسنة)', '📙', 'maqbul');
  }

  const ayat = [
    // [سورة، من، إلى، وصف]
    [2, 255, 255, 'آية الكرسي'],
    [2, 285, 286, 'خواتيم سورة البقرة'],
    [2, 282, 282, 'آية الدَّين'],
    [2, 183, 187, 'آيات الصيام'],
    [17, 23, 24, 'الأمر ببر الوالدين'],
    [23, 1, 11, 'صفات المؤمنين المفلحين'],
    [24, 35, 35, 'آية النور'],
    [25, 63, 77, 'صفات عباد الرحمن'],
    [31, 13, 19, 'وصايا لقمان لابنه'],
    [59, 22, 24, 'خواتيم سورة الحشر'],
    [96, 1, 5, 'أول ما نزل من القرآن'],
    [3, 190, 194, 'التفكر في خلق السماوات والأرض ودعاء أولي الألباب'],
    [4, 36, 36, 'عبادة الله والإحسان إلى الوالدين والأقربين'],
    [33, 56, 56, 'الأمر بالصلاة على النبي ﷺ'],
    [49, 10, 13, 'الأخوة وآداب المجتمع المسلم'],
    [51, 56, 56, 'الغاية من خلق الجن والإنس'],
    [65, 2, 3, 'التقوى والتوكل'],
  ];
  const suwar = [1, 18, 32, 36, 55, 56, 67, 78, 87, 88, 93, 94, 97, 99, 103, 108, 109, 110, 112, 113, 114];

  const row = (num, title, desc, route) => `<li class="yq-index-item" data-go="${route}" style="cursor:pointer"><span class="yq-index-num">${ar(num)}</span><div class="yq-index-body"><h3 class="yq-index-title">${esc(title)}</h3>${desc ? `<p class="yq-index-desc">${esc(desc)}</p>` : ''}</div><span aria-hidden="true">‹</span></li>`;

  function render() {
    N.setTitle('منتخبات إيمانية');
    const rng = (a, b) => (a === b ? `الآية ${ar(a)}` : `الآيات ${ar(a)}–${ar(b)}`);
    const quranRows = ayat.filter(([s]) => NAMES[s - 1]).map(([s, a, b, d], i) => row(i + 1, d, `سورة ${NAMES[s - 1]} · ${rng(a, b)}`, `surah/${s}/${a}`)).join('');
    const surahRows = suwar.filter((s) => NAMES[s - 1]).map((s, i) => row(i + 1, `سورة ${NAMES[s - 1]}`, `السورة رقم ${ar(s)}`, `surah/${s}`)).join('');
    const has = (k) => DB && DB.azkar && DB.azkar.some((c) => c.k === k);
    const sunnah = [
      has('sahihayn-agreed') && ['أذكار وأحاديث متفق عليها', 'ما اتفق عليه البخاري ومسلم', 'azcat/azkar/sahihayn-agreed'],
      has('sahih-bukhari') && ['من صحيح البخاري', 'أذكار مخرّجة في صحيح البخاري', 'azcat/azkar/sahih-bukhari'],
      has('sahih-muslim') && ['من صحيح مسلم', 'أذكار مخرّجة في صحيح مسلم', 'azcat/azkar/sahih-muslim'],
      ['الأربعون النووية', 'للإمام النووي رحمه الله', 'hbook/nawawi'],
      ['الأربعون القدسية', 'الأحاديث القدسية', 'hbook/qudsi'],
      ['مكتبة الحديث الشريف', 'تسعة كتب من كتب السنة', 'hadith'],
      ['أدعية القرآن الكريم', 'الأدعية الواردة في القرآن مع السورة ورقم الآية', 'azcat/duas/quran'],
      ['الأسماء الحسنى', 'أسماء الله الحسنى', 'names'],
      ...['sahih-graded', 'hasan-graded', 'maqbul-graded'].filter(has).map((k) => { const c = DB.azkar.find((x) => x.k === k); return [c.t, `${ar(c.items.length)} ذكراً مع التخريج`, `azcat/azkar/${k}`]; }),
    ].filter(Boolean);
    const duaRows = DB && DB.duas ? DB.duas.map((c, i) => row(i + 1, c.t, `${ar(c.items.length)} ${c.items.length > 10 ? 'دعاءً' : 'أدعية'}`, `azcat/duas/${c.k}`)).join('') : '';
    const azkarRows = DB && DB.azkar ? DB.azkar.filter((c) => !/^(sahihayn-agreed|sahih-|hasan-|maqbul-)/.test(c.k)).map((c, i) => row(i + 1, c.t, `${ar(c.items.length)} ذكراً`, `azcat/azkar/${c.k}`)).join('') : '';
    N.view.innerHTML = `
      <div class="yq-encyc-chapter"><p style="margin:0">مداخل سريعة إلى القرآن والسنة. النصوص تُعرض من مصادر التطبيق الموثقة نفسها، والحكم على الأحاديث منقول من نص التخريج.</p></div>
      <div class="section-title">آيات مختارة</div>
      <ol class="yq-index">${quranRows}</ol>
      <div class="section-title">سور مختارة</div>
      <ol class="yq-index">${surahRows}</ol>
      <div class="section-title">من السنة والأذكار</div>
      <ol class="yq-index">${sunnah.map(([t, d, r], i) => row(i + 1, t, d, r)).join('')}</ol>
      ${duaRows ? `<div class="section-title">أدعية بحسب الحاجة</div><ol class="yq-index">${duaRows}</ol>` : ''}
      ${azkarRows ? `<div class="section-title">أذكار بحسب الموضع</div><ol class="yq-index">${azkarRows}</ol>` : ''}
      <p class="muted enc-note">هذه الصفحة للتيسير على القراءة وليست فتوى. لمعرفة مصدر كل نص وحكمه افتح التخريج أسفل كل ذكر.</p>`;
    N.view.querySelectorAll('[data-go]').forEach((b) => { b.onclick = () => go(b.dataset.go); });
  }

  Object.assign(routes, { muntakhab: { title: 'منتخبات إيمانية', render, back: 'home' } });
});
