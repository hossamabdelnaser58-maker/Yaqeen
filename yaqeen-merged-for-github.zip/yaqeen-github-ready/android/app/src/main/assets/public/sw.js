/* عامل الخدمة: أحدث نسخة من الشبكة دائماً، والذاكرة عند انقطاع الإنترنت */
const VERSION = 'yaqeen-v56';
const SHELL = [
  './', 'index.html', 'css/style.css', 'css/yaqeen-design.css', 'css/yaqeen-v3.css', 'js/app.js', 'js/data.js', 'js/praytimes.js',
  'js/native-flags.js', 'js/quran-meta.js', 'js/academy-data.js', 'js/audio-lib.js', 'js/academy.js',
  'js/hadith-meta.js', 'js/hadith.js', 'js/hifz.js', 'js/dawah.js', 'js/azkar-data.js', 'js/azkar.js', 'js/radio.js', 'js/ibtihal.js', 'js/encyc-data.js', 'js/encyc.js', 'js/library.js', 'js/prayer-quran.js', 'js/calc-faraid.js', 'js/calc.js', 'js/calc-debts.js', 'js/calc-fin.js', 'js/calc-kaff.js', 'js/calc-ibadat.js', 'js/calc-contract.js', 'js/fiqh.js', 'js/fiqh-ask.js', 'js/share.js', 'js/version.js', 'data/enc-wiki.json', 'data/lib-index.json',
  'manifest.webmanifest', 'icons/icon.svg', 'icons/art/mosque.svg', 'icons/art/pattern.svg', 'icons/art/lantern.svg', 'icons/art/mosque-dark.svg', 'icons/art/pattern-dark.svg', 'icons/art/lantern-dark.svg', 'adhan/adhan.mp3', 'adhan/adhan_short.mp3',
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(VERSION)
      .then((c) => c.addAll(SHELL.map((u) => new Request(u, { cache: 'reload' }))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== VERSION && !k.startsWith('noor-audio') && !k.startsWith('noor-data') && !k.startsWith('noor-books')).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

const put = (req, res) => {
  if (res && (res.ok || res.type === 'opaque')) {
    const copy = res.clone();
    caches.open(VERSION).then((c) => c.put(req, copy));
  }
  return res;
};

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  // لا نخزّن ملفات الصوت لكبر حجمها
  if (/islamic\.network|mp3quran\.net|everyayah\.com|hadith-api|supabase\.co|ytimg\.com|youtube/.test(url.hostname + url.pathname) || req.headers.has('range')) return;

  if (url.origin === self.location.origin) {
    // ملفات التطبيق: الشبكة أولاً (بدون ذاكرة المتصفح) ثم النسخة المحفوظة
    e.respondWith(
      fetch(req, { cache: 'no-cache' }).then((res) => put(req, res))
        .catch(() => caches.match(req, { ignoreSearch: true }).then((hit) => hit || caches.match('./')))
    );
    return;
  }

  // الخطوط وبيانات القرآن: من الذاكرة أولاً ثم الشبكة
  e.respondWith(
    caches.match(req).then((hit) => hit || fetch(req).then((res) => put(req, res)))
  );
});
